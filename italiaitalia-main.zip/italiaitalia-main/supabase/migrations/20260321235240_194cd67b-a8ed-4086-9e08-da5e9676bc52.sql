-- Create expenses table
CREATE TABLE public.expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  amount_eur NUMERIC(10,2) NOT NULL DEFAULT 0,
  category TEXT NOT NULL DEFAULT 'other',
  paid_by TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Expenses viewable by authenticated"
  ON public.expenses FOR SELECT TO authenticated USING (true);

CREATE POLICY "Expenses insert by authenticated"
  ON public.expenses FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Expenses delete by creator"
  ON public.expenses FOR DELETE TO authenticated
  USING (auth.uid() = created_by);

CREATE POLICY "Expenses update by creator"
  ON public.expenses FOR UPDATE TO authenticated
  USING (auth.uid() = created_by);

-- Create trip_notes table
CREATE TABLE public.trip_notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  day_index INTEGER NULL,
  content TEXT NOT NULL DEFAULT '',
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.trip_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Notes viewable by authenticated"
  ON public.trip_notes FOR SELECT TO authenticated USING (true);

CREATE POLICY "Notes insert by authenticated"
  ON public.trip_notes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Notes update by creator"
  ON public.trip_notes FOR UPDATE TO authenticated
  USING (auth.uid() = created_by);

CREATE POLICY "Notes delete by creator"
  ON public.trip_notes FOR DELETE TO authenticated
  USING (auth.uid() = created_by);

ALTER PUBLICATION supabase_realtime ADD TABLE public.expenses;
ALTER PUBLICATION supabase_realtime ADD TABLE public.trip_notes;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_expenses_updated_at
  BEFORE UPDATE ON public.expenses
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_trip_notes_updated_at
  BEFORE UPDATE ON public.trip_notes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();