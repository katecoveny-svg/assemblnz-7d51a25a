-- Fix: replace permissive WITH CHECK (true) with auth check on shared tables
drop policy if exists "Bookings insert" on public.activity_bookings;
drop policy if exists "Bookings update" on public.activity_bookings;
drop policy if exists "Hotel insert" on public.hotel_state;
drop policy if exists "Hotel update" on public.hotel_state;

create policy "Bookings insert" on public.activity_bookings for insert to authenticated with check (auth.uid() is not null);
create policy "Bookings update" on public.activity_bookings for update to authenticated using (auth.uid() is not null);
create policy "Hotel insert" on public.hotel_state for insert to authenticated with check (auth.uid() is not null);
create policy "Hotel update" on public.hotel_state for update to authenticated using (auth.uid() is not null);