export const REGION_COLORS: Record<string, string> = {
  Milan: "#8B5A3A",
  "Lake Garda": "#4A7A6A",
  Florence: "#7B3F6B",
  Tuscany: "#B8860B",
  Rome: "#8B2252",
  Sorrento: "#B87048",
  Departure: "#8A8A8A",
};

export type ActivityType = "free" | "ticket" | "food" | "experience" | "transport";

export interface Activity {
  nm: string;
  c: number;
  tp: ActivityType;
  bk: boolean;
  nt?: string;
  lnk?: string;
  map?: string;
}

export interface Day {
  dt: string;
  dy: string;
  act: string;
  stay: string;
  rg: string;
  sg: Activity[];
}

export type HotelTier = "budget" | "mid" | "luxury";

export interface HotelOption {
  nm: string;
  q: string;
  s: number;
  nzd: number;
  eur: number;
  v: string;
  tier: HotelTier;
  hood: string; // neighbourhood / location tag
  perks: string[]; // bullet point highlights
  bk?: boolean;
  rb?: boolean;
  site?: string; // official site or notable listing URL
}

export interface HotelEntry {
  ci: string;
  co: string;
  n: number;
  st: string;
  cf?: string;
  note?: string; // contextual booking note
  opts: HotelOption[];
}

export type Hotels = Record<string, HotelEntry>;

export const HOTELS: Hotels = {
  // ── MILAN ─────────────────────────────────────────────────────────────
  Milan: {
    ci: "2026-05-25", co: "2026-05-28", n: 3, st: "confirmed", cf: "Crowne Plaza",
    note: "Near Centrale station — ideal for Como day-trip and luggage storage.",
    opts: [
      {
        nm: "Crowne Plaza Milan City", q: "Crowne Plaza Milan City", s: 4,
        nzd: 0, eur: 0, tier: "mid", hood: "Porta Garibaldi",
        perks: ["Already booked ✓", "Near Centrale for Como train", "Rooftop bar"],
        v: "Your confirmed hotel — no action needed.",
        bk: true,
      },
      {
        nm: "Palazzo Montemartini", q: "Palazzo Montemartini Milan", s: 5,
        nzd: 1040, eur: 560, tier: "luxury", hood: "Piazza della Repubblica",
        perks: ["Rooftop pool & bar", "Art-deco palazzo", "Spa & hammam", "200m from Centrale"],
        v: "5-star art hotel in converted palazzo. Doubles from ~€560/n May. Rooftop is Milan's best kept secret.",
        site: "https://palazzomontemartini.com",
      },
      {
        nm: "Hotel Spadari al Duomo", q: "Spadari al Duomo Milan", s: 4,
        nzd: 560, eur: 300, tier: "mid", hood: "Duomo",
        perks: ["150m from Duomo", "Free minibar & prosecco", "Private art collection", "Quiet side street"],
        v: "Beloved boutique 4-star. Art-filled rooms, attentive staff. One of Milan's best mid-range options.",
        site: "https://www.spadarihotel.com",
      },
      {
        nm: "Ostello Bello Grande", q: "Ostello Bello Grande Milan", s: 3,
        nzd: 280, eur: 150, tier: "budget", hood: "Central Station",
        perks: ["Free breakfast + aperitivo", "Rooftop terrace", "Social atmosphere", "Near Centrale"],
        v: "Milan's best design hostel — also has private rooms. Perfect if budget is the priority.",
        site: "https://www.ostellobello.com",
      },
    ],
  },

  // ── LAKE GARDA ────────────────────────────────────────────────────────
  "Lake Garda": {
    ci: "2026-05-28", co: "2026-05-30", n: 2, st: "needed",
    note: "May is shoulder season — warm but not peak. Most hotels open from mid-April.",
    opts: [
      {
        nm: "Grand Hotel Terme Sirmione", q: "Grand Hotel Terme Sirmione", s: 4,
        nzd: 690, eur: 370, tier: "mid", hood: "Sirmione peninsula",
        perks: ["Thermal spa on the lake", "Direct lake access", "Historic building", "Walk to Scaligero Castle"],
        v: "Iconic 4-star on the Sirmione peninsula. Thermal wellness, lakefront pool, exceptional location.",
        site: "https://www.termesirmione.com",
      },
      {
        nm: "Lido Palace", q: "Lido Palace Riva del Garda", s: 5,
        nzd: 980, eur: 525, tier: "luxury", hood: "Riva del Garda (north)",
        perks: ["Belle Époque 5-star", "Private lakeside park", "Michelin-starred dining", "Water sports"],
        v: "The benchmark for Garda luxury. Historic northern town, dramatic Dolomite backdrop, yacht culture.",
        site: "https://www.lidopalace.com",
      },
      {
        nm: "Hotel Caesius Thermae & Spa", q: "Hotel Caesius Thermae Spa Bardolino", s: 4,
        nzd: 520, eur: 280, tier: "mid", hood: "Bardolino",
        perks: ["Thermal pools", "Full-board option", "Lakefront location", "Great for relaxing"],
        v: "Excellent value thermal resort on the eastern shore. Multiple pools, great for a spa-focused 2 nights.",
        site: "https://www.hotelcaesius.it",
      },
      {
        nm: "B&B Il Sogno di Giulietta", q: "B&B Sirmione Lake Garda", s: 0,
        nzd: 260, eur: 140, tier: "budget", hood: "Sirmione town",
        perks: ["Charming family-run B&B", "Steps from old town", "Included breakfast", "Unbeatable value"],
        v: "A gem for budget travellers. Lovely hosts, great breakfast, right in Sirmione village.",
        site: "",
      },
    ],
  },

  // ── FLORENCE ──────────────────────────────────────────────────────────
  Florence: {
    ci: "2026-05-30", co: "2026-06-01", n: 2, st: "needed",
    note: "⚠ Florence ZTL: don't drive into the centre. Park at Garage Europa (€25/day) before check-in.",
    opts: [
      {
        nm: "Hotel Lungarno", q: "Hotel Lungarno Florence", s: 4,
        nzd: 700, eur: 375, tier: "mid", hood: "Oltrarno (river south)",
        perks: ["Juliet balconies over the Arno", "50m from Ponte Vecchio", "Picasso art collection", "Michelin-starred Borgo San Jacopo"],
        v: "40 of 65 rooms face the Arno. Quieter side, steps from the bridge. One of Florence's most romantic stays.",
        site: "https://www.lungarnohotels.com",
      },
      {
        nm: "Stella d'Italia", q: "Stella d'Italia Florence", s: 4,
        nzd: 370, eur: 200, tier: "budget", hood: "Via Tornabuoni",
        perks: ["16th-century Vasari palazzo", "18th-century fresco breakfast room", "Rooftop terrace bar", "From €180/n"],
        v: "Florence's most character-packed 4-star at a budget price. Ring the gold doorbell on Via Tornabuoni.",
        site: "https://stelladitalia.com",
      },
      {
        nm: "Four Seasons Hotel Firenze", q: "Four Seasons Firenze", s: 5,
        nzd: 1680, eur: 900, tier: "luxury", hood: "Porta Pinti (near Duomo)",
        perks: ["1473 Renaissance palazzo & 11-acre gardens", "28m pool", "Michelin-starred Il Palagio", "Museum-worthy interiors"],
        v: "The unmatched #1 Florence hotel. Built 1473 by Bartolomeo Scala. Frescoed ceilings, private gardens. Worth every cent for one night.",
        site: "https://www.fourseasons.com/florence",
      },
      {
        nm: "Palazzo Guadagni", q: "Palazzo Guadagni Florence", s: 3,
        nzd: 335, eur: 180, tier: "budget", hood: "Santo Spirito (Oltrarno)",
        perks: ["1500s palazzo", "Iconic rooftop negroni bar", "Bohemian artisan neighbourhood", "Piazza Santo Spirito views"],
        v: "Florence's chicest secret. A 16th-century palazzo in the coolest piazza. The terrace bar alone is worth it.",
        site: "https://www.palazzoguadagnihotel.com",
      },
    ],
  },

  // ── TUSCANY ───────────────────────────────────────────────────────────
  Tuscany: {
    ci: "2026-06-01", co: "2026-06-03", n: 2, st: "needed",
    note: "June is stunning — warm, golden, not yet peak-summer crowded. Drive the SS222 Chiantigiana between properties.",
    opts: [
      {
        nm: "Castel Monastero", q: "Castel Monastero Castelnuovo Berardenga", s: 5,
        nzd: 1070, eur: 575, tier: "luxury", hood: "Castelnuovo Berardenga (near Siena)",
        perks: ["Medieval hamlet hotel", "Gordon Ramsay's Contrada restaurant", "Infinity pool + spa", "15km from Siena"],
        v: "A medieval village converted into a resort. Gordon Ramsay's restaurant inside. Stay for 1 night and explore Siena the next day.",
        site: "https://www.castelmonastero.com",
      },
      {
        nm: "Poggio Amoroso", q: "Poggio Amoroso agriturismo Montalcino", s: 0,
        nzd: 520, eur: 280, tier: "mid", hood: "Montalcino hills",
        perks: ["Working Brunello wine estate", "Pool with Val d'Orcia views", "Home-cooked Tuscan dinners", "Cypress-lined drive"],
        v: "Authentic agriturismo on a Brunello di Montalcino estate. The Val d'Orcia view from the pool is iconic.",
        site: "https://www.poggioamoroso.it",
      },
      {
        nm: "Agriturismo Rendola Riding", q: "Rendola Riding agriturismo Chianti", s: 0,
        nzd: 290, eur: 155, tier: "budget", hood: "Chianti Classico",
        perks: ["Farmhouse in Chianti vineyards", "Pool with hills view", "Simple home-cooked meals", "No tourist crowds"],
        v: "Classic Chianti farmhouse with pool. No frills, all soul. Wake up to olive groves and rooster calls.",
        site: "",
      },
      {
        nm: "Borgo San Felice", q: "Borgo San Felice Chianti", s: 5,
        nzd: 1220, eur: 655, tier: "luxury", hood: "Castelnuovo Berardenga (Chianti)",
        perks: ["Own Chianti Classico wine production", "Michelin-starred Poggio Rosso", "Village of suites + cottages", "Infinity pool"],
        v: "The Chianti dream. A medieval hamlet that's actually a Relais & Châteaux property with its own winery.",
        site: "https://www.borgosanfelice.it",
      },
    ],
  },

  // ── ROME ──────────────────────────────────────────────────────────────
  Rome: {
    ci: "2026-06-03", co: "2026-06-05", n: 2, st: "needed",
    note: "Don't drive in Rome. Park at the hotel garage or leave car before entering the city.",
    opts: [
      {
        nm: "Hotel Raphael", q: "Hotel Raphael Rome Navona", s: 5,
        nzd: 910, eur: 490, tier: "luxury", hood: "Piazza Navona",
        perks: ["Ivy-covered façade steps from Navona", "Terrace with St Peter's & Roman rooftop views", "Picasso & Miró art collection", "Unique character"],
        v: "Rome's most romantic hotel. Hidden behind ivy on a cobblestone lane. Rooftop views are breathtaking.",
        site: "https://www.raphaelhotel.com",
      },
      {
        nm: "Relais Palazzo Taverna", q: "Relais Palazzo Taverna Rome", s: 4,
        nzd: 420, eur: 225, tier: "mid", hood: "Campo de' Fiori / Navona",
        perks: ["15th-century palazzo", "125m from Campo de' Fiori", "Rooftop terrace with Tiber views", "Boutique atmosphere"],
        v: "Outstanding mid-range boutique in a 15th-century palace. Prime location between Navona and Campo de' Fiori.",
        site: "https://www.relaispalazzotaverna.com",
      },
      {
        nm: "Ciao Hostel Roma", q: "Ciao Hostel Trastevere Rome", s: 0,
        nzd: 220, eur: 120, tier: "budget", hood: "Trastevere",
        perks: ["Private rooms available", "Bohemian Trastevere neighbourhood", "Night life & restaurants on doorstep", "Excellent value"],
        v: "For budget-conscious: private rooms in Trastevere, Rome's most atmospheric neighbourhood.",
        site: "",
      },
      {
        nm: "Hotel de Russie", q: "Hotel de Russie Rome Spanish Steps", s: 5,
        nzd: 1300, eur: 700, tier: "luxury", hood: "Spanish Steps / Via Condotti",
        perks: ["Rocco Forte flagship", "Secret garden & spa", "Steps from Spanish Steps & Pantheon", "Legendary service"],
        v: "The Rocco Forte Rome classic. Terraced secret garden, 5-star spa. Pure Roman glamour.",
        site: "https://www.roccofortehotels.com/hotels-and-resorts/hotel-de-russie",
      },
    ],
  },

  // ── SORRENTO ──────────────────────────────────────────────────────────
  Sorrento: {
    ci: "2026-06-05", co: "2026-06-09", n: 4, st: "needed",
    note: "June is the sweet spot — Capri and Amalfi busy but not overwhelming. Book early, clifftop rooms sell out.",
    opts: [
      {
        nm: "Grand Hotel Excelsior Vittoria", q: "Grand Hotel Excelsior Vittoria Sorrento", s: 5,
        nzd: 1110, eur: 595, tier: "luxury", hood: "Clifftop Centro",
        perks: ["Historic 5-star since 1834", "Michelin-starred Terrazza Bosquet", "Lush gardens & pool over the Bay", "Direct Capri ferry views"],
        v: "The #1 rated hotel in Sorrento. Wagner, Caruso and Pavarotti stayed here. Unforgettable clifftop gardens.",
        site: "https://www.exvitt.it",
      },
      {
        nm: "Hilton Sorrento Palace", q: "Hilton Sorrento Palace", s: 4,
        nzd: 650, eur: 350, tier: "mid", hood: "Via Califano hillside",
        perks: ["6 outdoor pools", "Vesuvius panorama", "Spa & fitness", "Walking distance from Piazza Tasso"],
        v: "Best value luxury in Sorrento. Six pools on a hillside with unbeatable Vesuvius and bay views.",
        site: "https://www.hiltonsorrento.com",
      },
      {
        nm: "Hotel Loreley", q: "Hotel Loreley Sorrento", s: 3,
        nzd: 320, eur: 170, tier: "budget", hood: "Marina Piccola",
        perks: ["Direct sea access via lift", "Terrace over the water", "Family-run charm", "Walk to ferries"],
        v: "Sorrento's best-kept secret. Small family hotel with a terrace right over the sea. Book room with balcony.",
        site: "https://www.loreley.it",
      },
      {
        nm: "Bellevue Syrene", q: "Bellevue Syrene Sorrento", s: 5,
        nzd: 1200, eur: 645, tier: "luxury", hood: "Marina Piccola clifftop",
        perks: ["Built on Roman ruins (1st century)", "Clifftop solarium with Bay of Naples views", "Private lift to beach club", "Only 18 rooms — very intimate"],
        v: "Built on Roman ruins. Only 18 rooms. The most exclusive stay in Sorrento — completely booked out by May.",
        site: "https://www.bellevue.it",
      },
    ],
  },

  // ── ROME (FINAL NIGHT) ────────────────────────────────────────────────
  "Rome Final": {
    ci: "2026-06-09", co: "2026-06-10", n: 1, st: "needed",
    note: "Last night before Fiumicino. Prioritise near Termini or EUR for easy airport access next morning.",
    opts: [
      {
        nm: "Same Rome hotel as Jun 3–5", q: "", s: 0, nzd: 0, eur: 0,
        tier: "mid", hood: "Same as before",
        perks: ["Already know it", "No re-orientation needed"],
        v: "Simplest option — rebook your earlier Rome hotel for the final night.", rb: true,
      },
      {
        nm: "iQ Hotel Roma", q: "iQ Hotel Roma Termini", s: 4,
        nzd: 490, eur: 265, tier: "mid", hood: "Near Termini",
        perks: ["5-min walk to Termini", "Leonardo Express from Termini in 32min", "Pool & gym", "Modern design"],
        v: "Smart 4-star close to Termini. Practical for early departures, unexpectedly stylish.",
        site: "https://www.iqhotelroma.it",
      },
      {
        nm: "Hotel Artemide", q: "Hotel Artemide Rome Termini", s: 4,
        nzd: 420, eur: 225, tier: "mid", hood: "Via Nazionale (Termini)",
        perks: ["Historic palazzo on Via Nazionale", "Rooftop restaurant", "500m from Termini", "Free minibar"],
        v: "Belle époque palazzo near Termini. Rooftop dining, excellent breakfasts, very friendly staff.",
        site: "https://www.hotelartemide.it",
      },
    ],
  },
};

export interface TransportDay {
  ic: string;
  s: string;
  d: string;
  t: string;
}

export interface RouteOption {
  mode: string;
  detail: string;
  cost: string;
  lnk?: string;
}

export interface RouteDay {
  from: string;
  to: string;
  opts: RouteOption[];
}

export interface GemItem {
  cat: "must" | "wow" | "gem";
  n: string;
  d: string;
  map?: string;
  lnk?: string;
}

export interface FoodItem {
  dish: string;
  tip: string;
  kind: string;
}

export interface Phrase {
  it: string;
  en: string;
}

export const TRANSPORT: Record<string, TransportDay> = {
  "25/05/26": { ic: "A", s: "Arrive Malpensa 6:30am", d: "Malpensa Express to Centrale (50min, ~€13). Taxi ~€100.", t: "Milan = walk + metro. No car needed." },
  "27/05/26": { ic: "T", s: "Milan → Como train (40min)", d: "Train €5–13. Buy free circulation ferry ticket.", t: "Train + ferry is the way." },
  "28/05/26": { ic: "D", s: "Milan → Garda: 1.5–2hr (A4)", d: "A4 east, tolls ~€12. Stop Sirmione en route. RENT CAR here.", t: "Pick up car Milan, drop Rome airport 10/06." },
  "29/05/26": { ic: "F", s: "Explore by ferry, not car", d: "Park car, ferry between towns. Garda→Malcesine ~50min.", t: "Ferry between towns. Parking is terrible." },
  "30/05/26": { ic: "D", s: "Garda → Florence: 3hr", d: "⚠ ZTL: Florence centre = camera fines! Park outside.", t: "Florence = walking city. Park & forget the car." },
  "01/06/26": { ic: "D", s: "Florence → Tuscany: 1–1.5hr", d: "SS222 Chiantigiana through Chianti — Italy's best drive.", t: "Car essential. Hill towns impossible by bus." },
  "03/06/26": { ic: "D", s: "Tuscany → Rome: 2.5–3hr", d: "Stop Orvieto en route: hilltop cathedral, caves, white wine.", t: "Don't drive in Rome. Park at hotel." },
  "05/06/26": { ic: "D", s: "Rome → Pompeii → Sorrento: 3.5hr", d: "A1 south, visit Pompeii, 30min to Sorrento.", t: "Consider dropping rental in Sorrento." },
  "06/06/26": { ic: "F", s: "Sorrento → Amalfi: ferry 1hr", d: "Ferry ~€10. Coast road = stressful + €30 parking.", t: "Take the ferry!" },
  "07/06/26": { ic: "B", s: "Sorrento → Positano: bus 40min", d: "SITA bus €2.50 for cliff views. Ferry back.", t: "Bus there, ferry back = perfect." },
  "08/06/26": { ic: "F", s: "Sorrento → Capri: ferry 25min", d: "First ferry 7:25am. ~€22 each way.", t: "No cars on Capri." },
  "09/06/26": { ic: "D", s: "Sorrento → Rome: 3.5hr", d: "Or train: Circumvesuviana + Frecciarossa (70min, €25).", t: "Return car at Fiumicino." },
  "10/06/26": { ic: "A", s: "Hotel → Fiumicino", d: "Leonardo Express 32min €14. Taxi ~€50.", t: "Don't risk delays." },
};

export const ROUTES: Record<string, RouteDay> = {
  "28/05/26": {
    from: "Milan", to: "Lake Garda",
    opts: [
      { mode: "Car rental", detail: "Pick up Milan Centrale. Hertz/Europcar/Sixt. Drop Rome Fiumicino 10/06.", cost: "€400–600 total", lnk: "https://www.rentalcars.com/SearchResults.do?country=Italy&pick=Milan&drop=Rome+Fiumicino" },
      { mode: "A4 Motorway", detail: "1.5–2hr. Tolls ~€12. Stop at Sirmione peninsula en route.", cost: "€12 tolls + fuel" },
      { mode: "Train alternative", detail: "Milano Centrale → Desenzano del Garda (55min, Trenitalia).", cost: "€15–25", lnk: "https://www.trenitalia.com/en.html" },
    ],
  },
  "30/05/26": {
    from: "Lake Garda", to: "Florence",
    opts: [
      { mode: "A22 + A1 Motorway", detail: "3hr. Verona→Bologna→Florence. Tolls ~€25.", cost: "€25 tolls + fuel" },
      { mode: "Park in Florence", detail: "⚠ Do NOT drive into centre. Use Garage Europa or Parcheggio Beccaria.", cost: "€20–30/day", lnk: "https://maps.google.com/?q=Garage+Europa+Florence" },
    ],
  },
  "01/06/26": {
    from: "Florence", to: "Tuscany",
    opts: [
      { mode: "SS222 Chiantigiana", detail: "The famous Chianti wine road. Slower but stunning. 1–1.5hr.", cost: "Free" },
      { mode: "Superstrada (FI-SI)", detail: "Fast route to Siena, 1hr. Then local roads to your stay.", cost: "Free" },
    ],
  },
  "03/06/26": {
    from: "Tuscany", to: "Rome",
    opts: [
      { mode: "A1 Autostrada", detail: "2.5–3hr via Orvieto. Stop for lunch — cathedral + white wine.", cost: "€20 tolls + fuel" },
      { mode: "Park in Rome", detail: "Use hotel garage or Parcheggio Ludovisi. Do NOT drive in centre.", cost: "€25–40/day", lnk: "https://maps.google.com/?q=Parcheggio+Ludovisi+Rome" },
    ],
  },
  "05/06/26": {
    from: "Rome", to: "Sorrento",
    opts: [
      { mode: "Drive via Pompeii", detail: "A1 south 2.5hr to Pompeii, then 30min to Sorrento.", cost: "€18 tolls + fuel" },
      { mode: "Train (no car)", detail: "Frecciarossa Roma→Napoli (70min, €25) + Circumvesuviana to Sorrento (65min, €4).", cost: "€29 pp", lnk: "https://www.trenitalia.com/en.html" },
      { mode: "Drop car in Sorrento?", detail: "Sorrento has parking. You won't need a car for 4 days of ferries. Could save €100+.", cost: "" },
    ],
  },
  "09/06/26": {
    from: "Sorrento", to: "Rome",
    opts: [
      { mode: "Drive A1 north", detail: "3.5hr. Return car at Fiumicino for easy airport access next day.", cost: "€15 tolls + fuel" },
      { mode: "Train", detail: "Circumvesuviana → Napoli Centrale + Frecciarossa → Roma. Total ~2.5hr.", cost: "€29 pp", lnk: "https://www.trenitalia.com/en.html" },
    ],
  },
  "10/06/26": {
    from: "Rome", to: "Airport",
    opts: [
      { mode: "Leonardo Express", detail: "Roma Termini → Fiumicino. Every 15min. 32min non-stop.", cost: "€14 pp", lnk: "https://www.trenitalia.com/en.html" },
      { mode: "Taxi", detail: "Fixed rate Roma centre → Fiumicino. 30–50min depending on traffic.", cost: "€50 fixed" },
      { mode: "Private transfer", detail: "Pre-book for hotel pickup. No stress on departure day.", cost: "€60–80", lnk: "https://www.getyourguide.com/rome-l33/airport-transfer-tc167/" },
    ],
  },
};

export const GEMS: Record<string, GemItem[]> = {
  Milan: [
    { cat: "must", n: "Duomo rooftop at sunset", d: "The marble glows pink. Best view in Milan.", map: "https://maps.google.com/?q=Duomo+di+Milano" },
    { cat: "wow", n: "San Bernardino alle Ossa", d: "Bone chapel covered in skulls, 5min from Duomo. Tourists walk right past.", map: "https://maps.google.com/?q=San+Bernardino+alle+Ossa+Milan" },
    { cat: "gem", n: "Navigli sunset aperitivo", d: "€8–12 for a drink and unlimited buffet. Canals glow golden.", map: "https://maps.google.com/?q=Navigli+District+Milan" },
    { cat: "wow", n: "Last Supper", d: "15 people allowed every 15 min. Life-changing art. Book months ahead.", lnk: "https://www.getyourguide.com/milan-l139/last-supper-tickets-tc24/" },
  ],
  "Lake Garda": [
    { cat: "wow", n: "Madonna della Corona", d: "Church built INTO a cliff at 775m. Free. Italy's most dramatic sight.", map: "https://maps.google.com/?q=Santuario+Madonna+della+Corona" },
    { cat: "must", n: "Monte Baldo cable car", d: "Rotating cabin, 360° views. Paragliders launch from the top.", lnk: "https://www.getyourguide.com/lake-garda-l901/monte-baldo-tc284/" },
    { cat: "gem", n: "Limonaia del Castèl, Limone", d: "1700s lemon terraces on cliffs. Fresh limoncello tasting.", map: "https://maps.google.com/?q=Limonaia+del+Castel+Limone+sul+Garda" },
    { cat: "must", n: "Verona — Arena + Juliet", d: "45min away. Roman amphitheatre, Juliet's balcony, wine bars.", map: "https://maps.google.com/?q=Arena+di+Verona" },
  ],
  Florence: [
    { cat: "must", n: "Piazzale Michelangelo golden hour", d: "Bring Aperol Spritz. Sky turns pink behind the Duomo. Unforgettable.", map: "https://maps.google.com/?q=Piazzale+Michelangelo+Florence" },
    { cat: "wow", n: "Officina Santa Maria Novella", d: "World's oldest pharmacy (1221). Frescoed rooms, perfumes, elixirs. Free.", map: "https://maps.google.com/?q=Officina+Profumo+Farmaceutica+Santa+Maria+Novella" },
    { cat: "gem", n: "Bardini Gardens", d: "Skip crowded Boboli. Same views, almost nobody. Wisteria tunnel in late May!", map: "https://maps.google.com/?q=Giardino+Bardini+Florence" },
    { cat: "must", n: "Giotto's Bell Tower", d: "Better than climbing Duomo — because you GET the Duomo in your photo.", lnk: "https://www.getyourguide.com/florence-l32/duomo-complex-tc386/" },
  ],
  Tuscany: [
    { cat: "wow", n: "Bagno Vignoni hot springs", d: "Medieval village around a thermal pool. Free natural springs in the river below.", map: "https://maps.google.com/?q=Bagno+Vignoni" },
    { cat: "must", n: "Dario Cecchini, Panzano", d: "World's most famous butcher. €50 feast with unlimited wine. Book ahead.", map: "https://maps.google.com/?q=Dario+Cecchini+Panzano" },
    { cat: "gem", n: "Certaldo Alto", d: "Funicular to medieval hilltop. Terracotta, barely any tourists.", map: "https://maps.google.com/?q=Certaldo+Alto" },
    { cat: "wow", n: "Val d'Orcia at golden hour", d: "Drive the cypress-lined roads at sunset. THE Tuscan postcard. Stop and breathe.", map: "https://maps.google.com/?q=Val+d+Orcia" },
  ],
  Rome: [
    { cat: "wow", n: "Aventine Keyhole", d: "Peer through Knights of Malta gate — St Peter's dome framed by hedges. Free. Magical.", map: "https://maps.google.com/?q=Buco+della+Serratura+Rome" },
    { cat: "gem", n: "Quartiere Coppedè", d: "Fairy-tale Art Nouveau neighborhood. Gargoyles, turrets, mosaics. Zero tourists.", map: "https://maps.google.com/?q=Quartiere+Coppede+Rome" },
    { cat: "must", n: "San Clemente — 3 layers", d: "Descend: 12th-c church → 4th-c church → 1st-c Roman house. Mind-blowing. €10.", map: "https://maps.google.com/?q=Basilica+di+San+Clemente+Rome" },
    { cat: "must", n: "Trastevere after dark", d: "Cobblestone streets, live music, candlelit dinners. The most romantic Rome.", map: "https://maps.google.com/?q=Trastevere+Rome" },
  ],
  Sorrento: [
    { cat: "wow", n: "Path of the Gods hike", d: "Walk 300m cliffs above the Amalfi Coast. Starts Agerola, ends above Positano. 3–4hr.", map: "https://maps.google.com/?q=Sentiero+degli+Dei+Agerola" },
    { cat: "gem", n: "Procida Island", d: "Talented Mr Ripley island. Colourful, zero tourists. Fraction of Capri's price.", map: "https://maps.google.com/?q=Procida+Italy" },
    { cat: "wow", n: "Fjord of Furore", d: "Hidden beach in a dramatic gorge. Italy's only fjord. Stairs from the bridge.", map: "https://maps.google.com/?q=Fiordo+di+Furore" },
    { cat: "must", n: "Valley of the Mills, Sorrento", d: "Collapsed gorge with jungle-reclaimed 13th-c mills. Public viewpoint.", map: "https://maps.google.com/?q=Vallone+dei+Mulini+Sorrento" },
    { cat: "gem", n: "Herculaneum (not Pompeii)", d: "Better preserved, far fewer crowds. Wooden furniture survived. 20min by train.", lnk: "https://www.getyourguide.com/herculaneum-l2619/" },
  ],
};

export const FOOD: Record<string, FoodItem[]> = {
  Milan: [
    { dish: "Risotto alla Milanese", tip: "Saffron rice, bone marrow. Try Trattoria Masuelli.", kind: "S" },
    { dish: "Cotoletta alla Milanese", tip: "Massive breaded veal cutlet fried in butter.", kind: "M" },
    { dish: "Panzerotti at Luini", tip: "Deep-fried stuffed dough near Duomo. €3. Queue worth it.", kind: "St" },
    { dish: "Aperitivo = dinner", tip: "€8–12 drink + unlimited buffet. Navigli bars 6–9pm.", kind: "Tip" },
  ],
  "Lake Garda": [
    { dish: "Bigoli con le sarde", tip: "Thick pasta with lake sardines. Only found here.", kind: "S" },
    { dish: "Tortellini di Valeggio", tip: "Handmade pasta from Valeggio sul Mincio.", kind: "M" },
    { dish: "Olive oil tasting", tip: "Italy's most northern olive oil. Visit a frantoio.", kind: "Tip" },
  ],
  Florence: [
    { dish: "Bistecca alla Fiorentina", tip: "Massive T-bone, served rare. Sostanza or Buca Mario.", kind: "S" },
    { dish: "Lampredotto", tip: "Tripe sandwich from a cart. €5 at Sant'Ambrogio.", kind: "St" },
    { dish: "Ribollita", tip: "Thick bread & vegetable soup. Peasant perfection.", kind: "M" },
    { dish: "Gelato at Vivoli", tip: "Skip neon-coloured tourist gelato. Natural colours only.", kind: "Tip" },
  ],
  Tuscany: [
    { dish: "Pici cacio e pepe", tip: "Fat hand-rolled pasta with pecorino. Pienza does it best.", kind: "S" },
    { dish: "Wild boar ragù", tip: "Slow-cooked cinghiale on pappardelle. Available everywhere in Chianti.", kind: "M" },
    { dish: "Pecorino di Pienza", tip: "Sample aged, semi-aged, fresh. Pair with honey and walnuts.", kind: "M" },
    { dish: "Dario Cecchini feast", tip: "€50 set menu + unlimited wine. Book ahead!", kind: "Tip" },
  ],
  Rome: [
    { dish: "Cacio e Pepe", tip: "Pecorino + black pepper pasta. Roma Sparita or Roscioli.", kind: "S" },
    { dish: "Supplì", tip: "Fried rice balls, melting mozzarella inside. €2 at Testaccio.", kind: "St" },
    { dish: "Carbonara", tip: "Egg, guanciale, pecorino. NEVER cream. Da Enzo, Trastevere.", kind: "M" },
    { dish: "Avoid landmark restaurants", tip: "3 blocks from the Colosseum = 10x better food.", kind: "Tip" },
  ],
  Sorrento: [
    { dish: "Scialatielli ai limoni", tip: "Flat pasta with Sorrento lemons, butter, basil. Only here.", kind: "S" },
    { dish: "Delizia al limone", tip: "Lemon sponge cake in limoncello cream. The Amalfi dessert.", kind: "M" },
    { dish: "Sfogliatella", tip: "Crispy shell pastry with ricotta. Best warm from a bakery.", kind: "St" },
    { dish: "Fish lunch in Minori", tip: "Half the price of Positano. Double the quality.", kind: "Tip" },
  ],
};

export const PHRASES: Phrase[] = [
  { it: "Buongiorno / Buonasera", en: "Good morning / evening" },
  { it: "Un tavolo per due, per favore", en: "A table for two, please" },
  { it: "Il conto, per favore", en: "The bill, please" },
  { it: "Che cosa mi consiglia?", en: "What do you recommend?" },
  { it: "Salute!", en: "Cheers!" },
  { it: "È buonissimo!", en: "It's delicious!" },
  { it: "Quanto costa?", en: "How much?" },
  { it: "Grazie mille", en: "Thank you so much" },
  { it: "Scusi / Permesso", en: "Excuse me / May I pass" },
  { it: "Vorrei un Aperol Spritz", en: "I'd like an Aperol Spritz" },
];

export const DAYS: Day[] = [
  { dt: "25/05/26", dy: "Sun", act: "Arrive Milan (6:30am)", stay: "Crowne Plaza ✓", rg: "Milan", sg: [
    { nm: "Navigli District", c: 0, tp: "free", bk: false, nt: "Canalside walk, first espresso" },
    { nm: "Duomo Rooftop Terraces", c: 22, tp: "ticket", bk: false, nt: "Book elevator, sunset views" },
    { nm: "Aperitivo Galleria V. Emanuele", c: 15, tp: "food", bk: false, nt: "World's oldest shopping mall" },
  ]},
  { dt: "26/05/26", dy: "Mon", act: "Explore Milan", stay: "Crowne Plaza ✓", rg: "Milan", sg: [
    { nm: "The Last Supper", c: 15, tp: "ticket", bk: false, nt: "⚠ BOOK NOW — sells out months ahead", lnk: "https://www.getyourguide.com/milan-l139/last-supper-tickets-tc24/" },
    { nm: "Sforza Castle & Brera", c: 15, tp: "ticket", bk: false, nt: "Renaissance masterpieces", map: "https://maps.google.com/?q=Castello+Sforzesco+Milan" },
    { nm: "Pasta Cooking Class", c: 65, tp: "experience", bk: false, nt: "Learn risotto alla Milanese", lnk: "https://www.getyourguide.com/milan-l139/cooking-class-tc70/" },
    { nm: "La Scala Museum", c: 12, tp: "ticket", bk: false, nt: "Europe's finest opera house", lnk: "https://www.getyourguide.com/milan-l139/la-scala-tc390/" },
  ]},
  { dt: "27/05/26", dy: "Tue", act: "Day trip Como", stay: "Crowne Plaza ✓", rg: "Milan", sg: [
    { nm: "Ferry Como→Bellagio→Varenna", c: 20, tp: "transport", bk: false, nt: "Golden Triangle route" },
    { nm: "Villa del Balbianello", c: 13, tp: "ticket", bk: false, nt: "Star Wars & Bond location" },
    { nm: "Lunch in Bellagio", c: 35, tp: "food", bk: false, nt: "Book ahead" },
    { nm: "Como-Brunate Funicular", c: 6, tp: "transport", bk: false, nt: "Panoramic ride" },
  ]},
  { dt: "28/05/26", dy: "Wed", act: "Drive to Garda (1.5–2hr)", stay: "— Needs booking", rg: "Lake Garda", sg: [
    { nm: "Sirmione stop en route", c: 25, tp: "ticket", bk: false, nt: "Scaligero Castle + Roman ruins" },
    { nm: "Explore Garda lakefront", c: 0, tp: "free", bk: false, nt: "Palazzo dei Capitani, sunset walk" },
    { nm: "Bardolino wine dinner", c: 40, tp: "food", bk: false, nt: "Eastern shore wines" },
  ]},
  { dt: "29/05/26", dy: "Thu", act: "Explore Garda", stay: "— Needs booking", rg: "Lake Garda", sg: [
    { nm: "Punta San Vigilio beach", c: 8, tp: "ticket", bk: false, nt: "Mermaids' Bay" },
    { nm: "Monte Baldo Cable Car", c: 22, tp: "experience", bk: false, nt: "360° rotating, alpine views", lnk: "https://www.getyourguide.com/lake-garda-l901/monte-baldo-tc284/" },
    { nm: "Ferry to Limone", c: 15, tp: "transport", bk: false, nt: "Lemon groves + bike path" },
    { nm: "Verona day trip (45min)", c: 0, tp: "free", bk: false, nt: "Roman Arena, Juliet balcony", map: "https://maps.google.com/?q=Arena+di+Verona" },
  ]},
  { dt: "30/05/26", dy: "Fri", act: "Drive to Florence (3hr)", stay: "— Needs booking", rg: "Florence", sg: [
    { nm: "Piazzale Michelangelo sunset", c: 0, tp: "free", bk: false, nt: "Best view + Aperol Spritz", map: "https://maps.google.com/?q=Piazzale+Michelangelo+Florence" },
    { nm: "Ponte Vecchio & Oltrarno", c: 0, tp: "free", bk: false, nt: "Artisan shops, less touristy" },
    { nm: "Bistecca alla Fiorentina", c: 50, tp: "food", bk: false, nt: "Massive T-bone, must-try" },
  ]},
  { dt: "31/05/26", dy: "Sat", act: "Explore Florence", stay: "— Needs booking", rg: "Florence", sg: [
    { nm: "Accademia (David)", c: 20, tp: "ticket", bk: false, nt: "⚠ PRE-BOOK skip-the-line", lnk: "https://www.getyourguide.com/florence-l32/accademia-gallery-tc51/" },
    { nm: "Uffizi Gallery", c: 25, tp: "ticket", bk: false, nt: "⚠ PRE-BOOK — Italy's top museum", lnk: "https://www.getyourguide.com/florence-l32/uffizi-gallery-tc50/" },
    { nm: "Giotto's Bell Tower", c: 15, tp: "ticket", bk: false, nt: "Best Duomo photo angle", lnk: "https://www.getyourguide.com/florence-l32/duomo-complex-tc386/" },
    { nm: "San Lorenzo Market", c: 0, tp: "free", bk: false, nt: "Leather bargains", map: "https://maps.google.com/?q=Mercato+San+Lorenzo+Florence" },
  ]},
  { dt: "01/06/26", dy: "Sun", act: "Drive to Tuscany (1–1.5hr)", stay: "— Needs booking", rg: "Tuscany", sg: [
    { nm: "Chianti wine tour", c: 55, tp: "experience", bk: false, nt: "Rolling hills, world-class", lnk: "https://www.getyourguide.com/florence-l32/chianti-wine-tour-tc71/" },
    { nm: "San Gimignano towers", c: 0, tp: "free", bk: false, nt: "UNESCO, gelato champion", map: "https://maps.google.com/?q=San+Gimignano" },
    { nm: "Siena Piazza del Campo", c: 0, tp: "free", bk: false, nt: "Shell-shaped square", map: "https://maps.google.com/?q=Piazza+del+Campo+Siena" },
  ]},
  { dt: "02/06/26", dy: "Mon", act: "Explore Tuscany", stay: "— Needs booking", rg: "Tuscany", sg: [
    { nm: "Val d'Orcia drive", c: 0, tp: "free", bk: false, nt: "Iconic cypress roads" },
    { nm: "Montepulciano wine", c: 20, tp: "experience", bk: false, nt: "Vino Nobile hilltop" },
    { nm: "Pienza cheese", c: 10, tp: "food", bk: false, nt: "Pecorino + Renaissance city" },
    { nm: "Truffle hunting", c: 80, tp: "experience", bk: false, nt: "With a truffle dog!" },
  ]},
  { dt: "03/06/26", dy: "Tue", act: "Drive to Rome (2.5–3hr)", stay: "— Needs booking", rg: "Rome", sg: [
    { nm: "Orvieto stop en route", c: 0, tp: "free", bk: false, nt: "Cathedral, caves, white wine", map: "https://maps.google.com/?q=Orvieto+Cathedral" },
    { nm: "Trastevere evening", c: 0, tp: "free", bk: false, nt: "Best food neighbourhood" },
    { nm: "Trevi Fountain (after 9pm)", c: 0, tp: "free", bk: false, nt: "Fewer crowds" },
    { nm: "Trastevere dinner", c: 35, tp: "food", bk: false, nt: "Authentic trattorias" },
  ]},
  { dt: "04/06/26", dy: "Wed", act: "Explore Rome", stay: "— Needs booking", rg: "Rome", sg: [
    { nm: "Colosseum + Forum", c: 18, tp: "ticket", bk: false, nt: "⚠ PRE-BOOK combined ticket", lnk: "https://www.getyourguide.com/rome-l33/colosseum-tc10/" },
    { nm: "Vatican & Sistine", c: 20, tp: "ticket", bk: false, nt: "⚠ PRE-BOOK — go early", lnk: "https://www.getyourguide.com/rome-l33/vatican-museums-tc46/" },
    { nm: "Pantheon", c: 5, tp: "ticket", bk: false, nt: "Best Roman building", map: "https://maps.google.com/?q=Pantheon+Rome" },
    { nm: "Gelato Giolitti", c: 5, tp: "food", bk: false, nt: "Famous since 1890", map: "https://maps.google.com/?q=Giolitti+Rome" },
  ]},
  { dt: "05/06/26", dy: "Thu", act: "Rome→Pompeii→Sorrento", stay: "— Needs booking", rg: "Sorrento", sg: [
    { nm: "Pompeii", c: 18, tp: "ticket", bk: false, nt: "⚠ PRE-BOOK — allow 3+ hours", lnk: "https://www.getyourguide.com/pompeii-l616/pompeii-tickets-tc1/" },
    { nm: "Guided Pompeii tour", c: 45, tp: "experience", bk: false, nt: "Hidden details worth it", lnk: "https://www.getyourguide.com/pompeii-l616/guided-tour-tc2/" },
    { nm: "Sorrento passeggiata", c: 0, tp: "free", bk: false, nt: "Piazza Tasso, limoncello", map: "https://maps.google.com/?q=Piazza+Tasso+Sorrento" },
  ]},
  { dt: "06/06/26", dy: "Fri", act: "Ferry to Amalfi (1hr)", stay: "— Needs booking", rg: "Sorrento", sg: [
    { nm: "Ferry Sorrento→Amalfi", c: 10, tp: "transport", bk: false, nt: "Way better than driving" },
    { nm: "Amalfi Cathedral", c: 3, tp: "ticket", bk: false, nt: "Stunning 9th-century" },
    { nm: "Seafood lunch, sea view", c: 40, tp: "food", bk: false, nt: "Lemon everything" },
  ]},
  { dt: "07/06/26", dy: "Sat", act: "Positano (bus + ferry)", stay: "— Needs booking", rg: "Sorrento", sg: [
    { nm: "Path of the Gods", c: 0, tp: "free", bk: false, nt: "Cliffside trail, 3–4hr", map: "https://maps.google.com/?q=Sentiero+degli+Dei+Agerola" },
    { nm: "Spiaggia Grande", c: 20, tp: "experience", bk: false, nt: "Iconic colourful backdrop" },
    { nm: "Coast boat tour", c: 50, tp: "experience", bk: false, nt: "Hidden coves, Fjord of Furore" },
  ]},
  { dt: "08/06/26", dy: "Sun", act: "Ferry to Capri (25min)", stay: "— Needs booking", rg: "Sorrento", sg: [
    { nm: "Ferry Capri (7:25am!)", c: 25, tp: "transport", bk: false, nt: "Beat the crowds", lnk: "https://www.getyourguide.com/sorrento-l718/capri-ferry-tc324/" },
    { nm: "Blue Grotto", c: 18, tp: "ticket", bk: false, nt: "Magical cave, weather dep.", lnk: "https://www.getyourguide.com/capri-l256/blue-grotto-tc121/" },
    { nm: "Chairlift Monte Solaro", c: 12, tp: "experience", bk: false, nt: "360° island views" },
    { nm: "Lunch Piazzetta", c: 45, tp: "food", bk: false, nt: "People-watching capital" },
  ]},
  { dt: "09/06/26", dy: "Mon", act: "Travel to Rome (3.5hr)", stay: "— Needs booking", rg: "Rome", sg: [
    { nm: "Spanish Steps", c: 0, tp: "free", bk: false, nt: "Iconic steps, designer shops" },
    { nm: "Final Piazza Navona aperitivo", c: 15, tp: "food", bk: false, nt: "Bernini fountain, last night" },
  ]},
  { dt: "10/06/26", dy: "Tue", act: "Flight Auckland 1pm", stay: "—", rg: "Departure", sg: [
    { nm: "Roscioli Caffè", c: 5, tp: "food", bk: false, nt: "Last Roman coffee" },
  ]},
];
