// Shared types for trip sync
export type Profile = {
  id: string;
  display_name: string;
  trip_role: 'k' | 'a';
};
