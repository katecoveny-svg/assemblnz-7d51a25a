import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { DAYS } from '@/data/tripData';
import { DEFAULT_PACKING, PackingItem } from '@/components/trip/PackingView';
import { useAuth } from '@/contexts/AuthContext';
import type { Profile } from '@/types/trip';
import type { Expense } from '@/components/trip/ExpenseView';
import type { TripNote } from '@/components/trip/NotesView';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const db = supabase as any;

type Day = typeof DAYS[number] & { sg: (typeof DAYS[number]['sg'][number] & { bk: boolean })[] };
type PackingState = Record<string, PackingItem[]>;

export type CustomHotel = {
  nm: string;
  nzd: number;
  st?: 'none' | 'selected' | 'booked';
};

function freshDays(): Day[] {
  return DAYS.map(d => ({ ...d, sg: d.sg.map(sg => ({ ...sg })) })) as Day[];
}
function freshPacking(): PackingState {
  return Object.fromEntries(DEFAULT_PACKING.map(c => [c.id, c.items.map(i => ({ ...i, k: false, a: false }))]));
}

export function useTripSync() {
  const { user, tripRole } = useAuth();

  const [days,          setDays]          = useState<Day[]>(freshDays);
  const [votes,         setVotes]         = useState<Record<string, { k?: boolean; a?: boolean }>>({});
  const [alreadyBooked, setAlreadyBooked] = useState<Record<string, boolean>>({ Milan: true });
  const [selectedNzd,   setSelectedNzd]   = useState<Record<string, number>>({ Milan: 0 });
  const [customHotels,  setCustomHotels]  = useState<Record<string, CustomHotel>>({ Milan: { nm: 'Crowne Plaza', nzd: 0 } });
  const [packing,       setPacking]       = useState<PackingState>(freshPacking);
  const [expenses,      setExpenses]      = useState<Expense[]>([]);
  const [notes,         setNotes]         = useState<TripNote[]>([]);
  const [synced,        setSynced]        = useState(false);

  const profilesRef    = useRef<Profile[]>([]);
  const alreadyBookedRef = useRef<Record<string, boolean>>({ Milan: true });
  const selectedNzdRef   = useRef<Record<string, number>>({ Milan: 0 });
  const customHotelsRef  = useRef<Record<string, CustomHotel>>({ Milan: { nm: 'Crowne Plaza', nzd: 0 } });

  useEffect(() => { alreadyBookedRef.current = alreadyBooked; }, [alreadyBooked]);
  useEffect(() => { selectedNzdRef.current   = selectedNzd;   }, [selectedNzd]);
  useEffect(() => { customHotelsRef.current  = customHotels;  }, [customHotels]);

  // ── Initial load ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!user) return;

    async function loadAll() {
      const [
        { data: profs },
        { data: bookings },
        { data: voteRows },
        { data: hotels },
        { data: checks },
        { data: expenseRows },
        { data: noteRows },
      ] = await Promise.all([
        db.from('profiles').select('id, display_name, trip_role'),
        db.from('activity_bookings').select('*'),
        db.from('activity_votes').select('*'),
        db.from('hotel_state').select('*'),
        db.from('packing_checks').select('*'),
        db.from('expenses').select('*').order('expense_date', { ascending: false }),
        db.from('trip_notes').select('*').order('created_at', { ascending: false }),
      ]);

      profilesRef.current = (profs ?? []) as Profile[];

      if (bookings?.length) {
        setDays(prev => {
          const next = prev.map(d => ({ ...d, sg: d.sg.map(sg => ({ ...sg })) })) as Day[];
          for (const b of bookings) {
            if (next[b.day_index]?.sg[b.segment_index]) {
              next[b.day_index].sg[b.segment_index].bk = b.booked;
            }
          }
          return next;
        });
      }

      if (voteRows?.length) {
        const newVotes: Record<string, { k?: boolean; a?: boolean }> = {};
        for (const v of voteRows) {
          if (!v.voted) continue;
          const role = profilesRef.current.find(p => p.id === v.user_id)?.trip_role;
          if (!role) continue;
          const key = `${v.day_index}-${v.segment_index}`;
          if (!newVotes[key]) newVotes[key] = {};
          (newVotes[key] as Record<string, boolean>)[role] = true;
        }
        setVotes(newVotes);
      }

      if (hotels?.length) {
        const newBooked: Record<string, boolean>     = { Milan: true };
        const newSel:    Record<string, number>      = { Milan: 0 };
        const newCust:   Record<string, CustomHotel> = { Milan: { nm: 'Crowne Plaza', nzd: 0 } };
        for (const h of hotels) {
          if (h.already_booked) newBooked[h.region] = true;
          if (h.selected_nzd > 0) newSel[h.region] = h.selected_nzd;
          if (h.custom_name || h.custom_nzd > 0) {
            newCust[h.region] = { nm: h.custom_name, nzd: h.custom_nzd, st: h.custom_status };
          }
        }
        setAlreadyBooked(newBooked);
        setSelectedNzd(newSel);
        setCustomHotels(newCust);
      }

      if (checks?.length) {
        setPacking(prev => {
          const next: PackingState = Object.fromEntries(
            Object.entries(prev).map(([cid, items]) => [cid, items.map(i => ({ ...i, k: false, a: false }))])
          );
          for (const c of checks) {
            if (!c.checked) continue;
            const role = profilesRef.current.find(p => p.id === c.user_id)?.trip_role;
            if (!role) continue;
            const items = next[c.cat_id];
            if (!items) continue;
            const item = items.find((i: PackingItem) => i.id === c.item_id);
            if (item) (item as unknown as Record<string, unknown>)[role] = true;
          }
          return next;
        });
      }

      if (expenseRows?.length) {
        setExpenses(expenseRows as Expense[]);
      }

      if (noteRows?.length) {
        setNotes(noteRows as TripNote[]);
      }

      setSynced(true);
    }

    loadAll();
  }, [user]);

  // ── Realtime subscriptions ──────────────────────────────────────────────────
  useEffect(() => {
    if (!user || !synced) return;

    const channel = supabase.channel('trip-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'activity_bookings' }, (payload: { new: Record<string, unknown> }) => {
        const b = payload.new as { day_index: number; segment_index: number; booked: boolean };
        setDays(prev => {
          const next = prev.map(d => ({ ...d, sg: d.sg.map(sg => ({ ...sg })) })) as Day[];
          if (next[b.day_index]?.sg[b.segment_index]) {
            next[b.day_index].sg[b.segment_index].bk = b.booked;
          }
          return next;
        });
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'activity_votes' }, (payload: { new: Record<string, unknown> }) => {
        const v = payload.new as { user_id: string; day_index: number; segment_index: number; voted: boolean };
        const role = profilesRef.current.find(p => p.id === v.user_id)?.trip_role;
        if (!role) return;
        const key = `${v.day_index}-${v.segment_index}`;
        setVotes(prev => ({ ...prev, [key]: { ...prev[key], [role]: v.voted } }));
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'hotel_state' }, (payload: { new: Record<string, unknown> }) => {
        const h = payload.new as { region: string; already_booked: boolean; selected_nzd: number; custom_name: string; custom_nzd: number; custom_status: string };
        setAlreadyBooked(prev => ({ ...prev, [h.region]: h.already_booked }));
        setSelectedNzd(prev => ({ ...prev, [h.region]: h.selected_nzd }));
        setCustomHotels(prev => ({ ...prev, [h.region]: { nm: h.custom_name, nzd: h.custom_nzd, st: h.custom_status as CustomHotel['st'] } }));
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'packing_checks' }, (payload: { new: Record<string, unknown> }) => {
        const c = payload.new as { user_id: string; item_id: string; cat_id: string; checked: boolean };
        const role = profilesRef.current.find(p => p.id === c.user_id)?.trip_role;
        if (!role) return;
        setPacking(prev => ({
          ...prev,
          [c.cat_id]: (prev[c.cat_id] ?? []).map(item =>
            item.id === c.item_id ? { ...item, [role]: c.checked } : item
          ),
        }));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'expenses' }, (payload: { new: Record<string, unknown> }) => {
        setExpenses(prev => {
          // avoid duplicates (our own insert may trigger this)
          if (prev.some(e => e.id === (payload.new as Expense).id)) return prev;
          return [payload.new as Expense, ...prev];
        });
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'expenses' }, (payload: { old: Record<string, unknown> }) => {
        const old = payload.old as { id: string };
        setExpenses(prev => prev.filter(e => e.id !== old.id));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'trip_notes' }, (payload: { new: Record<string, unknown> }) => {
        setNotes(prev => {
          if (prev.some(n => n.id === (payload.new as TripNote).id)) return prev;
          return [payload.new as TripNote, ...prev];
        });
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'trip_notes' }, (payload: { new: Record<string, unknown> }) => {
        const updated = payload.new as TripNote;
        setNotes(prev => prev.map(n => n.id === updated.id ? updated : n));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'trip_notes' }, (payload: { old: Record<string, unknown> }) => {
        const old = payload.old as { id: string };
        setNotes(prev => prev.filter(n => n.id !== old.id));
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user, synced]);

  // ── Helpers ─────────────────────────────────────────────────────────────────
  const syncHotelFull = useCallback((
    region: string,
    booked: boolean,
    selNzd: number,
    cust: CustomHotel,
  ) => {
    db.from('hotel_state').upsert(
      {
        region,
        already_booked: booked,
        selected_nzd:   selNzd,
        custom_name:    cust.nm   ?? '',
        custom_nzd:     cust.nzd  ?? 0,
        custom_status:  cust.st   ?? 'none',
        updated_at:     new Date().toISOString(),
      },
      { onConflict: 'region' }
    ).then(() => {});
  }, []);

  // ── Handlers ───────────────────────────────────────────────────────────────

  const toggleActivity = useCallback((di: number, si: number) => {
    setDays(prev => {
      const next = prev.map(d => ({ ...d, sg: d.sg.map(sg => ({ ...sg })) })) as Day[];
      const newBk = !next[di].sg[si].bk;
      next[di].sg[si].bk = newBk;
      db.from('activity_bookings').upsert(
        { day_index: di, segment_index: si, booked: newBk, updated_at: new Date().toISOString() },
        { onConflict: 'day_index,segment_index' }
      ).then(() => {});
      return next;
    });
  }, []);

  const handleVote = useCallback((di: number, si: number, who: 'k' | 'a') => {
    if (who !== tripRole || !user) return;
    const key = `${di}-${si}`;
    setVotes(prev => {
      const cur = prev[key] ?? {};
      const newVal = !(cur as Record<string, boolean>)[who];
      db.from('activity_votes').upsert(
        { user_id: user.id, day_index: di, segment_index: si, voted: newVal, updated_at: new Date().toISOString() },
        { onConflict: 'user_id,day_index,segment_index' }
      ).then(() => {});
      return { ...prev, [key]: { ...cur, [who]: newVal } };
    });
  }, [tripRole, user]);

  const handleSetCustomHotel = useCallback((region: string, val: Partial<CustomHotel>) => {
    setCustomHotels(prev => {
      const h = { nm: '', nzd: 0, st: 'none' as const, ...(prev[region] ?? {}), ...val };
      const next = { ...prev, [region]: h };
      syncHotelFull(region, alreadyBookedRef.current[region] ?? false, selectedNzdRef.current[region] ?? 0, h);
      return next;
    });
  }, [syncHotelFull]);

  const handleSelectOption = useCallback((region: string, nzd: number) => {
    setSelectedNzd(prev => {
      const next = { ...prev, [region]: nzd };
      syncHotelFull(region, alreadyBookedRef.current[region] ?? false, nzd, customHotelsRef.current[region] ?? { nm: '', nzd: 0 });
      return next;
    });
  }, [syncHotelFull]);

  const handleMarkBooked = useCallback((region: string) => {
    setAlreadyBooked(prev => {
      const newVal = !prev[region];
      syncHotelFull(region, newVal, selectedNzdRef.current[region] ?? 0, customHotelsRef.current[region] ?? { nm: '', nzd: 0 });
      return { ...prev, [region]: newVal };
    });
  }, [syncHotelFull]);

  const handlePackingToggle = useCallback((catId: string, itemId: string, who: 'k' | 'a') => {
    if (who !== tripRole || !user) return;
    setPacking(prev => {
      const items = (prev[catId] ?? []).map(item => {
        if (item.id !== itemId) return item;
        const newVal = !(item as unknown as Record<string, unknown>)[who];
        db.from('packing_checks').upsert(
          { user_id: user.id, item_id: itemId, cat_id: catId, checked: newVal, updated_at: new Date().toISOString() },
          { onConflict: 'user_id,item_id' }
        ).then(() => {});
        return { ...item, [who]: newVal };
      });
      return { ...prev, [catId]: items };
    });
  }, [tripRole, user]);

  const handlePackingAdd = useCallback((catId: string, nm: string) => {
    const id = `custom-${catId}-${Date.now()}`;
    setPacking(prev => ({
      ...prev,
      [catId]: [...(prev[catId] ?? []), { id, nm, k: false, a: false }],
    }));
  }, []);

  const handlePackingRemove = useCallback((catId: string, itemId: string) => {
    setPacking(prev => ({
      ...prev,
      [catId]: (prev[catId] ?? []).filter(item => item.id !== itemId),
    }));
  }, []);

  // ── Expense handlers ────────────────────────────────────────────────────────

  const handleAddExpense = useCallback(async (exp: Omit<Expense, 'id' | 'created_by'>) => {
    if (!user) return;
    const { data } = await db.from('expenses').insert({
      amount_eur:   exp.amount_eur,
      category:     exp.category,
      paid_by:      exp.paid_by,
      description:  exp.description,
      expense_date: exp.expense_date,
      created_by:   user.id,
    }).select().single();
    if (data) {
      setExpenses(prev => [data as Expense, ...prev]);
    }
  }, [user]);

  const handleDeleteExpense = useCallback(async (id: string) => {
    await db.from('expenses').delete().eq('id', id);
    setExpenses(prev => prev.filter(e => e.id !== id));
  }, []);

  // ── Note handlers ───────────────────────────────────────────────────────────

  const handleAddNote = useCallback(async (note: Omit<TripNote, 'id' | 'created_by' | 'created_at'>) => {
    if (!user) return;
    const { data } = await db.from('trip_notes').insert({
      day_index:  note.day_index,
      content:    note.content,
      created_by: user.id,
    }).select().single();
    if (data) {
      setNotes(prev => [data as TripNote, ...prev]);
    }
  }, [user]);

  const handleUpdateNote = useCallback(async (id: string, content: string) => {
    await db.from('trip_notes').update({ content, updated_at: new Date().toISOString() }).eq('id', id);
    setNotes(prev => prev.map(n => n.id === id ? { ...n, content } : n));
  }, []);

  const handleDeleteNote = useCallback(async (id: string) => {
    await db.from('trip_notes').delete().eq('id', id);
    setNotes(prev => prev.filter(n => n.id !== id));
  }, []);

  return {
    days, votes, alreadyBooked, selectedNzd, customHotels, packing, expenses, notes, synced,
    toggleActivity, handleVote,
    handleSetCustomHotel, handleSelectOption, handleMarkBooked,
    handlePackingToggle, handlePackingAdd, handlePackingRemove,
    handleAddExpense, handleDeleteExpense,
    handleAddNote, handleUpdateNote, handleDeleteNote,
  };
}
