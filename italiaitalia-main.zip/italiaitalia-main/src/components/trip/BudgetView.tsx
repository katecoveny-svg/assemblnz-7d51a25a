import { Day, HOTELS, ActivityType } from "@/data/tripData";
import { cn } from "@/lib/utils";
import { Plane, Hotel, Train, Ticket, Utensils, Sparkles, Check, Circle, AlertCircle } from "lucide-react";

interface CustomHotel {
  nm: string;
  nzd: number;
  st?: "none" | "selected" | "booked";
}

interface Props {
  days: Day[];
  pax: number;
  setPax: (n: number) => void;
  customHotels: Record<string, CustomHotel>;
  selectedNzd: Record<string, number>;
  alreadyBooked: Record<string, boolean>;
  flightPerPax: number;
  customActs: Record<string, { c: number; tp: ActivityType }[]>;
}

export function BudgetView({ days, pax, setPax, customHotels, selectedNzd, alreadyBooked, flightPerPax, customActs }: Props) {
  const FLIGHT_TOTAL = flightPerPax * pax;
  const hotelEntries = Object.entries(HOTELS);

  const byCat: Record<string, number> = { ticket: 0, food: 0, experience: 0, transport: 0, free: 0 };
  days.forEach(d => d.sg.forEach(sg => { byCat[sg.tp] = (byCat[sg.tp] ?? 0) + sg.c; }));
  Object.values(customActs).forEach(arr => arr.forEach(ca => { byCat.experience = (byCat.experience ?? 0) + ca.c; }));

  const accomNzd = hotelEntries.reduce((s, [r, d]) => {
    const cNzd = customHotels[r]?.nzd ?? 0;
    const sNzd = selectedNzd[r] ?? 0;
    return s + Math.max(cNzd, sNzd) * d.n;
  }, 0);

  const actTotal = days.reduce((s, d) => s + d.sg.reduce((s2, a) => s2 + a.c, 0), 0);
  const grand = accomNzd > 0 ? FLIGHT_TOTAL + accomNzd + Math.round(actTotal * 1.85) : 0;

  const hBooked = hotelEntries.filter(([r, d]) => {
    const c = customHotels[r];
    return alreadyBooked[r] || d.st === "confirmed" || c?.st === "booked";
  }).length;
  const hSelected = hotelEntries.filter(([r]) => customHotels[r]?.st === "selected").length;

  const LINE = [
    { label: "Flights",               icon: <Plane className="w-3.5 h-3.5" />,   col: "bg-primary",      eur: null,             nzd: FLIGHT_TOTAL,                      detail: `${pax} pax × $${flightPerPax.toLocaleString()}` },
    { label: "Accommodation",         icon: <Hotel className="w-3.5 h-3.5" />,   col: "bg-gold",         eur: null,             nzd: accomNzd,                          detail: `${hBooked} booked, ${hSelected} selected, ${hotelEntries.length - hBooked - hSelected} pending · 16 nights` },
    { label: "Transport",             icon: <Train className="w-3.5 h-3.5" />,   col: "bg-brown",        eur: byCat.transport,  nzd: Math.round(byCat.transport * 1.85), detail: "Ferries, trains, cable cars" },
    { label: "Tickets & Attractions", icon: <Ticket className="w-3.5 h-3.5" />,  col: "bg-primary",      eur: byCat.ticket,     nzd: Math.round(byCat.ticket * 1.85),   detail: "Museums, galleries, monuments" },
    { label: "Food & Drink",          icon: <Utensils className="w-3.5 h-3.5" />,col: "bg-brown-light",  eur: byCat.food,       nzd: Math.round(byCat.food * 1.85),     detail: "Planned dining — budget €40–80/day on top" },
    { label: "Experiences",           icon: <Sparkles className="w-3.5 h-3.5" />,col: "bg-gold",         eur: byCat.experience, nzd: Math.round(byCat.experience * 1.85), detail: "Cooking classes, wine tours, boat trips" },
  ];

  return (
    <div className="space-y-4">
      <h2 className="text-xl italic font-light text-primary font-serif">Cost Tracker</h2>

      {/* pax selector */}
      <div className="bg-card rounded-xl border border-border p-4 flex items-center gap-3 flex-wrap shadow-sm">
        <span className="text-sm font-semibold text-warm">Travelers:</span>
        {[1, 2, 3, 4].map(n => (
          <button key={n} onClick={() => setPax(n)}
            className={cn("w-8 h-8 rounded-full border-2 text-sm font-bold transition-all",
              pax === n ? "bg-primary border-primary text-primary-foreground" : "border-border text-foreground hover:border-primary/40")}>
            {n}
          </button>
        ))}
        <span className="text-[11px] text-muted-foreground ml-1">× ${flightPerPax.toLocaleString()} = ${FLIGHT_TOTAL.toLocaleString()}</span>
      </div>

      {/* grand total */}
      <div className="bg-primary rounded-xl p-5 text-primary-foreground shadow-md">
        <div className="text-[10px] opacity-60 tracking-widest uppercase mb-1 font-sans">Grand Total (NZD)</div>
        <div className="text-4xl font-bold text-gold font-serif">
          {grand > 0 ? `$${grand.toLocaleString()}` : "Enter hotels to see total"}
        </div>
        {grand > 0 && <div className="text-[10px] opacity-50 mt-1">Flights + Accommodation + Activities (×1.85 NZD/EUR est.)</div>}
      </div>

      {/* breakdown */}
      <div>
        <div className="text-sm font-semibold text-warm mb-2">Breakdown</div>
        <div className="space-y-2">
          {LINE.map((cat, i) => (
            <div key={i} className="bg-card rounded-xl border border-border p-3 shadow-sm">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <span className={cn("w-7 h-7 rounded-lg flex items-center justify-center text-white flex-shrink-0", cat.col)}>
                    {cat.icon}
                  </span>
                  <div>
                    <div className="text-[13px] font-semibold">{cat.label}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{cat.detail}</div>
                  </div>
                </div>
                <div className="text-right">
                  {cat.eur !== null && <div className="text-[10px] text-muted-foreground">€{cat.eur}</div>}
                  <div className="text-base font-bold">{cat.nzd > 0 ? `$${cat.nzd.toLocaleString()}` : "—"}</div>
                  <div className="text-[9px] text-muted-foreground">NZD</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* daily tip */}
      <div className="bg-cream rounded-xl border border-border p-4">
        <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-2">Daily Budget Tip</div>
        <p className="text-[12px] text-warm leading-relaxed">
          The food & drink above only counts planned activities. Budget an extra <strong>€40–80/day</strong> for meals not listed
          (about <strong>$1,200–2,400 NZD</strong> for the trip).
          A coffee is €1.50, lunch €12–20, dinner €25–45 per person.
        </p>
      </div>

      {/* accommodation by stop */}
      <div>
        <div className="text-sm font-semibold text-warm mb-2">Accommodation by Stop</div>
        <div className="space-y-1.5">
          {hotelEntries.map(([r, d], i) => {
            const ch = customHotels[r]?.nzd ? customHotels[r] : null;
            const sn = selectedNzd[r] ?? 0;
            const pn = ch ? ch.nzd : sn;
            const tt = pn * d.n;
            const isBooked = alreadyBooked[r] || d.st === "confirmed" || ch?.st === "booked";
            const isSel = ch?.st === "selected";
            const bdrCol = isBooked ? "border-primary" : isSel ? "border-gold" : "border-burg-light";
            const stCol = isBooked ? "text-primary" : isSel ? "text-brown" : "text-burg-light";
            const StIcon = isBooked ? Check : isSel ? Circle : AlertCircle;
            const stLbl = isBooked ? "Booked" : isSel ? "Selected" : "Needed";
            return (
              <div key={i} className={cn("bg-card rounded-lg border-l-4 px-3 py-2.5 flex justify-between items-center text-[12px] shadow-sm", bdrCol)}>
                <div className="flex items-baseline gap-2">
                  <span className="font-semibold">{r}</span>
                  <span className="text-[10px] text-muted-foreground">{d.n}n</span>
                  {ch?.nm && <span className={cn("text-[10px]", stCol)}>· {ch.nm}</span>}
                </div>
                <div className="flex items-center gap-1.5">
                  {pn > 0 && <span className="font-bold">${tt.toLocaleString()}</span>}
                  <span className={cn("inline-flex items-center gap-0.5 text-[10px]", stCol)}>
                    <StIcon className="w-3 h-3" />{stLbl}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
