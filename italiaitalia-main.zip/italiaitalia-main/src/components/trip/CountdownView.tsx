import { useMemo } from "react";
import { HOTELS } from "@/data/tripData";
import { Plane, Hotel, CheckCircle2, ShoppingBag, AlertTriangle, Calendar, Star } from "lucide-react";
import { cn } from "@/lib/utils";

const DEPARTURE = new Date("2026-05-25T06:30:00+02:00"); // Arrive Milan 6:30am local

interface Props {
  days: { sg: { bk: boolean; nt?: string; nm?: string; lnk?: string }[] }[];
  alreadyBooked: Record<string, boolean>;
  customHotels: Record<string, { st?: string }>;
  packing: Record<string, { k?: boolean; a?: boolean }[]>;
  urgentCount: number;
  onNavigate?: (view: string) => void;
}

export function CountdownView({ days, alreadyBooked, customHotels, packing, urgentCount }: Props) {
  const now = new Date();
  const msLeft = DEPARTURE.getTime() - now.getTime();
  const daysLeft = Math.max(0, Math.floor(msLeft / (1000 * 60 * 60 * 24)));
  const hoursLeft = Math.max(0, Math.floor((msLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)));
  const isPast = msLeft <= 0;
  const isInProgress = now >= DEPARTURE && now <= new Date("2026-06-10T23:59:59");

  // Hotel progress
  const hotelEntries = Object.entries(HOTELS);
  const bookedHotels = hotelEntries.filter(([r, d]) => {
    const c = customHotels[r];
    return alreadyBooked[r] || d.st === "confirmed" || c?.st === "booked";
  }).length;
  const selectedHotels = hotelEntries.filter(([r]) => customHotels[r]?.st === "selected").length;
  const hotelPct = Math.round(((bookedHotels + selectedHotels * 0.5) / hotelEntries.length) * 100);

  // Activity progress
  const totalActs = days.reduce((s, d) => s + d.sg.length, 0);
  const bookedActs = days.reduce((s, d) => s + d.sg.filter(a => a.bk).length, 0);
  const actPct = totalActs > 0 ? Math.round((bookedActs / totalActs) * 100) : 0;

  // Packing progress (Kate's perspective — own items)
  const allPackItems = Object.values(packing).flat();
  const kPacked = allPackItems.filter(i => i.k).length;
  const aPacked = allPackItems.filter(i => i.a).length;
  const packPct = allPackItems.length > 0
    ? Math.round(((kPacked + aPacked) / (allPackItems.length * 2)) * 100)
    : 0;

  // Today's focus — most urgent booking
  const urgentItems = days.flatMap((d, di) =>
    d.sg
      .map((a, si) => ({ ...a, di, si }))
      .filter(a => a.nt?.includes("⚠") && !a.bk)
  );
  const topFocus = urgentItems[0];

  const rings = [
    {
      label: "Hotels",
      icon: <Hotel className="w-4 h-4" />,
      pct: hotelPct,
      detail: `${bookedHotels} booked, ${selectedHotels} selected of ${hotelEntries.length}`,
      col: "text-gold",
      stroke: "hsl(34,48%,56%)",
    },
    {
      label: "Activities",
      icon: <CheckCircle2 className="w-4 h-4" />,
      pct: actPct,
      detail: `${bookedActs} of ${totalActs} confirmed`,
      col: "text-primary",
      stroke: "hsl(345,54%,22%)",
    },
    {
      label: "Packing",
      icon: <ShoppingBag className="w-4 h-4" />,
      pct: packPct,
      detail: `${kPacked}+${aPacked} items checked`,
      col: "text-brown",
      stroke: "hsl(18,42%,26%)",
    },
  ];

  // Key upcoming milestones
  const milestones = useMemo(() => [
    { label: "Book Lake Garda hotel",   done: !!(alreadyBooked["Lake Garda"] || customHotels["Lake Garda"]?.st === "booked" || customHotels["Lake Garda"]?.st === "selected") },
    { label: "Book Florence hotel",     done: !!(alreadyBooked["Florence"]    || customHotels["Florence"]?.st    === "booked" || customHotels["Florence"]?.st    === "selected") },
    { label: "Book Tuscany hotel",      done: !!(alreadyBooked["Tuscany"]     || customHotels["Tuscany"]?.st     === "booked" || customHotels["Tuscany"]?.st     === "selected") },
    { label: "Book Rome hotel",         done: !!(alreadyBooked["Rome"]        || customHotels["Rome"]?.st        === "booked" || customHotels["Rome"]?.st        === "selected") },
    { label: "Book Sorrento hotel",     done: !!(alreadyBooked["Sorrento"]    || customHotels["Sorrento"]?.st    === "booked" || customHotels["Sorrento"]?.st    === "selected") },
    { label: "Start packing",           done: packPct > 5 },
    { label: "All urgent bookings done",done: urgentCount === 0 },
  ], [alreadyBooked, customHotels, packPct, urgentCount]);

  const milestonesDone = milestones.filter(m => m.done).length;

  return (
    <div className="space-y-5">
      {/* Hero countdown */}
      <div className={cn(
        "rounded-xl p-6 text-primary-foreground shadow-md text-center relative overflow-hidden",
        isInProgress ? "bg-gradient-to-br from-primary to-brown" : "bg-primary"
      )}>
        {/* decorative */}
        <div className="absolute inset-0 opacity-5 pointer-events-none">
          <div className="absolute top-2 right-4 text-[80px] leading-none select-none">🇮🇹</div>
        </div>

        <div className="relative">
          <div className="flex items-center justify-center gap-2 text-[10px] opacity-60 tracking-widest uppercase mb-3">
            <Plane className="w-3.5 h-3.5" />
            {isInProgress ? "Currently in Italy" : isPast ? "Trip complete" : "Until departure · Milan 25 May 2026"}
          </div>

          {isPast || isInProgress ? (
            <div className="text-4xl font-bold text-gold font-serif">
              {isInProgress ? "Buon viaggio! 🥂" : "Arrivederci! 🇮🇹"}
            </div>
          ) : (
            <>
              <div className="flex items-baseline justify-center gap-3">
                <div className="text-center">
                  <div className="text-5xl font-bold text-gold font-serif tabular-nums leading-none">{daysLeft}</div>
                  <div className="text-[10px] opacity-60 mt-1">days</div>
                </div>
                <div className="text-3xl opacity-30 font-light mb-2">:</div>
                <div className="text-center">
                  <div className="text-5xl font-bold text-gold font-serif tabular-nums leading-none">{String(hoursLeft).padStart(2, "0")}</div>
                  <div className="text-[10px] opacity-60 mt-1">hours</div>
                </div>
              </div>
              <div className="text-[11px] opacity-50 mt-3">
                {milestonesDone}/{milestones.length} pre-trip tasks done
              </div>
            </>
          )}
        </div>
      </div>

      {/* Progress rings */}
      <div className="grid grid-cols-3 gap-3">
        {rings.map((r) => (
          <div key={r.label} className="bg-card border border-border rounded-xl p-3 flex flex-col items-center shadow-sm">
            <svg width="64" height="64" viewBox="0 0 64 64" className="mb-2">
              <circle cx="32" cy="32" r="26" fill="none" stroke="hsl(28,24%,87%)" strokeWidth="6" />
              <circle
                cx="32" cy="32" r="26" fill="none"
                stroke={r.stroke} strokeWidth="6"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 26}`}
                strokeDashoffset={`${2 * Math.PI * 26 * (1 - r.pct / 100)}`}
                transform="rotate(-90 32 32)"
                style={{ transition: "stroke-dashoffset 0.8s cubic-bezier(0.16,1,0.3,1)" }}
              />
              <text x="32" y="37" textAnchor="middle" className="font-bold" fontSize="13" fill="currentColor" style={{ fill: r.stroke }}>
                {r.pct}%
              </text>
            </svg>
            <div className={cn("text-[11px] font-semibold flex items-center gap-1", r.col)}>
              {r.icon}{r.label}
            </div>
            <div className="text-[9px] text-muted-foreground text-center mt-0.5 leading-tight">{r.detail}</div>
          </div>
        ))}
      </div>

      {/* Today's focus */}
      {topFocus && (
        <div className="bg-card border border-burg-light/40 rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-2 text-[11px] font-semibold text-burg-light uppercase tracking-widest mb-2">
            <Star className="w-3.5 h-3.5" /> Today's Focus
          </div>
          <div className="text-[14px] font-semibold text-foreground">{topFocus.nm}</div>
          {topFocus.nt && (
            <div className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2">{topFocus.nt.replace("⚠", "").trim()}</div>
          )}
          {topFocus.lnk && (
            <a href={topFocus.lnk} target="_blank" rel="noopener noreferrer"
              className="inline-block mt-2 text-[11px] font-semibold text-primary underline hover:no-underline">
              Book now →
            </a>
          )}
        </div>
      )}

      {/* Status cards */}
      <div className="space-y-2">
        {urgentCount > 0 && (
          <div className="flex items-center gap-3 bg-card border border-burg-light/40 rounded-lg px-3 py-2.5 shadow-sm">
            <AlertTriangle className="w-4 h-4 text-burg-light shrink-0" />
            <span className="text-[13px] font-semibold text-burg-light">{urgentCount} urgent booking{urgentCount !== 1 ? "s" : ""} remaining</span>
          </div>
        )}
        {hotelEntries.length - bookedHotels - selectedHotels > 0 && (
          <div className="flex items-center gap-3 bg-card border border-gold/30 rounded-lg px-3 py-2.5 shadow-sm">
            <Hotel className="w-4 h-4 text-gold shrink-0" />
            <span className="text-[13px] text-brown font-medium">{hotelEntries.length - bookedHotels - selectedHotels} hotel{hotelEntries.length - bookedHotels - selectedHotels !== 1 ? "s" : ""} still to select</span>
          </div>
        )}
        {packPct === 0 && (
          <div className="flex items-center gap-3 bg-card border border-border rounded-lg px-3 py-2.5 shadow-sm">
            <ShoppingBag className="w-4 h-4 text-muted-foreground shrink-0" />
            <span className="text-[13px] text-muted-foreground">Packing not started yet</span>
          </div>
        )}
      </div>

      {/* Milestone checklist */}
      <div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-warm uppercase tracking-widest mb-2">
          <Calendar className="w-3.5 h-3.5" /> Pre-Trip Checklist
        </div>
        <div className="space-y-1.5">
          {milestones.map((m, i) => (
            <div key={i} className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 border transition-colors",
              m.done ? "bg-secondary border-transparent opacity-60" : "bg-card border-border shadow-sm"
            )}>
              <div className={cn(
                "w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-all",
                m.done ? "bg-primary border-primary" : "border-muted-foreground"
              )}>
                {m.done && <div className="w-1.5 h-1.5 rounded-full bg-primary-foreground" />}
              </div>
              <span className={cn("text-[12px]", m.done ? "line-through text-muted-foreground" : "text-foreground font-medium")}>
                {m.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
