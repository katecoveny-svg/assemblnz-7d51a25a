// Re-export from BrandIcons for backward compatibility
export { TypeBadge } from "./BrandIcons";
