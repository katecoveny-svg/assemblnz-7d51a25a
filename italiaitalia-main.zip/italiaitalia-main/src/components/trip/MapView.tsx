import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Day, HOTELS, HotelEntry, ActivityType } from "@/data/tripData";
import { cn } from "@/lib/utils";
import {
  X, CalendarDays, BedDouble, MapPin, Zap, ChevronRight,
  ChevronLeft, Globe, List, Layers,
} from "lucide-react";

// ── Region stop definitions ─────────────────────────────────────────
export interface MapStop {
  id: string;
  label: string;
  emoji: string;
  latlng: [number, number];
  dates: string;
  nights: number;
  color: string;
  hslVar: string;
}

export const MAP_STOPS: MapStop[] = [
  { id: "Milan",      label: "Milan",      emoji: "I",   latlng: [45.4654,  9.1860], dates: "25–28 May",    nights: 3, color: "#6B3520", hslVar: "terra"   },
  { id: "Lake Garda", label: "Lake Garda", emoji: "II",  latlng: [45.6389, 10.6780], dates: "28–30 May",    nights: 2, color: "#5C1A2A", hslVar: "primary" },
  { id: "Florence",   label: "Florence",   emoji: "III", latlng: [43.7696, 11.2558], dates: "30 May–1 Jun",  nights: 2, color: "#7A2535", hslVar: "primary" },
  { id: "Tuscany",    label: "Tuscany",    emoji: "IV",  latlng: [43.3187, 11.3307], dates: "1–3 Jun",      nights: 2, color: "#8B5A3A", hslVar: "terra"   },
  { id: "Rome",       label: "Rome",       emoji: "V",   latlng: [41.9028, 12.4964], dates: "3–5 Jun",      nights: 2, color: "#5C1A2A", hslVar: "primary" },
  { id: "Sorrento",   label: "Sorrento",   emoji: "VI",  latlng: [40.6263, 14.3752], dates: "5–9 Jun",      nights: 4, color: "#7A3A1A", hslVar: "terra"   },
  { id: "Rome Final", label: "Rome (fly)", emoji: "VII", latlng: [41.9328, 12.5164], dates: "9–10 Jun",     nights: 1, color: "#4A3028", hslVar: "brown"   },
];

const ROUTE_COORDS: [number, number][] = MAP_STOPS.map(s => s.latlng);

// ── Activity coordinates (hardcoded per known landmark) ─────────────
const ACTIVITY_COORDS: Record<string, [number, number]> = {
  // Milan
  "Navigli District":               [45.4494,  9.1785],
  "Duomo Rooftop Terraces":         [45.4641,  9.1919],
  "Aperitivo Galleria V. Emanuele": [45.4657,  9.1895],
  "The Last Supper":                [45.4660,  9.1706],
  "Sforza Castle & Brera":          [45.4706,  9.1796],
  "Pasta Cooking Class":            [45.4654,  9.1860],
  "La Scala Museum":                [45.4676,  9.1893],
  "Ferry Como→Bellagio→Varenna":   [45.8085,  9.0852],
  "Villa del Balbianello":          [45.9597,  9.1462],
  "Lunch in Bellagio":              [45.9847,  9.2613],
  "Como-Brunate Funicular":         [45.8110,  9.0848],
  // Lake Garda
  "Sirmione stop en route":         [45.4949, 10.6062],
  "Explore Garda lakefront":        [45.5773, 10.6980],
  "Bardolino wine dinner":          [45.5497, 10.7247],
  "Punta San Vigilio beach":        [45.5942, 10.7257],
  "Monte Baldo Cable Car":          [45.7360, 10.8430],
  "Ferry to Limone":                [45.8115, 10.7930],
  "Verona day trip (45min)":        [45.4384, 10.9916],
  // Florence
  "Piazzale Michelangelo sunset":   [43.7631, 11.2658],
  "Ponte Vecchio & Oltrarno":       [43.7681, 11.2531],
  "Bistecca alla Fiorentina":       [43.7696, 11.2558],
  "Accademia (David)":              [43.7767, 11.2587],
  "Uffizi Gallery":                 [43.7678, 11.2553],
  "Giotto's Bell Tower":            [43.7733, 11.2560],
  "San Lorenzo Market":             [43.7751, 11.2543],
  // Tuscany
  "Chianti wine tour":              [43.5557, 11.2628],
  "San Gimignano towers":           [43.4676, 11.0437],
  "Siena Piazza del Campo":         [43.3186, 11.3307],
  "Val d'Orcia drive":              [43.0860, 11.6305],
  "Montepulciano wine":             [43.0985, 11.7831],
  "Pienza cheese":                  [43.0752, 11.6806],
  "Truffle hunting":                [43.3187, 11.4000],
  // Rome
  "Orvieto stop en route":          [42.7189, 12.1082],
  "Trastevere evening":             [41.8896, 12.4698],
  "Trevi Fountain (after 9pm)":     [41.9009, 12.4833],
  "Trastevere dinner":              [41.8896, 12.4698],
  "Colosseum + Forum":              [41.8902, 12.4922],
  "Vatican & Sistine":              [41.9029, 12.4534],
  "Pantheon":                       [41.8986, 12.4769],
  "Gelato Giolitti":                [41.8993, 12.4757],
  "Spanish Steps":                  [41.9059, 12.4823],
  "Final Piazza Navona aperitivo":  [41.8990, 12.4730],
  // Sorrento / Amalfi
  "Pompeii":                        [40.7508, 14.4890],
  "Guided Pompeii tour":            [40.7508, 14.4890],
  "Sorrento passeggiata":           [40.6263, 14.3752],
  "Ferry Sorrento→Amalfi":         [40.6342, 14.5995],
  "Amalfi Cathedral":               [40.6342, 14.5996],
  "Seafood lunch, sea view":        [40.6342, 14.5998],
  "Path of the Gods":               [40.6631, 14.5003],
  "Spiaggia Grande":                [40.6275, 14.4840],
  "Coast boat tour":                [40.6275, 14.4841],
  "Ferry Capri (7:25am!)":          [40.5534, 14.2429],
  "Blue Grotto":                    [40.5534, 14.1778],
  "Chairlift Monte Solaro":         [40.5620, 14.2222],
  "Lunch Piazzetta":                [40.5501, 14.2424],
  // Departure
  "Roscioli Caffè":                 [41.8975, 12.4718],
};

// ── Pin colours per activity type ───────────────────────────────────
const TYPE_CONFIG: Record<ActivityType, { color: string; label: string; dot: string }> = {
  ticket:     { color: "#5C1A2A", label: "Ticket",     dot: "bg-primary"   },
  experience: { color: "#C4956A", label: "Experience",  dot: "bg-gold"      },
  food:       { color: "#8B5A3A", label: "Food",        dot: "bg-terra"     },
  transport:  { color: "#7A7060", label: "Transport",   dot: "bg-brown"     },
  free:       { color: "#4A7A5A", label: "Free",        dot: "bg-muted-foreground" },
};

// ── Props ────────────────────────────────────────────────────────────
interface Props {
  days: Day[];
  alreadyBooked: Record<string, boolean>;
  customHotels: Record<string, { nm: string; nzd: number; st?: string }>;
  onNavigate: (view: "timeline" | "hotels") => void;
}

type MapMode = "trip" | "day";

// ── Small circle icon for activity pins ─────────────────────────────
function buildActivityIcon(type: ActivityType, booked: boolean) {
  const cfg = TYPE_CONFIG[type];
  const bg  = booked ? "#5C1A2A" : cfg.color;
  const sz  = 22;
  return L.divIcon({
    html: `<div style="
      width:${sz}px;height:${sz}px;border-radius:50%;
      background:${bg};border:2px solid white;
      box-shadow:0 1px 4px rgba(0,0,0,.35);
      display:flex;align-items:center;justify-content:center;
    "></div>`,
    className: "",
    iconSize: [sz, sz],
    iconAnchor: [sz / 2, sz / 2],
  });
}

function buildRegionIcon(stop: MapStop, active: boolean) {
  const size = active ? 46 : 36;
  const ring = active ? `box-shadow:0 0 0 3px white,0 0 0 5px ${stop.color};` : "";
  const svg = `<svg width="${size}" height="${Math.round(size*1.3)}" viewBox="0 0 36 47" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18 1C9.163 1 2 8.163 2 17c0 10.5 16 29 16 29S34 27.5 34 17C34 8.163 26.837 1 18 1z"
      fill="${stop.color}" stroke="white" stroke-width="2"/>
    <text x="18" y="21" text-anchor="middle" dominant-baseline="middle"
      font-family="'DM Sans',sans-serif" font-size="${active ? 9 : 8}" font-weight="600"
      fill="white" letter-spacing="0.5">${stop.emoji}</text>
  </svg>`;
  return L.divIcon({
    html: `<div style="${ring}transition:all .2s;">${svg}</div>`,
    className: "",
    iconSize: [size, Math.round(size * 1.3)],
    iconAnchor: [size / 2, Math.round(size * 1.3)],
  });
}

// ── Component ────────────────────────────────────────────────────────
export function MapView({ days, alreadyBooked, customHotels, onNavigate }: Props) {
  const mapRef     = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<L.Map | null>(null);
  const regionMarkersRef  = useRef<L.Marker[]>([]);
  const activityLayerRef  = useRef<L.LayerGroup | null>(null);
  const routeLayerRef     = useRef<L.Polyline | null>(null);

  const [mode,       setMode]       = useState<MapMode>("trip");
  const [activeStop, setActiveStop] = useState<MapStop | null>(null);
  const [dayIndex,   setDayIndex]   = useState(0);
  const [activeAct,  setActiveAct]  = useState<{ nm: string; tp: ActivityType; c: number; bk: boolean; nt?: string; lnk?: string } | null>(null);

  // ── Init map ──────────────────────────────────────────────────────
  useEffect(() => {
    if (!mapRef.current || leafletMap.current) return;

    const map = L.map(mapRef.current, {
      center: [43.5, 12.2], zoom: 6,
      zoomControl: false, attributionControl: false,
    });

    L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
      attribution: "© OpenStreetMap © CARTO",
      subdomains: "abcd", maxZoom: 19,
    }).addTo(map);

    L.control.attribution({ position: "bottomleft", prefix: false }).addTo(map);
    L.control.zoom({ position: "topright" }).addTo(map);

    // Region markers (always present)
    MAP_STOPS.forEach((stop, i) => {
      const marker = L.marker(stop.latlng, { icon: buildRegionIcon(stop, false) })
        .addTo(map)
        .on("click", () => {
          setMode("trip");
          setActiveAct(null);
          setActiveStop(s => s?.id === stop.id ? null : stop);
        });
      regionMarkersRef.current[i] = marker;
    });

    // Route polyline (trip mode)
    routeLayerRef.current = L.polyline(ROUTE_COORDS, {
      color: "#5C1A2A", weight: 2.5, opacity: 0.5, dashArray: "6 8",
    }).addTo(map);

    activityLayerRef.current = L.layerGroup().addTo(map);

    leafletMap.current = map;
    return () => { map.remove(); leafletMap.current = null; };
  }, []);

  // ── Update region marker icons on active change ───────────────────
  useEffect(() => {
    MAP_STOPS.forEach((stop, i) => {
      const m = regionMarkersRef.current[i];
      if (m) m.setIcon(buildRegionIcon(stop, activeStop?.id === stop.id));
    });
  }, [activeStop]);

  // ── Fly to stop in trip mode ──────────────────────────────────────
  useEffect(() => {
    if (!leafletMap.current) return;
    if (mode === "trip") {
      if (activeStop) {
        leafletMap.current.flyTo(activeStop.latlng, 9, { duration: 0.9 });
      } else {
        leafletMap.current.flyTo([43.5, 12.2], 6, { duration: 0.8 });
      }
    }
  }, [activeStop, mode]);

  // ── Day mode: render activity pins + intra-day route ─────────────
  useEffect(() => {
    if (!leafletMap.current || !activityLayerRef.current) return;
    const layer = activityLayerRef.current;
    layer.clearLayers();
    if (routeLayerRef.current) {
      routeLayerRef.current.setStyle({ opacity: mode === "trip" ? 0.5 : 0.12 });
    }

    if (mode !== "day") return;

    const day = days[dayIndex];
    if (!day) return;

    const pts: [number, number][] = [];

    day.sg.forEach(act => {
      const coords = ACTIVITY_COORDS[act.nm];
      if (!coords) return;
      pts.push(coords);
      L.marker(coords, { icon: buildActivityIcon(act.tp, act.bk) })
        .addTo(layer)
        .on("click", () => setActiveAct(a => a?.nm === act.nm ? null : act));
    });

    // Intra-day route line
    if (pts.length > 1) {
      L.polyline(pts, { color: "#5C1A2A", weight: 2, opacity: 0.7, dashArray: "4 6" }).addTo(layer);
    }

    // Fly to day's region
    const stop = MAP_STOPS.find(s => s.id === day.rg || (day.rg === "Departure" && s.id === "Rome Final"));
    if (stop) {
      leafletMap.current.flyTo(
        pts.length > 0 ? centroid(pts) : stop.latlng,
        pts.length > 0 ? 12 : 9,
        { duration: 0.9 }
      );
    }
  }, [mode, dayIndex, days]);

  function centroid(pts: [number, number][]): [number, number] {
    const lat = pts.reduce((s, p) => s + p[0], 0) / pts.length;
    const lng = pts.reduce((s, p) => s + p[1], 0) / pts.length;
    return [lat, lng];
  }

  // ── Trip-mode stop data ───────────────────────────────────────────
  function stopData(stop: MapStop) {
    const hotel = HOTELS[stop.id] as HotelEntry | undefined;
    const booked = alreadyBooked[stop.id] || hotel?.st === "confirmed" || customHotels[stop.id]?.st === "booked";
    const selected = customHotels[stop.id]?.st === "selected";
    const customNm = customHotels[stop.id]?.nm;
    const hotelName = booked && customNm && customNm !== "Crowne Plaza" ? customNm : hotel?.cf ?? (booked ? "Booked" : null);
    const stopDays = days.filter(d => d.rg === stop.id || (stop.id === "Rome Final" && d.rg === "Departure"));
    const totalActs  = stopDays.reduce((s, d) => s + d.sg.length, 0);
    const bookedActs = stopDays.reduce((s, d) => s + d.sg.filter(a => a.bk).length, 0);
    const urgentActs = stopDays.reduce((s, d) => s + d.sg.filter(a => a.nt?.includes("⚠") && !a.bk).length, 0);
    const highlights = stopDays.flatMap(d => d.sg.filter(a => a.tp === "experience" || a.tp === "ticket")).slice(0, 3);
    return { booked, selected, hotelName, totalActs, bookedActs, urgentActs, highlights };
  }

  const currentDay = days[dayIndex];
  const dayPins = currentDay ? currentDay.sg.filter(a => ACTIVITY_COORDS[a.nm]) : [];

  return (
    <div className="relative" style={{ height: "calc(100vh - 160px)", minHeight: 480 }}>
      {/* Map canvas */}
      <div ref={mapRef} className="absolute inset-0 rounded-xl overflow-hidden z-0" />

      {/* ── Mode toggle ── */}
      <div className="absolute top-3 left-3 z-[999] flex rounded-lg border border-border overflow-hidden shadow-md">
        <button
          onClick={() => { setMode("trip"); setActiveAct(null); }}
          className={cn(
            "flex items-center gap-1.5 px-3 py-2 text-[11px] font-semibold transition-colors",
            mode === "trip" ? "bg-primary text-primary-foreground" : "bg-card/95 text-muted-foreground hover:bg-secondary"
          )}
        >
          <Globe className="w-3 h-3" /> Trip
        </button>
        <button
          onClick={() => { setMode("day"); setActiveStop(null); setActiveAct(null); }}
          className={cn(
            "flex items-center gap-1.5 px-3 py-2 text-[11px] font-semibold transition-colors",
            mode === "day" ? "bg-primary text-primary-foreground" : "bg-card/95 text-muted-foreground hover:bg-secondary"
          )}
        >
          <Layers className="w-3 h-3" /> Day
        </button>
      </div>

      {/* ── TRIP MODE: stop list strip ── */}
      {mode === "trip" && !activeStop && (
        <div className="absolute bottom-3 left-3 right-3 z-[999]">
          <div className="bg-card/95 backdrop-blur rounded-xl border border-border shadow-lg p-3">
            <p className="text-[9px] uppercase tracking-widest text-muted-foreground mb-2 px-1">Tap a pin or stop</p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {MAP_STOPS.map((stop, i) => {
                const d = stopData(stop);
                return (
                  <button key={stop.id} onClick={() => setActiveStop(stop)}
                    className="flex flex-col items-center gap-1 min-w-[58px] px-2 py-2 rounded-lg border border-border hover:bg-secondary transition-colors active:scale-95 shrink-0"
                  >
                    <span className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[10px] font-bold"
                      style={{ background: stop.color }}>{i + 1}</span>
                    <span className="text-[9px] font-medium text-foreground leading-tight text-center">{stop.label}</span>
                    <span className={cn(
                      "text-[8px] font-bold rounded-full px-1.5 py-0.5",
                      d.booked ? "bg-primary/12 text-primary" : "bg-gold/15 text-brown"
                    )}>{d.booked ? "✓" : "needed"}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── TRIP MODE: stop detail panel ── */}
      {mode === "trip" && activeStop && (() => {
        const active = stopData(activeStop);
        return (
          <div className="absolute bottom-3 left-3 right-3 z-[999]">
            <div className="bg-card/97 backdrop-blur rounded-xl border border-border shadow-xl overflow-hidden">
              <div className="flex items-center gap-3 px-4 py-3"
                style={{ background: activeStop.color + "22", borderBottom: `3px solid ${activeStop.color}` }}
              >
                <span className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[11px] font-bold shrink-0"
                  style={{ background: activeStop.color }}>
                  {MAP_STOPS.findIndex(s => s.id === activeStop.id) + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-sm text-foreground">{activeStop.label}</div>
                  <div className="text-[10px] text-muted-foreground">{activeStop.dates} · {activeStop.nights} night{activeStop.nights !== 1 ? "s" : ""}</div>
                </div>
                <span className={cn(
                  "text-[10px] font-semibold px-2 py-0.5 rounded-full border shrink-0",
                  active.booked ? "bg-primary/12 text-primary border-primary/25"
                    : active.selected ? "bg-gold/15 text-brown border-gold/35"
                    : "bg-primary/8 text-primary-light border-primary-light/30"
                )}>
                  {active.booked ? "Hotel ✓" : active.selected ? "Selected" : "Needs hotel"}
                </span>
                <button onClick={() => setActiveStop(null)} className="ml-1 text-muted-foreground hover:text-foreground transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="px-4 py-3 space-y-3">
                <div className="flex gap-3">
                  <div className="flex items-center gap-1.5 text-[11px] text-foreground">
                    <CalendarDays className="w-3.5 h-3.5 text-muted-foreground" />
                    <span>{active.bookedActs}/{active.totalActs} activities booked</span>
                  </div>
                  {active.urgentActs > 0 && (
                    <div className="flex items-center gap-1 text-[11px] font-semibold" style={{ color: "hsl(var(--rose))" }}>
                      <Zap className="w-3 h-3" /> {active.urgentActs} urgent
                    </div>
                  )}
                  {active.hotelName && (
                    <div className="flex items-center gap-1 text-[11px] text-muted-foreground ml-auto">
                      <BedDouble className="w-3.5 h-3.5" />
                      <span className="truncate max-w-[120px]">{active.hotelName}</span>
                    </div>
                  )}
                </div>
                {active.highlights.length > 0 && (
                  <div>
                    <p className="text-[9px] uppercase tracking-widest text-muted-foreground mb-1.5">Highlights</p>
                    <div className="space-y-1">
                      {active.highlights.map((act, i) => (
                        <div key={i} className="flex items-center gap-2 text-[11px] text-foreground">
                          <MapPin className="w-3 h-3 text-muted-foreground shrink-0" />
                          <span className={act.bk ? "line-through text-muted-foreground" : ""}>{act.nm}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                <div className="flex gap-2 pt-1">
                  <button onClick={() => onNavigate("timeline")}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-border text-[11px] font-semibold text-foreground hover:bg-secondary transition-colors active:scale-95">
                    <CalendarDays className="w-3.5 h-3.5" /> View days <ChevronRight className="w-3 h-3 ml-auto" />
                  </button>
                  <button onClick={() => onNavigate("hotels")}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-primary text-primary-foreground text-[11px] font-semibold hover:opacity-90 transition-opacity active:scale-95">
                    <BedDouble className="w-3.5 h-3.5" />
                    {active.booked ? "Hotel details" : "Book hotel"}
                    <ChevronRight className="w-3 h-3 ml-auto" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* ── DAY MODE: day selector ── */}
      {mode === "day" && (
        <div className="absolute bottom-3 left-3 right-3 z-[999] space-y-2">
          {/* Activity popup */}
          {activeAct && (
            <div className="bg-card/97 backdrop-blur rounded-xl border border-border shadow-xl px-4 py-3 flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: TYPE_CONFIG[activeAct.tp].color }} />
                  <span className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">{TYPE_CONFIG[activeAct.tp].label}</span>
                  {activeAct.bk && <span className="text-[10px] text-primary font-bold ml-auto">✓ Booked</span>}
                  {activeAct.c > 0 && <span className="text-[11px] font-bold text-foreground">€{activeAct.c}</span>}
                </div>
                <div className="text-sm font-semibold text-foreground">{activeAct.nm}</div>
                {activeAct.nt && (
                  <div className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                    {activeAct.nt.replace("⚠ ", "").replace("⚠", "")}
                  </div>
                )}
                {activeAct.lnk && (
                  <a href={activeAct.lnk} target="_blank" rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[10px] text-primary font-semibold mt-1.5 hover:opacity-70 transition-opacity">
                    Book online <ChevronRight className="w-3 h-3" />
                  </a>
                )}
              </div>
              <button onClick={() => setActiveAct(null)} className="text-muted-foreground hover:text-foreground shrink-0 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Day nav + pin list */}
          <div className="bg-card/95 backdrop-blur rounded-xl border border-border shadow-lg p-3">
            {/* Day header with arrows */}
            <div className="flex items-center gap-2 mb-2">
              <button onClick={() => { setDayIndex(i => Math.max(0, i - 1)); setActiveAct(null); }}
                disabled={dayIndex === 0}
                className="p-1 rounded-md hover:bg-secondary disabled:opacity-30 transition-colors active:scale-90">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="flex-1 text-center">
                <div className="text-[12px] font-bold text-foreground">{currentDay?.dt} · {currentDay?.dy}</div>
                <div className="text-[10px] text-muted-foreground truncate">{currentDay?.act}</div>
              </div>
              <button onClick={() => { setDayIndex(i => Math.min(days.length - 1, i + 1)); setActiveAct(null); }}
                disabled={dayIndex === days.length - 1}
                className="p-1 rounded-md hover:bg-secondary disabled:opacity-30 transition-colors active:scale-90">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Pin legend + activity list */}
            {dayPins.length > 0 ? (
              <div className="space-y-1">
                {dayPins.map((act, i) => (
                  <button key={i} onClick={() => setActiveAct(a => a?.nm === act.nm ? null : act)}
                    className={cn(
                      "w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-colors active:scale-[0.98]",
                      activeAct?.nm === act.nm ? "bg-secondary border border-border" : "hover:bg-secondary/60"
                    )}
                  >
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: act.bk ? "#5C1A2A" : TYPE_CONFIG[act.tp].color }} />
                    <span className={cn("text-[11px] flex-1 leading-snug", act.bk && "line-through text-muted-foreground")}>
                      {act.nm}
                    </span>
                    {act.c > 0 && <span className="text-[10px] text-muted-foreground shrink-0">€{act.c}</span>}
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex items-center gap-2 text-[11px] text-muted-foreground px-1 py-1">
                <List className="w-3.5 h-3.5 shrink-0" />
                <span>No mapped pins for this day yet</span>
              </div>
            )}

            {/* Type legend */}
            <div className="flex gap-3 mt-2 pt-2 border-t border-border flex-wrap">
              {(Object.entries(TYPE_CONFIG) as [ActivityType, typeof TYPE_CONFIG[ActivityType]][]).map(([tp, cfg]) => (
                <div key={tp} className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full" style={{ background: cfg.color }} />
                  <span className="text-[9px] text-muted-foreground">{cfg.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
