import { FOOD, PHRASES } from "@/data/tripData";
import { cn } from "@/lib/utils";
import { Utensils, BookOpen } from "lucide-react";

const KIND_STYLE: Record<string, string> = {
  S:   "bg-primary/10 text-primary border-primary/30",
  M:   "bg-brown/10 text-brown border-brown/30",
  St:  "bg-gold/10 text-brown border-gold/30",
  Tip: "bg-gold/15 text-brown border-gold/40",
};
const KIND_LABEL: Record<string, string> = {
  S: "Speciality", M: "Main", St: "Street food", Tip: "Tip",
};

const REGIONS = ["Milan", "Lake Garda", "Florence", "Tuscany", "Rome", "Sorrento"];

export function FoodView() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl italic font-light text-primary font-serif">Food & Culture</h2>

      {REGIONS.map(region => {
        const items = FOOD[region];
        if (!items) return null;
        return (
          <div key={region} className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
            <div className="px-4 py-3 bg-secondary/40 border-b border-border flex items-center gap-2">
              <Utensils className="w-3.5 h-3.5 text-gold shrink-0" />
              <span className="text-[13px] font-semibold text-warm">{region}</span>
            </div>
            <div className="divide-y divide-border">
              {items.map((item, i) => (
                <div key={i} className="px-4 py-3 flex items-start gap-3">
                  <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold flex-shrink-0 mt-0.5", KIND_STYLE[item.kind])}>
                    {KIND_LABEL[item.kind] ?? item.kind}
                  </span>
                  <div>
                    <div className="text-[13px] font-semibold">{item.dish}</div>
                    <div className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{item.tip}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {/* Italian phrases */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="px-4 py-3 bg-secondary/40 border-b border-border flex items-center gap-2">
          <BookOpen className="w-3.5 h-3.5 text-gold shrink-0" />
          <span className="text-[13px] font-semibold text-warm">Essential Phrases</span>
        </div>
        <div className="divide-y divide-border">
          {PHRASES.map((p, i) => (
            <div key={i} className="px-4 py-2.5 flex justify-between items-start gap-4">
              <div className="text-[13px] font-semibold italic text-primary font-serif">{p.it}</div>
              <div className="text-[11px] text-muted-foreground text-right flex-shrink-0">{p.en}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
