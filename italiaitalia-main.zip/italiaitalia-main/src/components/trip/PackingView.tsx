import { useState } from "react";
import { cn } from "@/lib/utils";
import { Check, Shirt, FileText, Sparkles, Laptop, Plus, Trash2, ChevronDown, ChevronUp } from "lucide-react";

export interface PackingItem {
  id: string;
  nm: string;
  k: boolean; // Kate checked
  a: boolean; // Adrian checked
}

export interface PackingCategory {
  id: string;
  label: string;
  icon: React.ReactNode;
  items: PackingItem[];
}

export const DEFAULT_PACKING: PackingCategory[] = [
  {
    id: "clothes",
    label: "Clothes",
    icon: <Shirt className="w-4 h-4" />,
    items: [
      { id: "c1", nm: "Lightweight summer dresses / shirts", k: false, a: false },
      { id: "c2", nm: "Smart evening outfit (restaurants)", k: false, a: false },
      { id: "c3", nm: "Comfortable walking shoes", k: false, a: false },
      { id: "c4", nm: "Sandals for the coast", k: false, a: false },
      { id: "c5", nm: "Light cardigan / jacket (evenings)", k: false, a: false },
      { id: "c6", nm: "Swimwear × 2", k: false, a: false },
      { id: "c7", nm: "Scarf / wrap (churches require coverage)", k: false, a: false },
      { id: "c8", nm: "Underwear & socks × 7", k: false, a: false },
      { id: "c9", nm: "Sun hat / cap", k: false, a: false },
      { id: "c10", nm: "Rain jacket (just in case)", k: false, a: false },
      { id: "c11", nm: "Jeans or trousers × 2", k: false, a: false },
      { id: "c12", nm: "Hiking shoes (Path of the Gods)", k: false, a: false },
    ],
  },
  {
    id: "documents",
    label: "Documents",
    icon: <FileText className="w-4 h-4" />,
    items: [
      { id: "d1", nm: "Passports (check expiry!)", k: false, a: false },
      { id: "d2", nm: "Flight confirmations (NZ → Milan, Rome → NZ)", k: false, a: false },
      { id: "d3", nm: "Travel insurance policy", k: false, a: false },
      { id: "d4", nm: "Driving licence (international)", k: false, a: false },
      { id: "d5", nm: "Hotel bookings printed / saved offline", k: false, a: false },
      { id: "d6", nm: "Pre-booked tickets (Last Supper, Uffizi…)", k: false, a: false },
      { id: "d7", nm: "Credit / debit cards (notify bank!)", k: false, a: false },
      { id: "d8", nm: "Travel card / forex cash (€200–300)", k: false, a: false },
      { id: "d9", nm: "Emergency contacts list", k: false, a: false },
      { id: "d10", nm: "EHIC / health card", k: false, a: false },
    ],
  },
  {
    id: "toiletries",
    label: "Toiletries",
    icon: <Sparkles className="w-4 h-4" />,
    items: [
      { id: "t1", nm: "SPF 50 sunscreen (pack big!)", k: false, a: false },
      { id: "t2", nm: "After-sun lotion", k: false, a: false },
      { id: "t3", nm: "Insect repellent", k: false, a: false },
      { id: "t4", nm: "Shampoo & conditioner (travel size)", k: false, a: false },
      { id: "t5", nm: "Moisturiser", k: false, a: false },
      { id: "t6", nm: "Deodorant", k: false, a: false },
      { id: "t7", nm: "Toothbrush & toothpaste", k: false, a: false },
      { id: "t8", nm: "Razor / shaving kit", k: false, a: false },
      { id: "t9", nm: "Medications & prescriptions", k: false, a: false },
      { id: "t10", nm: "Blister plasters (essential!)", k: false, a: false },
      { id: "t11", nm: "Hand sanitiser", k: false, a: false },
      { id: "t12", nm: "Lip balm with SPF", k: false, a: false },
    ],
  },
  {
    id: "tech",
    label: "Tech",
    icon: <Laptop className="w-4 h-4" />,
    items: [
      { id: "tc1", nm: "Phones + chargers", k: false, a: false },
      { id: "tc2", nm: "International power adaptors (Italy = Type F)", k: false, a: false },
      { id: "tc3", nm: "Portable power bank", k: false, a: false },
      { id: "tc4", nm: "Camera + SD cards", k: false, a: false },
      { id: "tc5", nm: "Headphones / earbuds", k: false, a: false },
      { id: "tc6", nm: "Offline maps downloaded (Google / Maps.me)", k: false, a: false },
      { id: "tc7", nm: "Duolingo Italian practice done", k: false, a: false },
      { id: "tc8", nm: "Netflix / shows downloaded for flights", k: false, a: false },
    ],
  },
];

type CategoryState = Record<string, PackingItem[]>;

function categoryProgress(items: PackingItem[]) {
  const k = items.filter(i => i.k).length;
  const a = items.filter(i => i.a).length;
  const total = items.length;
  return { k, a, total };
}

interface Props {
  packing: CategoryState;
  onToggle: (catId: string, itemId: string, who: "k" | "a") => void;
  onAddItem: (catId: string, nm: string) => void;
  onRemoveItem: (catId: string, itemId: string) => void;
}

const CATEGORY_META = DEFAULT_PACKING.map(c => ({ id: c.id, label: c.label, icon: c.icon }));

const catColor: Record<string, string> = {
  clothes:    "text-primary",
  documents:  "text-gold",
  toiletries: "text-brown",
  tech:       "text-primary-light",
};
const catBorder: Record<string, string> = {
  clothes:    "border-l-primary",
  documents:  "border-l-gold",
  toiletries: "border-l-brown",
  tech:       "border-l-primary-light",
};
const catBg: Record<string, string> = {
  clothes:    "bg-primary/5",
  documents:  "bg-gold/8",
  toiletries: "bg-brown/5",
  tech:       "bg-primary/5",
};

function ProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = max === 0 ? 0 : Math.round((value / max) * 100);
  return (
    <div className="h-1 rounded-full bg-border overflow-hidden flex-1">
      <div
        className={cn("h-full rounded-full transition-all duration-500", color)}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

export function PackingView({ packing, onToggle, onAddItem, onRemoveItem }: Props) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [adding, setAdding] = useState<Record<string, string>>({});

  const totalItems = DEFAULT_PACKING.reduce((s, c) => s + (packing[c.id]?.length ?? c.items.length), 0);
  const kDone = DEFAULT_PACKING.reduce((s, c) => s + (packing[c.id] ?? c.items).filter(i => i.k).length, 0);
  const aDone = DEFAULT_PACKING.reduce((s, c) => s + (packing[c.id] ?? c.items).filter(i => i.a).length, 0);

  return (
    <div className="space-y-4">
      {/* Header summary */}
      <div className="rounded-xl bg-primary text-primary-foreground px-5 py-4">
        <div className="text-[10px] uppercase tracking-widest opacity-60 mb-1">Packing Progress</div>
        <div className="flex gap-6">
          <div>
            <span className="text-gold text-xl font-bold font-serif">{kDone}/{totalItems}</span>
            <span className="text-[11px] opacity-70 ml-1.5">Kate packed</span>
          </div>
          <div>
            <span className="text-gold text-xl font-bold font-serif">{aDone}/{totalItems}</span>
            <span className="text-[11px] opacity-70 ml-1.5">Adrian packed</span>
          </div>
        </div>
        <div className="flex gap-2 mt-3 items-center">
          <span className="text-[10px] opacity-50 w-8">K</span>
          <ProgressBar value={kDone} max={totalItems} color="bg-rose" />
        </div>
        <div className="flex gap-2 mt-1 items-center">
          <span className="text-[10px] opacity-50 w-8">A</span>
          <ProgressBar value={aDone} max={totalItems} color="bg-gold" />
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-3 text-[10px] text-warm px-1">
        <span className="flex items-center gap-1"><span className="w-4 h-4 rounded border-2 border-rose bg-rose/10 flex items-center justify-center text-rose"><Check className="w-2.5 h-2.5" /></span> Kate</span>
        <span className="flex items-center gap-1"><span className="w-4 h-4 rounded border-2 border-gold bg-gold/10 flex items-center justify-center text-gold"><Check className="w-2.5 h-2.5" /></span> Adrian</span>
        <span className="text-muted-foreground ml-auto italic">Tap to check off your items</span>
      </div>

      {/* Categories */}
      {DEFAULT_PACKING.map((cat) => {
        const items = packing[cat.id] ?? cat.items;
        const { k, a, total } = categoryProgress(items);
        const isCollapsed = collapsed[cat.id];
        const addVal = adding[cat.id] ?? "";
        const allKDone = k === total;
        const allADone = a === total;

        return (
          <div key={cat.id} className={cn("rounded-xl border bg-card overflow-hidden shadow-sm border-l-4", catBorder[cat.id])}>
            {/* Category header */}
            <button
              className="w-full flex items-center gap-3 px-4 py-3 text-left"
              onClick={() => setCollapsed(p => ({ ...p, [cat.id]: !p[cat.id] }))}
            >
              <span className={cn("shrink-0", catColor[cat.id])}>{cat.icon}</span>
              <span className="font-semibold text-sm text-foreground flex-1">{cat.label}</span>
              <span className="text-[10px] text-muted-foreground mr-1">
                {allKDone && allADone ? "✓ All done!" : `${k}/${total} K · ${a}/${total} A`}
              </span>
              {isCollapsed ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" /> : <ChevronUp className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
            </button>

            {/* Mini progress */}
            <div className="px-4 pb-2 flex gap-1.5">
              <ProgressBar value={k} max={total} color="bg-rose" />
              <ProgressBar value={a} max={total} color="bg-gold" />
            </div>

            {/* Items */}
            {!isCollapsed && (
              <div className="px-2 pb-2">
                {items.map((item) => (
                  <div key={item.id} className={cn(
                    "flex items-center gap-2 rounded-lg px-2 py-2.5 group",
                    item.k && item.a ? "opacity-50" : ""
                  )}>
                    {/* Kate button */}
                    <button
                      onClick={() => onToggle(cat.id, item.id, "k")}
                      className={cn(
                        "w-6 h-6 rounded border-2 flex items-center justify-center shrink-0 transition-all active:scale-95",
                        item.k
                          ? "border-rose bg-rose/15 text-rose"
                          : "border-border text-transparent hover:border-rose/50"
                      )}
                    >
                      <Check className="w-3 h-3" />
                    </button>

                    {/* Item name */}
                    <span className={cn(
                      "flex-1 text-[12px] leading-snug",
                      item.k && item.a ? "line-through text-muted-foreground" : "text-foreground"
                    )}>
                      {item.nm}
                    </span>

                    {/* Adrian button */}
                    <button
                      onClick={() => onToggle(cat.id, item.id, "a")}
                      className={cn(
                        "w-6 h-6 rounded border-2 flex items-center justify-center shrink-0 transition-all active:scale-95",
                        item.a
                          ? "border-gold bg-gold/15 text-gold"
                          : "border-border text-transparent hover:border-gold/50"
                      )}
                    >
                      <Check className="w-3 h-3" />
                    </button>

                    {/* Remove custom items */}
                    <button
                      onClick={() => onRemoveItem(cat.id, item.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-rose"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}

                {/* Add item row */}
                <div className={cn("flex gap-2 mt-1 px-2 rounded-lg", catBg[cat.id], "p-2")}>
                  <input
                    type="text"
                    placeholder="Add an item…"
                    value={addVal}
                    onChange={e => setAdding(p => ({ ...p, [cat.id]: e.target.value }))}
                    onKeyDown={e => {
                      if (e.key === "Enter" && addVal.trim()) {
                        onAddItem(cat.id, addVal.trim());
                        setAdding(p => ({ ...p, [cat.id]: "" }));
                      }
                    }}
                    className="flex-1 text-[11px] bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
                  />
                  <button
                    onClick={() => {
                      if (addVal.trim()) {
                        onAddItem(cat.id, addVal.trim());
                        setAdding(p => ({ ...p, [cat.id]: "" }));
                      }
                    }}
                    className={cn("text-muted-foreground hover:text-foreground transition-colors", !addVal.trim() && "opacity-30")}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}

      {/* Note about sync */}
      <p className="text-[10px] text-muted-foreground text-center italic pb-4">
        Connect Lovable Cloud to sync Kate &amp; Adrian's packing in real-time
      </p>
    </div>
  );
}
