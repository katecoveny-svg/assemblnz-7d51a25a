/**
 * Shown once after first sign-up, before the planner.
 * Lets the user tell the app whether they are Kate or Adrian.
 */
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

const PEOPLE = [
  { role: "k" as const, name: "Kate",   initial: "K", color: "border-primary bg-primary/8 hover:bg-primary/15" },
  { role: "a" as const, name: "Adrian", initial: "A", color: "border-gold   bg-gold/8   hover:bg-gold/15"   },
];

export function ProfileSetup() {
  const { createProfile, signOut } = useAuth();
  const [loading, setLoading] = useState<"k" | "a" | null>(null);
  const [error,   setError]   = useState<string | null>(null);

  const handle = async (role: "k" | "a", name: string) => {
    setLoading(role); setError(null);
    const { error: err } = await createProfile(role, name);
    if (err) { setError(err.message); setLoading(null); }
    // On success, AuthContext updates profile → planner renders automatically
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-5">
      <div className="text-center mb-8 fade-up">
        <h1 className="text-[36px] font-light italic text-primary font-serif leading-none">Welcome!</h1>
        <p className="text-sm text-muted-foreground mt-3 font-sans">Which traveller are you?</p>
      </div>

      <div className="flex gap-4 fade-up delay-1">
        {PEOPLE.map(p => (
          <button key={p.role}
            onClick={() => handle(p.role, p.name)}
            disabled={!!loading}
            className={cn(
              "w-36 h-44 flex flex-col items-center justify-center gap-3 rounded-2xl border-2 transition-all active:scale-95",
              p.color,
              loading === p.role && "opacity-70"
            )}>
            <span className="w-16 h-16 rounded-full bg-primary text-primary-foreground text-3xl font-bold font-serif flex items-center justify-center shadow-md">
              {p.initial}
            </span>
            <span className="text-base font-semibold text-foreground">{p.name}</span>
            {loading === p.role && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
          </button>
        ))}
      </div>

      {error && (
        <p className="mt-4 text-[12px] text-burg-light fade-up">{error}</p>
      )}

      <button onClick={signOut} className="mt-8 text-[11px] text-muted-foreground hover:text-foreground transition-colors">
        Sign out
      </button>
    </div>
  );
}
