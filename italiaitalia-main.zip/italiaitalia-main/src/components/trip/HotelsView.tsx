import { useState } from "react";
import { HOTELS, HotelTier } from "@/data/tripData";
import { cn } from "@/lib/utils";
import {
  ExternalLink, Star, Check, BookmarkCheck, CircleDot,
  MapPin, Sparkles, Leaf, Crown, ChevronDown, ChevronUp, Globe,
  Info, CheckCircle2, Hotel,
} from "lucide-react";

/* ─── Types ─────────────────────────────────────────────────────────── */
interface CustomHotel {
  nm: string;
  nzd: number;
  st?: "none" | "selected" | "booked";
}

interface Props {
  customHotels: Record<string, CustomHotel>;
  selectedNzd: Record<string, number>;
  alreadyBooked: Record<string, boolean>;
  onSetCustom: (region: string, val: Partial<CustomHotel>) => void;
  onSelectOption: (region: string, nzd: number) => void;
  onMarkBooked: (region: string) => void;
}

/* ─── Tier config ────────────────────────────────────────────────────── */
const TIER_CONFIG: Record<HotelTier, {
  label: string;
  icon: React.FC<{ className?: string }>;
  chip: string;
  bar: string;
  dot: string;
}> = {
  budget: {
    label: "Budget",
    icon: Leaf,
    chip: "bg-emerald-50 text-emerald-700 border-emerald-200",
    bar: "bg-emerald-400",
    dot: "bg-emerald-500",
  },
  mid: {
    label: "Mid-range",
    icon: Sparkles,
    chip: "bg-amber-50 text-amber-700 border-amber-200",
    bar: "bg-amber-400",
    dot: "bg-amber-500",
  },
  luxury: {
    label: "Luxury",
    icon: Crown,
    chip: "bg-purple-50 text-purple-700 border-purple-200",
    bar: "bg-purple-400",
    dot: "bg-purple-500",
  },
};

const TIER_ORDER: HotelTier[] = ["budget", "mid", "luxury"];

/* ─── Helpers ────────────────────────────────────────────────────────── */
function bkDates(q: string, ci: string, co: string) {
  return `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(q)}&checkin=${ci}&checkout=${co}&group_adults=2&no_rooms=1`;
}
function bkBrowse(q: string) {
  return `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(q)}&group_adults=2&no_rooms=1`;
}
function fmtDate(d: string) {
  const dt = new Date(d + "T00:00:00");
  return dt.toLocaleDateString("en-NZ", { day: "numeric", month: "short" });
}

function StarRow({ n }: { n: number }) {
  if (n === 0) return null;
  return (
    <span className="inline-flex gap-0.5">
      {Array.from({ length: n }).map((_, i) => (
        <Star key={i} className="w-2.5 h-2.5 fill-gold text-gold" />
      ))}
    </span>
  );
}

function PriceBar({ eur, tier }: { eur: number; tier: HotelTier }) {
  const max = tier === "budget" ? 250 : tier === "mid" ? 450 : 800;
  const pct = Math.min(100, (eur / max) * 100);
  const cfg = TIER_CONFIG[tier];
  return (
    <div className="flex-1 h-1 rounded-full bg-border overflow-hidden">
      <div className={cn("h-full rounded-full", cfg.bar)} style={{ width: `${pct}%` }} />
    </div>
  );
}

/* ─── Booked region summary card ─────────────────────────────────────── */
function BookedCard({
  region,
  bookedHotelName,
  nights,
  ci,
  co,
  onUnbook,
  isConfirmed,
}: {
  region: string;
  bookedHotelName: string;
  nights: number;
  ci: string;
  co: string;
  onUnbook: () => void;
  isConfirmed: boolean;
}) {
  return (
    <div className="bg-card rounded-xl border border-primary/20 shadow-sm overflow-hidden">
      <div className="bg-primary px-4 py-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-gold" />
          <div>
            <div className="text-[13px] font-semibold text-primary-foreground">{region}</div>
            <div className="text-[10px] text-primary-foreground/70">{fmtDate(ci)} → {fmtDate(co)} · {nights}n</div>
          </div>
        </div>
        {!isConfirmed && (
          <button
            onClick={onUnbook}
            className="text-[9px] px-2 py-1 rounded border border-white/20 text-white/70 hover:bg-white/10 transition-colors"
          >
            Unbook
          </button>
        )}
      </div>
      <div className="px-4 py-3 flex items-center gap-3">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", "bg-primary/10")}>
          <Hotel className="w-4 h-4 text-primary" />
        </div>
        <div>
          <div className="text-[13px] font-semibold text-foreground">{bookedHotelName}</div>
          <div className="text-[10px] text-muted-foreground mt-0.5">
            {isConfirmed ? "Pre-confirmed — no action needed" : "Marked as booked"}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Single hotel option card ───────────────────────────────────────── */
function OptionCard({
  opt,
  nights,
  ci,
  co,
  isSel,
  onSelect,
}: {
  opt: typeof HOTELS[string]["opts"][number];
  nights: number;
  ci: string;
  co: string;
  isSel: boolean;
  onSelect: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const cfg = TIER_CONFIG[opt.tier];
  const Icon = cfg.icon;

  if (opt.rb) {
    return (
      <div className="px-4 py-3 flex items-start gap-3">
        <div className={cn("w-2 h-2 rounded-full shrink-0 mt-1.5", cfg.dot)} />
        <div>
          <div className="text-[12px] font-semibold">{opt.nm}</div>
          <div className="text-[11px] text-muted-foreground mt-0.5">{opt.v}</div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn(
      "relative transition-all duration-200",
      isSel ? "bg-cream/60" : ""
    )}>
      {isSel && <div className={cn("absolute left-0 top-0 bottom-0 w-0.5 rounded-r", cfg.bar)} />}

      <div className="px-4 py-3.5">
        {/* Top row */}
        <div className="flex items-start gap-3">
          {/* Left: name, tier, location */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-1.5 mb-1.5">
              <span className={cn(
                "inline-flex items-center gap-0.5 text-[9px] font-semibold px-1.5 py-0.5 rounded border",
                cfg.chip
              )}>
                <Icon className="w-2.5 h-2.5" />
                {cfg.label}
              </span>
              {opt.bk && (
                <span className="inline-flex items-center gap-0.5 text-[9px] font-semibold px-1.5 py-0.5 rounded border bg-primary/10 text-primary border-primary/20">
                  <BookmarkCheck className="w-2.5 h-2.5" /> Confirmed
                </span>
              )}
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[14px] font-semibold leading-tight">{opt.nm}</span>
              <StarRow n={opt.s} />
            </div>
            <div className="flex items-center gap-1 mt-0.5">
              <MapPin className="w-2.5 h-2.5 text-muted-foreground shrink-0" />
              <span className="text-[10px] text-muted-foreground">{opt.hood}</span>
            </div>
          </div>

          {/* Right: price */}
          {!opt.bk && opt.nzd > 0 && (
            <div className="text-right shrink-0">
              <div className="text-[16px] font-bold leading-none">
                ${opt.nzd}
                <span className="text-[10px] font-normal text-muted-foreground">/n</span>
              </div>
              <div className="text-[9px] text-muted-foreground mt-0.5">€{opt.eur}/n</div>
              <div className="flex items-center gap-1 mt-1 justify-end">
                <PriceBar eur={opt.eur} tier={opt.tier} />
              </div>
              <div className="text-[10px] text-muted-foreground mt-1">
                {nights}n = <span className="font-bold text-foreground">${(opt.nzd * nights).toLocaleString()}</span>
              </div>
            </div>
          )}
        </div>

        {/* Description */}
        <p className="text-[11px] text-muted-foreground leading-snug mt-2">{opt.v}</p>

        {/* Expandable perks */}
        {opt.perks && opt.perks.length > 0 && (
          <div className="mt-2">
            <button
              onClick={() => setExpanded(v => !v)}
              className="flex items-center gap-1 text-[10px] text-primary/70 hover:text-primary font-medium"
            >
              <Info className="w-3 h-3" />
              {expanded ? "Hide details" : "What's included"}
              {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            {expanded && (
              <ul className="mt-2 space-y-1">
                {opt.perks.map((p, i) => (
                  <li key={i} className="flex items-center gap-1.5 text-[11px] text-foreground/80">
                    <Check className="w-3 h-3 text-primary shrink-0" />
                    {p}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {/* Action buttons */}
        {!opt.bk && (
          <div className="flex flex-wrap gap-2 mt-3 items-center">
            {opt.q && (
              <>
                <a
                  href={bkDates(opt.q, ci, co)}
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[10px] px-3 py-1.5 rounded-lg bg-primary text-primary-foreground font-semibold hover:opacity-80 transition-opacity"
                >
                  Check availability <ExternalLink className="w-3 h-3" />
                </a>
                <a
                  href={bkBrowse(opt.q)}
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[10px] px-3 py-1.5 rounded-lg border border-border text-muted-foreground hover:border-primary/40 hover:text-foreground transition-colors"
                >
                  Browse
                </a>
              </>
            )}
            {opt.site && (
              <a
                href={opt.site}
                target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[10px] px-3 py-1.5 rounded-lg border border-border text-muted-foreground hover:border-primary/40 hover:text-foreground transition-colors"
              >
                <Globe className="w-3 h-3" /> Official site
              </a>
            )}
            {opt.nzd > 0 && (
              <button
                onClick={onSelect}
                className={cn(
                  "inline-flex items-center gap-1 text-[10px] px-3 py-1.5 rounded-lg border transition-all ml-auto",
                  isSel
                    ? "border-gold bg-cream text-brown font-bold"
                    : "border-border text-muted-foreground hover:border-gold/50 hover:text-brown"
                )}
              >
                {isSel ? <><Check className="w-3 h-3" /> Selected</> : "Select for budget"}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Main component ─────────────────────────────────────────────────── */
export function HotelsView({
  customHotels, selectedNzd, alreadyBooked,
  onSetCustom, onSelectOption, onMarkBooked,
}: Props) {
  const [activeTier, setActiveTier] = useState<HotelTier | "all">("all");
  const [expandedRegions, setExpandedRegions] = useState<Record<string, boolean>>({});

  const toggleRegion = (r: string) =>
    setExpandedRegions(prev => ({ ...prev, [r]: !prev[r] }));

  const regions = Object.entries(HOTELS);
  const totalSelected = Object.values(selectedNzd).reduce((a, b) => a + b, 0);
  const regionsBooked = regions.filter(([r, d]) =>
    alreadyBooked[r] || d.st === "confirmed" || customHotels[r]?.st === "booked"
  ).length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl italic font-light text-primary mb-0.5 font-serif">Where to Stay</h2>
        <p className="text-xs text-muted-foreground">
          Researched options at three price levels. Booked regions are collapsed — tap to review.
        </p>
      </div>

      {/* Summary */}
      <div className="bg-card border border-border rounded-xl px-4 py-3 flex gap-4 items-center">
        <div className="text-center">
          <div className="text-[20px] font-bold text-primary leading-none">{regionsBooked}/{regions.length}</div>
          <div className="text-[9px] text-muted-foreground uppercase tracking-wide mt-0.5">Booked</div>
        </div>
        <div className="w-px h-8 bg-border" />
        <div className="flex-1">
          <div className="flex gap-2">
            {regions.map(([r, d]) => {
              const isBooked = alreadyBooked[r] || d.st === "confirmed" || customHotels[r]?.st === "booked";
              const isSelected = customHotels[r]?.st === "selected";
              return (
                <div
                  key={r}
                  title={r}
                  className={cn(
                    "h-2 flex-1 rounded-full transition-all",
                    isBooked ? "bg-primary" : isSelected ? "bg-gold" : "bg-muted"
                  )}
                />
              );
            })}
          </div>
          <div className="flex gap-3 mt-1.5">
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-primary" /><span className="text-[9px] text-muted-foreground">Booked</span></div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-gold" /><span className="text-[9px] text-muted-foreground">Selected</span></div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-muted" /><span className="text-[9px] text-muted-foreground">To do</span></div>
          </div>
        </div>
        {totalSelected > 0 && (
          <>
            <div className="w-px h-8 bg-border" />
            <div className="text-center">
              <div className="text-[16px] font-bold leading-none">${totalSelected.toLocaleString()}</div>
              <div className="text-[9px] text-muted-foreground uppercase tracking-wide mt-0.5">Selected NZD</div>
            </div>
          </>
        )}
      </div>

      {/* Tier filter */}
      <div className="flex gap-1.5 flex-wrap">
        {(["all", ...TIER_ORDER] as const).map(t => {
          const active = activeTier === t;
          const cfg = t !== "all" ? TIER_CONFIG[t] : null;
          const Icon = cfg?.icon;
          return (
            <button
              key={t}
              onClick={() => setActiveTier(t)}
              className={cn(
                "inline-flex items-center gap-1 text-[11px] px-3 py-1.5 rounded-full border font-medium transition-all",
                active
                  ? t === "all"
                    ? "bg-primary text-primary-foreground border-primary"
                    : cn(cfg!.chip, "border font-bold")
                  : "bg-transparent text-muted-foreground border-border hover:border-primary/30"
              )}
            >
              {Icon && <Icon className="w-3 h-3" />}
              {t === "all" ? "All" : cfg!.label}
            </button>
          );
        })}
      </div>

      {/* Region cards */}
      {regions.map(([region, d]) => {
        const cust = customHotels[region];
        const isConfirmedByData = d.st === "confirmed";
        const isBooked = alreadyBooked[region] || isConfirmedByData || cust?.st === "booked";
        const isExpanded = expandedRegions[region] ?? !isBooked; // booked = collapsed by default

        // Find the booked hotel's name
        const bookedOpt = d.opts.find(o => o.bk);
        const bookedHotelName = isConfirmedByData
          ? (bookedOpt?.nm ?? d.cf ?? region)
          : cust?.nm || "Custom hotel";

        // Show only collapsed summary for booked regions
        if (isBooked && !isExpanded) {
          return (
            <div key={region}>
              <BookedCard
                region={region}
                bookedHotelName={bookedHotelName}
                nights={d.n}
                ci={d.ci}
                co={d.co}
                isConfirmed={isConfirmedByData}
                onUnbook={() => {
                  onMarkBooked(region); // toggle off
                  if (cust) onSetCustom(region, { st: "none" });
                }}
              />
              <button
                onClick={() => toggleRegion(region)}
                className="w-full text-[10px] text-muted-foreground text-center py-1.5 hover:text-primary transition-colors flex items-center justify-center gap-1"
              >
                <ChevronDown className="w-3 h-3" /> Show all options
              </button>
            </div>
          );
        }

        const filteredOpts = activeTier === "all"
          ? d.opts
          : d.opts.filter(o => o.tier === activeTier || o.bk || o.rb);

        return (
          <div key={region} className="bg-card rounded-xl overflow-hidden shadow-sm border border-border">
            {/* Region header */}
            <button
              onClick={() => isBooked && toggleRegion(region)}
              className={cn(
                "w-full px-4 py-3 flex justify-between items-start gap-2 text-left",
                isBooked ? "bg-primary text-primary-foreground cursor-pointer" : "bg-primary/90 text-primary-foreground"
              )}
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[14px] font-semibold">{region}</span>
                  {isBooked && (
                    <span className="inline-flex items-center gap-1 text-[9px] px-2 py-0.5 bg-white/20 rounded-full font-medium">
                      <Check className="w-2.5 h-2.5" /> Booked
                    </span>
                  )}
                </div>
                <div className="text-[10px] opacity-75 mt-0.5">
                  {fmtDate(d.ci)} → {fmtDate(d.co)} · {d.n} nights
                  {d.note && <span> · <span className="opacity-60">{d.note.substring(0, 50)}</span></span>}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {!isConfirmedByData && !isBooked && (
                  <button
                    onClick={e => { e.stopPropagation(); onMarkBooked(region); }}
                    className="text-[9px] px-2.5 py-1 rounded border border-white/30 hover:bg-white/15 transition-colors font-medium"
                  >
                    Mark booked
                  </button>
                )}
                {isBooked && <ChevronUp className="w-4 h-4 opacity-60" />}
              </div>
            </button>

            {/* Context note */}
            {d.note && (
              <div className="px-4 py-2 bg-secondary/30 border-b border-border flex items-start gap-1.5">
                <Info className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
                <span className="text-[10px] text-muted-foreground leading-snug">{d.note}</span>
              </div>
            )}

            {/* Tier legend */}
            <div className="flex border-b border-border bg-muted/20 px-4 py-1.5 gap-4">
              {TIER_ORDER.map(t => {
                const cfg = TIER_CONFIG[t];
                const TIcon = cfg.icon;
                const count = d.opts.filter(o => o.tier === t).length;
                if (count === 0) return null;
                return (
                  <div key={t} className="flex items-center gap-1">
                    <TIcon className={cn("w-2.5 h-2.5",
                      t === "budget" ? "text-emerald-600" : t === "mid" ? "text-amber-600" : "text-purple-600"
                    )} />
                    <span className="text-[9px] text-muted-foreground">{count} {cfg.label.toLowerCase()}</span>
                  </div>
                );
              })}
            </div>

            {/* Options */}
            <div className="divide-y divide-border">
              {filteredOpts.length === 0 ? (
                <div className="px-4 py-6 text-center text-[12px] text-muted-foreground">
                  No {activeTier} options for this region
                </div>
              ) : (
                filteredOpts.map((opt, i) => {
                  const isSel = selectedNzd[region] === opt.nzd && opt.nzd > 0;
                  return (
                    <OptionCard
                      key={i}
                      opt={opt}
                      nights={d.n}
                      ci={d.ci}
                      co={d.co}
                      isSel={isSel}
                      onSelect={() => onSelectOption(region, isSel ? 0 : opt.nzd)}
                    />
                  );
                })
              )}
            </div>

            {/* Custom entry */}
            <div className="px-4 py-3 bg-cream/40 border-t border-border">
              <div className="flex justify-between items-center mb-2">
                <span className="text-[10px] font-semibold text-warm uppercase tracking-wide">Add your own find</span>
                <a
                  href={bkDates(region === "Rome Final" ? "hotel Rome near Termini" : `hotel ${region} Italy`, d.ci, d.co)}
                  target="_blank" rel="noopener noreferrer"
                  className="text-[10px] px-3 py-1 rounded-lg bg-primary text-primary-foreground font-semibold hover:opacity-80 transition-opacity inline-flex items-center gap-1"
                >
                  Search Booking.com <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <div className="flex flex-wrap gap-2 items-center">
                <input
                  type="text" placeholder="Hotel name"
                  value={cust?.nm ?? ""}
                  onChange={e => onSetCustom(region, { nm: e.target.value })}
                  className="flex-1 min-w-[120px] text-[12px] px-2.5 py-1.5 rounded-lg border border-border bg-background focus:outline-none focus:ring-1 focus:ring-primary/40"
                />
                <div className="flex items-center gap-1">
                  <span className="text-[11px] text-muted-foreground">$NZD/n</span>
                  <input
                    type="number" placeholder="0"
                    value={cust?.nzd || ""}
                    onChange={e => onSetCustom(region, { nzd: parseInt(e.target.value) || 0 })}
                    className="w-20 text-[12px] px-2.5 py-1.5 rounded-lg border border-border bg-background focus:outline-none focus:ring-1 focus:ring-primary/40"
                  />
                </div>
              </div>

              {cust?.nm && (
                <div className="flex gap-2 mt-2">
                  {(["none", "selected", "booked"] as const).map(st => {
                    const cur = cust?.st ?? "none";
                    const on = cur === st;
                    const cols = {
                      none: "border-muted-foreground/40 text-muted-foreground",
                      selected: "border-gold text-brown",
                      booked: "border-primary text-primary",
                    };
                    return (
                      <button
                        key={st}
                        onClick={() => onSetCustom(region, { st })}
                        className={cn(
                          "inline-flex items-center gap-1 text-[11px] px-3 py-1 rounded-lg border transition-all",
                          on ? `${cols[st]} font-bold border-2 bg-primary/5` : "border-border text-muted-foreground hover:border-primary/30"
                        )}
                      >
                        {on && <CircleDot className="w-2.5 h-2.5" />}
                        {st === "none" ? "Not booked" : st === "selected" ? "Selected" : "Booked ✓"}
                      </button>
                    );
                  })}
                </div>
              )}

              {cust?.nzd && cust.nzd > 0 && (
                <div className={cn(
                  "inline-flex items-center gap-1 text-[11px] font-semibold mt-2",
                  cust.st === "booked" ? "text-primary" : cust.st === "selected" ? "text-brown" : "text-muted-foreground"
                )}>
                  {cust.st === "booked" && <Check className="w-3 h-3" />}
                  {cust.nm || "Your hotel"}: ${cust.nzd}/n × {d.n}n = ${(cust.nzd * d.n).toLocaleString()} NZD
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
