import { Day, HotelEntry, Hotels } from "@/data/tripData";

interface Props {
  days: Day[];
  hotels: Hotels;
  customNzd: Record<string, { nm: string; nzd: number; st?: string }>;
  selectedNzd: Record<string, number>;
  alreadyBooked: Record<string, boolean>;
  pax: number;
  flightPerPax: number;
}

export function TripHeader({ days, hotels, customNzd, selectedNzd, alreadyBooked, pax, flightPerPax }: Props) {
  const bookedCount = days.reduce((s, d) => s + d.sg.filter(a => a.bk).length, 0);
  const totalActs   = days.reduce((s, d) => s + d.sg.length, 0);
  const actCost     = days.reduce((s, d) => s + d.sg.reduce((s2, a) => s2 + a.c, 0), 0);

  const hotelEntries = Object.entries(hotels) as [string, HotelEntry][];
  const hBooked  = hotelEntries.filter(([r, d]) => {
    const c = customNzd[r];
    return alreadyBooked[r] || d.st === "confirmed" || c?.st === "booked";
  }).length;
  const hSelected = hotelEntries.filter(([r]) => customNzd[r]?.st === "selected").length;
  const hTotal = hotelEntries.length;

  const accomNzd = hotelEntries.reduce((s, [r, d]) => {
    const cNzd = customNzd[r]?.nzd ?? 0;
    const sNzd = selectedNzd[r] ?? 0;
    return s + (Math.max(cNzd, sNzd) * d.n);
  }, 0);
  const flightTotal = flightPerPax * pax;
  const grandTotal  = accomNzd > 0 ? flightTotal + accomNzd + Math.round(actCost * 1.85) : 0;

  const hotelSub = hBooked === hTotal
    ? "All booked"
    : `${hSelected > 0 ? hSelected + " selected, " : ""}${hTotal - hBooked - hSelected} to book`;

  const stat = (label: string, value: string, sub?: string) => (
    <div className="flex flex-col items-start bg-white/10 rounded-lg px-3 py-2.5 min-w-[76px] border border-white/15">
      <span className="text-[15px] font-bold font-sans text-gold leading-tight">{value}</span>
      <span className="text-[9px] uppercase tracking-[0.08em] opacity-55 mt-0.5 font-sans">{label}</span>
      {sub && <span className="text-[9px] opacity-38 mt-0.5 leading-tight font-sans">{sub}</span>}
    </div>
  );

  return (
    <header className="relative overflow-hidden bg-gradient-to-br from-foreground via-primary to-primary-light py-8 px-5 text-primary-foreground">
      {/* Texture — gold radial hints */}
      <div className="absolute inset-0 opacity-[0.06] pointer-events-none"
        style={{ backgroundImage: "radial-gradient(ellipse at 15% 60%, hsl(34 48% 56% / 0.6) 0%, transparent 55%), radial-gradient(ellipse at 85% 25%, hsl(34 48% 56% / 0.25) 0%, transparent 45%)" }} />

      <div className="relative max-w-3xl mx-auto">
        <div className="fade-up">
          <h1 className="text-[32px] font-light italic leading-none mb-1 font-serif tracking-wide">Kate &amp; Adrian</h1>
          <p className="text-[18px] font-sans font-light opacity-75 tracking-[0.18em] uppercase">Italia 2026</p>
          <p className="text-[11px] font-sans opacity-45 tracking-[0.06em] mt-2">25 May – 10 Jun · 17 days</p>
        </div>

        <div className="flex flex-wrap gap-2 mt-5 fade-up delay-2">
          {stat("Activities", `${bookedCount}/${totalActs}`)}
          {stat("Hotels", `${hBooked}/${hTotal}`, hotelSub)}
          {stat("Flights", `$${flightTotal.toLocaleString()}`, `${pax} pax`)}
          {stat("Accom", accomNzd > 0 ? `$${accomNzd.toLocaleString()}` : "—", "NZD")}
          {stat("Est. Total", grandTotal > 0 ? `$${grandTotal.toLocaleString()}` : "—", "NZD")}
        </div>
      </div>
    </header>
  );
}
