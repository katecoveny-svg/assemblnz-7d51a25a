// Custom SVG icon set — brand colours only (burgundy / brown / gold)
// Drop-in replacement for emoji and generic letter badges throughout the app.

import { cn } from "@/lib/utils";
import { ActivityType } from "@/data/tripData";

// ── Activity type icons ─────────────────────────────────────────────

const icons = {
  // Ticket / entry — stylised arch
  ticket: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <rect x="1.5" y="4.5" width="13" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M5.5 4.5v-.5a2.5 2.5 0 0 1 5 0v.5" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M5.5 11.5v.5a2.5 2.5 0 0 0 5 0v-.5" stroke="currentColor" strokeWidth="1.4"/>
      <line x1="5.5" y1="8" x2="10.5" y2="8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  // Food / dining — fork and knife
  food: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M5 2v4a2 2 0 0 0 2 2v6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <path d="M5 2v4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <line x1="7" y1="2" x2="7" y2="6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <line x1="9" y1="2" x2="9" y2="6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <line x1="11" y1="2" x2="11" y2="14" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <path d="M9 6a2 2 0 0 0 2-2" stroke="currentColor" strokeWidth="1.4"/>
    </svg>
  ),
  // Experience — star spark
  experience: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M8 2v2M8 12v2M2 8h2M12 8h2M3.93 3.93l1.41 1.41M10.66 10.66l1.41 1.41M3.93 12.07l1.41-1.41M10.66 5.34l1.41-1.41" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <circle cx="8" cy="8" r="2.5" stroke="currentColor" strokeWidth="1.4"/>
    </svg>
  ),
  // Transport / route — compass
  transport: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M10.5 5.5 9 9l-3.5 1.5L7 7l3.5-1.5z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round"/>
    </svg>
  ),
  // Free — open hand / gift
  free: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M8 2.5A1.5 1.5 0 0 1 9.5 4H8M8 2.5A1.5 1.5 0 0 0 6.5 4H8M8 2.5V4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
      <rect x="5" y="4" width="6" height="1.5" rx=".75" stroke="currentColor" strokeWidth="1.3"/>
      <rect x="5.5" y="5.5" width="5" height="6" rx=".75" stroke="currentColor" strokeWidth="1.3"/>
      <line x1="8" y1="5.5" x2="8" y2="11.5" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round"/>
    </svg>
  ),
  // Map pin for location
  mapPin: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M8 1.5C5.79 1.5 4 3.29 4 5.5c0 3.25 4 9 4 9s4-5.75 4-9c0-2.21-1.79-4-4-4z" stroke="currentColor" strokeWidth="1.4"/>
      <circle cx="8" cy="5.5" r="1.5" stroke="currentColor" strokeWidth="1.3"/>
    </svg>
  ),
  // Urgent / warning
  urgent: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M8 2L1.5 13.5h13L8 2z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
      <line x1="8" y1="7" x2="8" y2="10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <circle cx="8" cy="11.8" r=".8" fill="currentColor"/>
    </svg>
  ),
  // Plane for flights / travel
  plane: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M2 9.5l2.5-1L7 13l1.5-.5V10l5-3.5V5l-1.5.5-2 2.5-3-1-1-1.5-1 .5.5 2L4 9l-2 .5z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round"/>
    </svg>
  ),
  // Hotel / bed
  hotel: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <rect x="1.5" y="8" width="13" height="5.5" rx="1" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M1.5 8V5a1 1 0 0 1 1-1H5a1 1 0 0 1 1 1v3" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M6 8V6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2" stroke="currentColor" strokeWidth="1.4"/>
      <line x1="1.5" y1="11" x2="14.5" y2="11" stroke="currentColor" strokeWidth="1.2"/>
    </svg>
  ),
  // Budget / coins
  budget: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <circle cx="9" cy="9" r="5" stroke="currentColor" strokeWidth="1.4"/>
      <circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.4"/>
      <path d="M7 5v.5M7 9.5V10M5.5 7h3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  // Clothes / hanger
  clothes: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M8 3.5A1.5 1.5 0 0 1 9.5 5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <path d="M9.5 5L14 9H2l4.5-4" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/>
      <line x1="8" y1="2" x2="8" y2="3.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <rect x="2" y="9" width="12" height="5" rx=".75" stroke="currentColor" strokeWidth="1.4"/>
    </svg>
  ),
  // Documents / passport
  documents: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <rect x="3" y="1.5" width="10" height="13" rx="1.5" stroke="currentColor" strokeWidth="1.4"/>
      <circle cx="8" cy="6.5" r="2" stroke="currentColor" strokeWidth="1.3"/>
      <line x1="5" y1="11" x2="11" y2="11" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
      <line x1="5.5" y1="12.5" x2="10.5" y2="12.5" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round"/>
    </svg>
  ),
  // Toiletries / bottle
  toiletries: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M6 4h4v1.5a2 2 0 0 1 2 2V12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7.5a2 2 0 0 1 2-2V4z" stroke="currentColor" strokeWidth="1.4"/>
      <rect x="6.5" y="2" width="3" height="2" rx=".5" stroke="currentColor" strokeWidth="1.2"/>
      <line x1="7" y1="9" x2="9" y2="9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
    </svg>
  ),
  // Tech / device
  tech: (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <rect x="2" y="3.5" width="12" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.4"/>
      <line x1="5" y1="13.5" x2="11" y2="13.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <line x1="8" y1="11.5" x2="8" y2="13.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
      <circle cx="8" cy="7.5" r="1.5" stroke="currentColor" strokeWidth="1.2"/>
    </svg>
  ),
};

// ── Activity type badge ─────────────────────────────────────────────

const BADGE_CONFIG: Record<ActivityType, { label: string; icon: keyof typeof icons; classes: string }> = {
  free:       { label: "Free",       icon: "free",       classes: "bg-gold/10 text-brown border-gold/30" },
  ticket:     { label: "Ticket",     icon: "ticket",     classes: "bg-primary/10 text-primary border-primary/30" },
  food:       { label: "Dine",       icon: "food",       classes: "bg-brown/10 text-brown border-brown/30" },
  experience: { label: "Experience", icon: "experience", classes: "bg-gold/15 text-brown border-gold/40" },
  transport:  { label: "Route",      icon: "transport",  classes: "bg-primary/8 text-primary border-primary/20" },
};

export function TypeBadge({ type, className }: { type: ActivityType; className?: string }) {
  const { label, icon, classes } = BADGE_CONFIG[type];
  return (
    <span className={cn("inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-semibold tracking-wide border", classes, className)}>
      <span className="w-3 h-3 shrink-0">{icons[icon]}</span>
      {label}
    </span>
  );
}

// ── Named icon components ───────────────────────────────────────────

export function Icon({ name, className }: { name: keyof typeof icons; className?: string }) {
  return (
    <span className={cn("inline-flex items-center justify-center", className)}>
      {icons[name]}
    </span>
  );
}

// Map stop icons — round branded pin with SVG symbol
export const STOP_ICONS: Record<string, keyof typeof icons> = {
  "Milan":       "plane",
  "Lake Garda":  "mapPin",
  "Florence":    "experience",
  "Tuscany":     "food",
  "Rome":        "ticket",
  "Sorrento":    "transport",
  "Rome Final":  "plane",
};

export { icons };
