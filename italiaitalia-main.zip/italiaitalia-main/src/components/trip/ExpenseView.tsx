import { useState } from "react";
import { Plus, Trash2, Plane, Hotel, Train, Ticket, Utensils, ShoppingBag, CircleHelp, TrendingUp, ArrowLeftRight } from "lucide-react";
import { cn } from "@/lib/utils";

export type ExpenseCategory = "accommodation" | "transport" | "food" | "activities" | "shopping" | "other";
export type Expense = {
  id: string;
  amount_eur: number;
  category: ExpenseCategory;
  paid_by: "k" | "a";
  description: string;
  expense_date: string;
  created_by: string;
};

const EUR_TO_NZD = 1.85;

const CAT_CONFIG: Record<ExpenseCategory, { label: string; icon: React.ReactNode; col: string; bg: string }> = {
  accommodation: { label: "Accommodation", icon: <Hotel className="w-3.5 h-3.5" />,   col: "text-primary",     bg: "bg-primary" },
  transport:     { label: "Transport",      icon: <Train className="w-3.5 h-3.5" />,   col: "text-brown",       bg: "bg-brown" },
  food:          { label: "Food & Drink",   icon: <Utensils className="w-3.5 h-3.5" />, col: "text-brown-light", bg: "bg-brown-light" },
  activities:    { label: "Activities",     icon: <Ticket className="w-3.5 h-3.5" />,  col: "text-primary",     bg: "bg-primary" },
  shopping:      { label: "Shopping",       icon: <ShoppingBag className="w-3.5 h-3.5" />, col: "text-gold",    bg: "bg-gold" },
  other:         { label: "Other",          icon: <CircleHelp className="w-3.5 h-3.5" />, col: "text-muted-foreground", bg: "bg-muted" },
};

interface Props {
  expenses: Expense[];
  onAdd: (e: Omit<Expense, "id" | "created_by">) => void;
  onDelete: (id: string) => void;
  currentUserRole: "k" | "a";
}

export function ExpenseView({ expenses, onAdd, onDelete, currentUserRole }: Props) {
  const [form, setForm] = useState({
    description: "",
    amount_eur: "",
    category: "food" as ExpenseCategory,
    paid_by: currentUserRole,
    expense_date: new Date().toISOString().slice(0, 10),
  });
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = () => {
    const amt = parseFloat(form.amount_eur);
    if (!form.description.trim() || isNaN(amt) || amt <= 0) return;
    onAdd({
      description: form.description.trim(),
      amount_eur: amt,
      category: form.category,
      paid_by: form.paid_by as "k" | "a",
      expense_date: form.expense_date,
    });
    setForm(f => ({ ...f, description: "", amount_eur: "" }));
    setShowForm(false);
  };

  // Totals
  const kTotal = expenses.filter(e => e.paid_by === "k").reduce((s, e) => s + e.amount_eur, 0);
  const aTotal = expenses.filter(e => e.paid_by === "a").reduce((s, e) => s + e.amount_eur, 0);
  const grandEur = kTotal + aTotal;
  const grandNzd = grandEur * EUR_TO_NZD;
  const eachShare = grandEur / 2;
  const kOwes = aTotal > eachShare ? aTotal - eachShare : 0;
  const aOwes = kTotal > eachShare ? kTotal - eachShare : 0;

  // By category
  const byCat = expenses.reduce<Record<string, number>>((acc, e) => {
    acc[e.category] = (acc[e.category] ?? 0) + e.amount_eur;
    return acc;
  }, {});

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl italic font-light text-primary font-serif">Expenses</h2>
        <button
          onClick={() => setShowForm(v => !v)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary text-primary-foreground text-[11px] font-semibold transition-all active:scale-95 hover:bg-primary/90"
        >
          <Plus className="w-3 h-3" /> Add Expense
        </button>
      </div>

      {/* Add expense form */}
      {showForm && (
        <div className="bg-card border border-border rounded-xl p-4 space-y-3 shadow-sm">
          <div className="text-[11px] font-semibold text-warm uppercase tracking-widest">New Expense</div>
          <input
            type="text"
            placeholder="Description (e.g. Uffizi tickets)"
            value={form.description}
            onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-[13px] placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-[13px]">€</span>
              <input
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={form.amount_eur}
                onChange={e => setForm(f => ({ ...f, amount_eur: e.target.value }))}
                className="w-full rounded-lg border border-input bg-background pl-7 pr-3 py-2 text-[13px] placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <input
              type="date"
              value={form.expense_date}
              onChange={e => setForm(f => ({ ...f, expense_date: e.target.value }))}
              className="flex-1 rounded-lg border border-input bg-background px-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={form.category}
              onChange={e => setForm(f => ({ ...f, category: e.target.value as ExpenseCategory }))}
              className="flex-1 rounded-lg border border-input bg-background px-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-ring"
            >
              {Object.entries(CAT_CONFIG).map(([k, v]) => (
                <option key={k} value={k}>{v.label}</option>
              ))}
            </select>
            <div className="flex gap-1.5 items-center">
              {(["k", "a"] as const).map(who => (
                <button
                  key={who}
                  onClick={() => setForm(f => ({ ...f, paid_by: who }))}
                  className={cn(
                    "w-9 h-9 rounded-full text-[11px] font-bold border-2 transition-all",
                    form.paid_by === who ? "bg-primary border-primary text-primary-foreground" : "border-border text-foreground"
                  )}
                >
                  {who === "k" ? "K" : "A"}
                </button>
              ))}
              <span className="text-[10px] text-muted-foreground ml-0.5">paid</span>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleSubmit}
              className="flex-1 rounded-lg bg-primary text-primary-foreground py-2 text-[13px] font-semibold hover:bg-primary/90 transition-colors active:scale-95"
            >
              Save
            </button>
            <button
              onClick={() => setShowForm(false)}
              className="px-4 rounded-lg border border-border text-[13px] text-muted-foreground hover:bg-secondary transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Grand total */}
      <div className="bg-primary rounded-xl p-5 text-primary-foreground shadow-md">
        <div className="text-[10px] opacity-60 tracking-widest uppercase mb-1">Total Spent</div>
        <div className="text-4xl font-bold text-gold font-serif">€{grandEur.toFixed(2)}</div>
        <div className="text-[11px] opacity-60 mt-1">≈ ${grandNzd.toFixed(0)} NZD at ×{EUR_TO_NZD}</div>
      </div>

      {/* Settle-up */}
      {grandEur > 0 && (
        <div className="bg-card border border-border rounded-xl p-4 shadow-sm space-y-3">
          <div className="flex items-center gap-2 text-[11px] font-semibold text-warm uppercase tracking-widest">
            <ArrowLeftRight className="w-3.5 h-3.5" /> Settle Up
          </div>
          <div className="flex gap-3">
            <div className="flex-1 bg-secondary rounded-lg p-3 text-center">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground text-[11px] font-bold flex items-center justify-center mx-auto mb-1.5">K</div>
              <div className="text-base font-bold">€{kTotal.toFixed(2)}</div>
              <div className="text-[10px] text-muted-foreground">Kate paid</div>
            </div>
            <div className="flex-1 bg-secondary rounded-lg p-3 text-center">
              <div className="w-8 h-8 rounded-full bg-gold text-white text-[11px] font-bold flex items-center justify-center mx-auto mb-1.5">A</div>
              <div className="text-base font-bold">€{aTotal.toFixed(2)}</div>
              <div className="text-[10px] text-muted-foreground">Adrian paid</div>
            </div>
          </div>
          <div className={cn(
            "rounded-lg p-3 text-center text-[13px] font-semibold",
            (kOwes > 0 || aOwes > 0) ? "bg-gold/15 border border-gold/30 text-brown" : "bg-secondary text-muted-foreground"
          )}>
            {kOwes > 0.01
              ? `Kate owes Adrian €${kOwes.toFixed(2)} (≈$${(kOwes * EUR_TO_NZD).toFixed(0)} NZD)`
              : aOwes > 0.01
              ? `Adrian owes Kate €${aOwes.toFixed(2)} (≈$${(aOwes * EUR_TO_NZD).toFixed(0)} NZD)`
              : "All square! 🎉"}
          </div>
        </div>
      )}

      {/* By category breakdown */}
      {Object.keys(byCat).length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-warm uppercase tracking-widest mb-2">
            <TrendingUp className="w-3.5 h-3.5" /> By Category
          </div>
          <div className="space-y-1.5">
            {Object.entries(byCat)
              .sort(([, a], [, b]) => b - a)
              .map(([cat, eur]) => {
                const cfg = CAT_CONFIG[cat as ExpenseCategory];
                const pct = grandEur > 0 ? Math.round((eur / grandEur) * 100) : 0;
                return (
                  <div key={cat} className="bg-card border border-border rounded-lg px-3 py-2 flex items-center gap-3 shadow-sm">
                    <span className={cn("w-7 h-7 rounded-lg flex items-center justify-center text-white shrink-0", cfg.bg)}>
                      {cfg.icon}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between text-[12px] font-medium mb-0.5">
                        <span>{cfg.label}</span>
                        <span className="font-bold">€{eur.toFixed(2)}</span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className={cn("h-full rounded-full transition-all", cfg.bg)} style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                    <div className="text-[10px] text-muted-foreground shrink-0 w-8 text-right">{pct}%</div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Expense list */}
      <div>
        <div className="text-[11px] font-semibold text-warm uppercase tracking-widest mb-2">All Expenses</div>
        {expenses.length === 0 ? (
          <div className="bg-card border border-border rounded-xl p-8 text-center">
            <Plane className="w-8 h-8 mx-auto mb-3 text-muted-foreground opacity-40" />
            <p className="text-[13px] text-muted-foreground">No expenses logged yet.</p>
            <p className="text-[11px] text-muted-foreground mt-1">Add your first expense above.</p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {[...expenses]
              .sort((a, b) => new Date(b.expense_date).getTime() - new Date(a.expense_date).getTime())
              .map(exp => {
                const cfg = CAT_CONFIG[exp.category];
                const nzd = exp.amount_eur * EUR_TO_NZD;
                return (
                  <div key={exp.id} className="bg-card border border-border rounded-lg px-3 py-2.5 flex items-center gap-3 shadow-sm group">
                    <span className={cn("w-7 h-7 rounded-lg flex items-center justify-center text-white shrink-0", cfg.bg)}>
                      {cfg.icon}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-[13px] font-medium truncate">{exp.description}</div>
                      <div className="text-[10px] text-muted-foreground">
                        {new Date(exp.expense_date).toLocaleDateString("en-NZ", { day: "numeric", month: "short" })}
                        {" · "}{cfg.label}
                        {" · "}<span className={cn("font-semibold", exp.paid_by === "k" ? "text-primary" : "text-gold")}>{exp.paid_by === "k" ? "Kate" : "Adrian"} paid</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-[13px] font-bold">€{exp.amount_eur.toFixed(2)}</div>
                      <div className="text-[10px] text-muted-foreground">${nzd.toFixed(0)} NZD</div>
                    </div>
                    <button
                      onClick={() => onDelete(exp.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded-full hover:bg-destructive/10 text-destructive ml-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
          </div>
        )}
      </div>
    </div>
  );
}
