import { useState } from "react";
import { Day, ActivityType, TRANSPORT, ROUTES, GEMS } from "@/data/tripData";
import { TypeBadge } from "./TypeBadge";
import { REGION_COLORS } from "@/data/tripData";
import { cn } from "@/lib/utils";
import { MapPin, ExternalLink, Plus, Trash2, Gem, Check, AlertTriangle } from "lucide-react";

const ACT_FILTER: { value: "all" | ActivityType; label: string }[] = [
  { value: "all", label: "All" },
  { value: "ticket", label: "Tickets" },
  { value: "food", label: "Dining" },
  { value: "experience", label: "Experiences" },
  { value: "transport", label: "Routes" },
  { value: "free", label: "Free" },
];

const CAT_STYLE: Record<string, string> = {
  must: "bg-primary/10 text-primary border-primary/30",
  wow: "bg-gold/10 text-brown border-gold/30",
  gem: "bg-brown/10 text-brown border-brown/30",
};
const CAT_LABEL: Record<string, string> = { must: "Must", wow: "Wow", gem: "Hidden Gem" };

interface Props {
  days: Day[];
  votes: Record<string, { k?: boolean; a?: boolean }>;
  customActs: Record<string, { nm: string; c: number; tp: ActivityType; bk: boolean }[]>;
  onToggle: (di: number, si: number) => void;
  onVote: (di: number, si: number, who: "k" | "a") => void;
  onAddCustom: (di: number, nm: string, cost: number) => void;
  onRemoveCustom: (di: number, ci: number) => void;
  onToggleCustom: (di: number, ci: number) => void;
}

export function TimelineView({ days, votes, customActs, onToggle, onVote, onAddCustom, onRemoveCustom, onToggleCustom }: Props) {
  const [sel, setSel] = useState(0);
  const [filter, setFilter] = useState<"all" | ActivityType>("all");
  const [addNm, setAddNm] = useState("");
  const [addCost, setAddCost] = useState("");

  const cur = days[sel];
  const regionColor = REGION_COLORS[cur.rg] ?? "#5C1A2A";
  const transport = TRANSPORT[cur.dt];
  const routes = ROUTES[cur.dt];
  const gems = GEMS[cur.rg] ?? [];
  const myActs = customActs["d" + sel] ?? [];

  const filtered = filter === "all" ? cur.sg : cur.sg.filter(sg => sg.tp === filter);

  // Booking progress for this day
  const totalBookable = cur.sg.filter(a => a.lnk || a.bk).length;
  const bookedCount = cur.sg.filter(a => a.bk).length;
  const urgentUnbooked = cur.sg.filter(a => a.nt?.includes("⚠") && !a.bk);

  const handleAdd = () => {
    if (!addNm.trim()) return;
    onAddCustom(sel, addNm.trim(), parseInt(addCost) || 0);
    setAddNm(""); setAddCost("");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-4">
      {/* ── Day selector sidebar ── */}
      <div className="flex flex-col gap-0.5 max-h-[75vh] overflow-y-auto pr-1">
        {days.map((d, i) => {
          const rc = REGION_COLORS[d.rg] ?? "#5C1A2A";
          const dayBooked = d.sg.filter(a => a.bk).length;
          const dayUrgent = d.sg.filter(a => a.nt?.includes("⚠") && !a.bk).length;
          const isToday = i === sel;

          return (
            <button
              key={i}
              onClick={() => setSel(i)}
              className={cn(
                "text-left px-3 py-2.5 rounded-xl transition-all border",
                isToday
                  ? "text-primary-foreground shadow-sm border-transparent"
                  : "hover:bg-secondary/60 text-foreground border-transparent hover:border-border"
              )}
              style={isToday ? { background: rc } : undefined}
            >
              <div className="flex justify-between items-center gap-2">
                <span className={cn("text-[10px] font-medium tracking-wide", isToday ? "opacity-60" : "text-muted-foreground")}>{d.dt}</span>
                <div className="flex items-center gap-1">
                  {dayUrgent > 0 && !isToday && (
                    <span className="w-4 h-4 rounded-full bg-destructive/15 flex items-center justify-center">
                      <AlertTriangle className="w-2.5 h-2.5 text-destructive" />
                    </span>
                  )}
                  {dayBooked > 0 && (
                    <span className={cn(
                      "text-[9px] font-semibold px-1.5 rounded-full",
                      isToday ? "bg-white/20 text-white" : "bg-primary/10 text-primary"
                    )}>
                      {dayBooked}/{d.sg.length}
                    </span>
                  )}
                </div>
              </div>
              <div className={cn("text-[12px] font-semibold leading-snug mt-0.5", isToday ? "" : "text-foreground")}>{d.act}</div>
              <div className={cn("text-[10px] mt-0.5", isToday ? "opacity-55" : "text-muted-foreground")}>{d.rg}</div>
            </button>
          );
        })}
      </div>

      {/* ── Day detail ── */}
      <div className="space-y-3">
        {/* Day hero */}
        <div className="rounded-xl overflow-hidden shadow-sm" style={{ background: regionColor }}>
          <div className="px-4 py-4 text-white">
            <div className="text-[10px] opacity-50 tracking-widest uppercase">{cur.dt} · {cur.dy}</div>
            <h2 className="text-[18px] font-semibold mt-1 leading-tight">{cur.act}</h2>
            <div className="text-[11px] opacity-65 mt-1">{cur.stay}</div>
            {/* Booking progress bar */}
            {totalBookable > 0 && (
              <div className="mt-3">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[9px] opacity-55 uppercase tracking-wide">Day progress</span>
                  <span className="text-[9px] opacity-70">{bookedCount}/{cur.sg.length} confirmed</span>
                </div>
                <div className="h-1 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-white/60 rounded-full transition-all duration-500"
                    style={{ width: `${cur.sg.length > 0 ? (bookedCount / cur.sg.length) * 100 : 0}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Urgent alert */}
        {urgentUnbooked.length > 0 && (
          <div className="flex items-start gap-2 bg-destructive/8 border border-destructive/25 rounded-xl px-3 py-2.5">
            <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
            <div>
              <div className="text-[12px] font-semibold text-destructive">
                {urgentUnbooked.length} item{urgentUnbooked.length > 1 ? "s" : ""} need booking on this day
              </div>
              <div className="text-[10px] text-muted-foreground mt-0.5">
                {urgentUnbooked.map(a => a.nm).join(" · ")}
              </div>
            </div>
          </div>
        )}

        {/* Transport tip */}
        {transport && (
          <div className="bg-card rounded-xl p-3.5 border border-border shadow-sm">
            <div className="flex items-start gap-2.5">
              <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-primary/10 text-primary text-[10px] font-bold flex-shrink-0 mt-0.5">{transport.ic}</span>
              <div>
                <div className="text-[13px] font-semibold">{transport.s}</div>
                <div className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{transport.d}</div>
                <div className="text-[11px] text-brown font-medium mt-1.5 italic border-l-2 border-gold/50 pl-2 leading-snug">{transport.t}</div>
              </div>
            </div>
          </div>
        )}

        {/* Route options */}
        {routes && (
          <div className="bg-card rounded-xl border border-border overflow-hidden shadow-sm">
            <div className="px-4 py-2.5 border-b border-border bg-secondary/40">
              <span className="text-[11px] font-semibold text-warm tracking-wide">{routes.from} → {routes.to}</span>
            </div>
            <div className="divide-y divide-border">
              {routes.opts.map((o, i) => (
                <div key={i} className="px-4 py-3 flex justify-between items-start gap-3">
                  <div className="flex-1">
                    <div className="text-[12px] font-semibold">{o.mode}</div>
                    <div className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{o.detail}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                    {o.cost && <span className="text-[11px] font-semibold text-terra">{o.cost}</span>}
                    {o.lnk && (
                      <a href={o.lnk} target="_blank" rel="noopener noreferrer"
                        className="text-[10px] px-2.5 py-1 rounded-lg bg-primary text-primary-foreground font-semibold inline-flex items-center gap-1 hover:opacity-80 transition-opacity">
                        Book <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Activity type filter */}
        <div className="flex flex-wrap gap-1.5">
          {ACT_FILTER.map(f => (
            <button key={f.value} onClick={() => setFilter(f.value)}
              className={cn(
                "text-[10px] px-3 py-1.5 rounded-full border transition-all",
                filter === f.value
                  ? "bg-primary text-primary-foreground border-primary font-semibold"
                  : "bg-card text-muted-foreground border-border hover:border-primary/40"
              )}>
              {f.label}
            </button>
          ))}
        </div>

        {/* Activities list */}
        <div className="space-y-2.5">
          {filtered.map((act, i) => {
            const origIdx = cur.sg.indexOf(act);
            const vk = votes[`${sel}-${origIdx}`];
            const isUrgent = act.nt?.includes("⚠");
            const needsBooking = !!act.lnk && !act.bk;

            return (
              <div
                key={i}
                className={cn(
                  "bg-card rounded-xl border shadow-sm transition-all duration-200",
                  act.bk
                    ? "border-primary/25 bg-primary/[0.03]"
                    : isUrgent
                      ? "border-destructive/35"
                      : "border-border"
                )}
              >
                <div className="p-3.5">
                  {/* Top row: toggle + name + cost */}
                  <div className="flex items-start gap-3">
                    {/* Booking toggle — larger, more prominent */}
                    <button
                      onClick={() => onToggle(sel, origIdx)}
                      className={cn(
                        "shrink-0 w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all mt-0.5",
                        act.bk
                          ? "bg-primary border-primary text-primary-foreground shadow-sm"
                          : isUrgent
                            ? "border-destructive/50 hover:border-destructive hover:bg-destructive/5"
                            : "border-border hover:border-primary"
                      )}
                    >
                      {act.bk && <Check className="w-3.5 h-3.5" />}
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <TypeBadge type={act.tp} />
                        {isUrgent && !act.bk && (
                          <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.5 rounded border bg-destructive/10 text-destructive border-destructive/25 font-semibold">
                            <AlertTriangle className="w-2.5 h-2.5" /> Urgent
                          </span>
                        )}
                        <span className={cn(
                          "text-[13px] font-semibold leading-tight",
                          act.bk ? "line-through opacity-50" : ""
                        )}>
                          {act.nm}
                        </span>
                        {act.c > 0 && (
                          <span className="text-[11px] text-muted-foreground font-medium">€{act.c}</span>
                        )}
                      </div>

                      {act.nt && (
                        <p className={cn(
                          "text-[11px] mt-1 leading-snug",
                          isUrgent && !act.bk ? "text-destructive/80 font-medium" : "text-muted-foreground"
                        )}>
                          {act.nt.replace("⚠ ", "")}
                        </p>
                      )}

                      {/* Action row */}
                      <div className="flex gap-1.5 mt-2 flex-wrap items-center">
                        {act.lnk && !act.bk && (
                          <a href={act.lnk} target="_blank" rel="noopener noreferrer"
                            className={cn(
                              "inline-flex items-center gap-1 text-[10px] px-3 py-1.5 rounded-lg font-semibold hover:opacity-80 transition-opacity",
                              isUrgent
                                ? "bg-destructive text-white"
                                : "bg-primary text-primary-foreground"
                            )}>
                            Book now <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                        {act.lnk && act.bk && (
                          <a href={act.lnk} target="_blank" rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-lg border border-border text-muted-foreground hover:border-primary/40 transition-colors">
                            View booking <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                        {act.map && (
                          <a href={act.map} target="_blank" rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-lg border border-border text-muted-foreground hover:border-primary/40 transition-colors">
                            <MapPin className="w-3 h-3" /> Map
                          </a>
                        )}

                        {/* Who's keen votes */}
                        <div className="ml-auto flex gap-1.5">
                          {(["k", "a"] as const).map(who => {
                            const on = vk?.[who];
                            return (
                              <button
                                key={who}
                                onClick={() => onVote(sel, origIdx, who)}
                                className={cn(
                                  "text-[9px] px-2 py-1 rounded-lg border transition-all font-medium",
                                  on
                                    ? who === "k"
                                      ? "border-primary bg-primary/10 text-primary"
                                      : "border-gold bg-gold/15 text-brown"
                                    : "border-border text-muted-foreground hover:border-primary/30"
                                )}
                              >
                                {on ? "✓ " : ""}{who === "k" ? "Kate" : "Adrian"}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Custom activities */}
          {myActs.map((act, ci) => (
            <div key={ci} className={cn(
              "bg-card rounded-xl border p-3.5 shadow-sm",
              act.bk ? "border-primary/25 bg-primary/[0.03]" : "border-gold/40"
            )}>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => onToggleCustom(sel, ci)}
                  className={cn(
                    "shrink-0 w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all",
                    act.bk ? "bg-primary border-primary text-primary-foreground" : "border-border hover:border-primary"
                  )}
                >
                  {act.bk && <Check className="w-3.5 h-3.5" />}
                </button>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <TypeBadge type={act.tp} />
                    <span className={cn("text-[13px] font-semibold", act.bk && "line-through opacity-50")}>{act.nm}</span>
                    {act.c > 0 && <span className="text-[11px] text-muted-foreground">€{act.c}</span>}
                  </div>
                  <span className="text-[9px] text-gold font-medium">Added by you</span>
                </div>
                <button
                  onClick={() => onRemoveCustom(sel, ci)}
                  className="w-7 h-7 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:border-destructive/40 hover:text-destructive hover:bg-destructive/5 transition-all"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}

          {/* Add custom activity */}
          <div className="bg-card rounded-xl border border-dashed border-border p-3.5">
            <div className="text-[11px] font-semibold text-muted-foreground mb-2">Add your own activity</div>
            <div className="flex gap-2 flex-wrap">
              <input
                value={addNm}
                onChange={e => setAddNm(e.target.value)}
                placeholder="e.g. Cooking class, boat trip…"
                className="flex-1 min-w-[140px] text-[12px] px-3 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-1 focus:ring-primary/40"
                onKeyDown={e => e.key === "Enter" && handleAdd()}
              />
              <input
                value={addCost}
                onChange={e => setAddCost(e.target.value)}
                type="number"
                placeholder="€ cost"
                className="w-20 text-[12px] px-3 py-2 rounded-lg border border-border bg-background focus:outline-none focus:ring-1 focus:ring-primary/40"
                onKeyDown={e => e.key === "Enter" && handleAdd()}
              />
              <button
                onClick={handleAdd}
                className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-[12px] font-semibold hover:opacity-80 transition-opacity flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
          </div>
        </div>

        {/* Hidden gems */}
        {gems.length > 0 && (
          <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
            <div className="px-4 py-2.5 border-b border-border bg-secondary/30 flex items-center gap-1.5">
              <Gem className="w-3.5 h-3.5 text-gold" />
              <span className="text-[11px] font-semibold text-warm tracking-wide">Hidden Gems — {cur.rg}</span>
            </div>
            <div className="divide-y divide-border">
              {gems.map((g, i) => (
                <div key={i} className="px-4 py-3 flex items-start gap-3">
                  <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold flex-shrink-0 mt-0.5", CAT_STYLE[g.cat])}>
                    {CAT_LABEL[g.cat]}
                  </span>
                  <div className="flex-1">
                    <div className="text-[12px] font-semibold">{g.n}</div>
                    <div className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{g.d}</div>
                    <div className="flex gap-1.5 mt-2">
                      {g.lnk && (
                        <a href={g.lnk} target="_blank" rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-lg bg-primary text-primary-foreground font-semibold hover:opacity-80 transition-opacity">
                          Book <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      )}
                      {g.map && (
                        <a href={g.map} target="_blank" rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-lg border border-border text-muted-foreground hover:border-primary/40 transition-colors">
                          <MapPin className="w-2.5 h-2.5" /> Map
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
