import { FileDown, BookOpen, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

const EXPORTS = [
  {
    id: "full",
    label: "Full Itinerary PDF",
    desc: "All 17 days · Cover page · ToC · Every region · Hidden gems & food guide",
    icon: <BookOpen className="w-5 h-5" />,
    col: "bg-primary",
    file: "Kate_Adrian_Italia_2026_Full.pdf",
  },
  {
    id: "milan",
    label: "Milan",
    desc: "3 nights · 25–28 May · Day trip Como",
    icon: <MapPin className="w-4 h-4" />,
    col: "bg-[#7B5038]",
    file: "Kate_Adrian_Italia_2026_Milan.pdf",
  },
  {
    id: "garda",
    label: "Lake Garda",
    desc: "2 nights · 28–30 May · Monte Baldo & Verona",
    icon: <MapPin className="w-4 h-4" />,
    col: "bg-[#4A7A6A]",
    file: "Kate_Adrian_Italia_2026_Lake_Garda.pdf",
  },
  {
    id: "florence",
    label: "Florence",
    desc: "2 nights · 30 May–1 Jun · Uffizi & David",
    icon: <MapPin className="w-4 h-4" />,
    col: "bg-[#7B3F6B]",
    file: "Kate_Adrian_Italia_2026_Florence.pdf",
  },
  {
    id: "tuscany",
    label: "Tuscany",
    desc: "2 nights · 1–3 Jun · Chianti, Siena, Val d'Orcia",
    icon: <MapPin className="w-4 h-4" />,
    col: "bg-[#B8860B]",
    file: "Kate_Adrian_Italia_2026_Tuscany.pdf",
  },
  {
    id: "rome",
    label: "Rome",
    desc: "2+1 nights · 3–5 Jun & 9 Jun · Colosseum, Vatican",
    icon: <MapPin className="w-4 h-4" />,
    col: "bg-[#8B2252]",
    file: "Kate_Adrian_Italia_2026_Rome.pdf",
  },
  {
    id: "sorrento",
    label: "Sorrento & Amalfi",
    desc: "4 nights · 5–9 Jun · Capri, Positano, Path of the Gods",
    icon: <MapPin className="w-4 h-4" />,
    col: "bg-[#B87048]",
    file: "Kate_Adrian_Italia_2026_Sorrento.pdf",
  },
];

export function ExportView() {
  const full = EXPORTS[0];
  const regional = EXPORTS.slice(1);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl italic font-light text-primary font-serif">Export PDFs</h2>
        <p className="text-[12px] text-muted-foreground mt-1">
          Download the full itinerary or individual region guides — beautifully formatted A4 PDFs.
        </p>
      </div>

      {/* Full itinerary — featured */}
      <a
        href={`/${full.file}`}
        download={full.file}
        target="_blank"
        rel="noopener noreferrer"
        className="block bg-primary rounded-xl p-5 text-primary-foreground shadow-md hover:bg-primary/90 transition-colors active:scale-[0.99] cursor-pointer"
      >
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-white/15 flex items-center justify-center shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[15px] font-bold">{full.label}</div>
            <div className="text-[11px] opacity-70 mt-0.5">{full.desc}</div>
          </div>
          <FileDown className="w-5 h-5 opacity-60 shrink-0 mt-1" />
        </div>
      </a>

      {/* Regional guides */}
      <div>
        <div className="text-[11px] font-semibold text-warm uppercase tracking-widest mb-2">Regional Guides</div>
        <div className="space-y-2">
          {regional.map(exp => (
            <a
              key={exp.id}
              href={`/${exp.file}`}
              download={exp.file}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 bg-card border border-border rounded-xl px-4 py-3 shadow-sm hover:border-primary/30 hover:bg-secondary/50 transition-all active:scale-[0.99] cursor-pointer"
            >
              <span className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-white shrink-0", exp.col)}>
                {exp.icon}
              </span>
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-semibold text-foreground">{exp.label}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{exp.desc}</div>
              </div>
              <FileDown className="w-4 h-4 text-muted-foreground shrink-0" />
            </a>
          ))}
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl p-4 text-[11px] text-muted-foreground leading-relaxed">
        <strong className="text-warm">Tip:</strong> Save the PDFs to your phone before the trip for offline access — each guide includes activities, hidden gems, food recommendations, and a daily cost summary.
      </div>
    </div>
  );
}
