import { Day } from "@/data/tripData";
import { cn } from "@/lib/utils";
import { ExternalLink, CheckCircle2, AlertTriangle } from "lucide-react";

interface UrgentItem {
  nm: string;
  nt?: string;
  c: number;
  dt: string;
  di: number;
  si: number;
  lnk?: string;
}

interface Props {
  days: Day[];
  onToggle: (di: number, si: number) => void;
}

export function UrgentView({ days, onToggle }: Props) {
  const urgent: UrgentItem[] = days.flatMap((d, di) =>
    d.sg.map((sg, si) => ({ ...sg, di, si, dt: d.dt }))
       .filter(sg => sg.nt?.includes("⚠") && !sg.bk)
  );

  if (urgent.length === 0) {
    return (
      <div className="text-center py-16 bg-primary/5 border border-primary/15 rounded-xl">
        <CheckCircle2 className="w-10 h-10 mx-auto text-gold mb-3" />
        <div className="text-base italic text-primary font-medium font-serif">Tutto fatto!</div>
        <div className="text-sm text-muted-foreground mt-1">All urgent items are booked.</div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div>
        <h2 className="text-xl italic font-light text-primary mb-1 font-serif">Urgent Bookings</h2>
        <p className="text-xs text-muted-foreground">These sell out months in advance — book as soon as possible.</p>
      </div>

      {urgent.map((item, i) => (
        <div key={i} className="bg-card rounded-xl border-2 border-burg-light/40 p-4 flex flex-wrap justify-between items-start gap-3 shadow-sm">
          <div className="flex-1">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-burg-light shrink-0 mt-0.5" />
              <div>
                <div className="text-[13px] font-semibold">{item.nm}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{item.dt}</div>
                {item.nt && (
                  <div className="text-[11px] text-burg-light mt-1">
                    {item.nt.replace("⚠ ", "").replace("⚠", "")}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {item.c > 0 && <span className="text-sm font-bold text-primary">€{item.c}</span>}
            {item.lnk && (
              <a href={item.lnk} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[10px] px-3 py-1.5 rounded bg-primary text-primary-foreground font-semibold hover:opacity-80 transition-opacity">
                Book <ExternalLink className="w-3 h-3" />
              </a>
            )}
            <button onClick={() => onToggle(item.di, item.si)}
              className="inline-flex items-center gap-1 text-[10px] px-3 py-1.5 rounded bg-gold/20 text-brown border border-gold/40 font-semibold hover:bg-gold/30 transition-colors">
              <CheckCircle2 className="w-3 h-3" /> Done
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
