import { useState } from "react";
import { Plus, Trash2, StickyNote, Calendar, Edit3, Check, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { DAYS } from "@/data/tripData";

export type TripNote = {
  id: string;
  day_index: number | null;
  content: string;
  created_by: string;
  created_at: string;
};

interface Props {
  notes: TripNote[];
  onAdd: (note: Omit<TripNote, "id" | "created_by" | "created_at">) => void;
  onUpdate: (id: string, content: string) => void;
  onDelete: (id: string) => void;
  currentUserId: string;
}

export function NotesView({ notes, onAdd, onUpdate, onDelete, currentUserId }: Props) {
  const [tab, setTab] = useState<"general" | "daily">("general");
  const [draftContent, setDraftContent] = useState("");
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");

  const generalNotes = notes.filter(n => n.day_index === null);
  const notesByDay = DAYS.reduce<Record<number, TripNote[]>>((acc, _, i) => {
    acc[i] = notes.filter(n => n.day_index === i);
    return acc;
  }, {});

  const handleAdd = () => {
    const content = draftContent.trim();
    if (!content) return;
    onAdd({ day_index: tab === "general" ? null : selectedDay ?? null, content });
    setDraftContent("");
  };

  const handleSaveEdit = (id: string) => {
    const content = editContent.trim();
    if (content) onUpdate(id, content);
    setEditingId(null);
  };

  const startEdit = (note: TripNote) => {
    setEditingId(note.id);
    setEditContent(note.content);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl italic font-light text-primary font-serif">Notes</h2>

      {/* Tabs */}
      <div className="flex gap-1.5 bg-muted rounded-lg p-1">
        {(["general", "daily"] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "flex-1 py-1.5 rounded-md text-[12px] font-medium transition-all",
              tab === t ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {t === "general" ? "General Notes" : "Per Day"}
          </button>
        ))}
      </div>

      {/* Day selector for daily tab */}
      {tab === "daily" && (
        <div className="overflow-x-auto -mx-4 px-4">
          <div className="flex gap-1.5 w-max pb-1">
            {DAYS.map((d, i) => (
              <button
                key={i}
                onClick={() => setSelectedDay(i)}
                className={cn(
                  "shrink-0 px-2.5 py-1.5 rounded-lg text-[10px] font-medium border transition-all whitespace-nowrap",
                  selectedDay === i
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card border-border text-foreground hover:border-primary/30",
                  notesByDay[i]?.length > 0 && selectedDay !== i && "border-gold/50"
                )}
              >
                {d.dy.split(" ").slice(0, 2).join(" ")}
                {notesByDay[i]?.length > 0 && <span className="ml-1 text-gold">·</span>}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Add note */}
      <div className="bg-card border border-border rounded-xl p-4 shadow-sm space-y-2">
        <div className="text-[10px] font-semibold text-warm uppercase tracking-widest flex items-center gap-1.5">
          <Edit3 className="w-3 h-3" />
          {tab === "general" ? "New general note" : selectedDay !== null ? `Note for ${DAYS[selectedDay]?.dy}` : "Select a day above"}
        </div>
        <textarea
          rows={3}
          placeholder={tab === "general"
            ? "Anything important — confirmation numbers, tips, reminders…"
            : selectedDay !== null ? `Notes for ${DAYS[selectedDay]?.act}…` : "Select a day first"}
          value={draftContent}
          disabled={tab === "daily" && selectedDay === null}
          onChange={e => setDraftContent(e.target.value)}
          onKeyDown={e => e.key === "Enter" && e.metaKey && handleAdd()}
          className="w-full rounded-lg border border-input bg-background px-3 py-2 text-[13px] placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none disabled:opacity-40"
        />
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-muted-foreground">⌘↵ to save</span>
          <button
            onClick={handleAdd}
            disabled={!draftContent.trim() || (tab === "daily" && selectedDay === null)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary text-primary-foreground text-[11px] font-semibold disabled:opacity-40 hover:bg-primary/90 transition-colors active:scale-95"
          >
            <Plus className="w-3 h-3" /> Add Note
          </button>
        </div>
      </div>

      {/* Notes list */}
      {tab === "general" ? (
        <NoteList
          notes={generalNotes}
          editingId={editingId}
          editContent={editContent}
          currentUserId={currentUserId}
          onStartEdit={startEdit}
          onSaveEdit={handleSaveEdit}
          onCancelEdit={() => setEditingId(null)}
          onEditChange={setEditContent}
          onDelete={onDelete}
          emptyLabel="No general notes yet"
        />
      ) : selectedDay !== null ? (
        <NoteList
          notes={notesByDay[selectedDay] ?? []}
          editingId={editingId}
          editContent={editContent}
          currentUserId={currentUserId}
          onStartEdit={startEdit}
          onSaveEdit={handleSaveEdit}
          onCancelEdit={() => setEditingId(null)}
          onEditChange={setEditContent}
          onDelete={onDelete}
          emptyLabel={`No notes for ${DAYS[selectedDay]?.dy} yet`}
        />
      ) : (
        <div className="bg-card border border-border rounded-xl p-8 text-center">
          <Calendar className="w-8 h-8 mx-auto mb-3 text-muted-foreground opacity-40" />
          <p className="text-[13px] text-muted-foreground">Select a day to see or add notes</p>
        </div>
      )}
    </div>
  );
}

function NoteList({
  notes, editingId, editContent, currentUserId,
  onStartEdit, onSaveEdit, onCancelEdit, onEditChange, onDelete, emptyLabel
}: {
  notes: TripNote[];
  editingId: string | null;
  editContent: string;
  currentUserId: string;
  onStartEdit: (n: TripNote) => void;
  onSaveEdit: (id: string) => void;
  onCancelEdit: () => void;
  onEditChange: (v: string) => void;
  onDelete: (id: string) => void;
  emptyLabel: string;
}) {
  if (notes.length === 0) {
    return (
      <div className="bg-card border border-border rounded-xl p-6 text-center">
        <StickyNote className="w-7 h-7 mx-auto mb-2 text-muted-foreground opacity-40" />
        <p className="text-[12px] text-muted-foreground">{emptyLabel}</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {[...notes]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
        .map(note => (
          <div key={note.id} className="bg-card border border-border rounded-xl p-4 shadow-sm group">
            {editingId === note.id ? (
              <div className="space-y-2">
                <textarea
                  rows={3}
                  value={editContent}
                  onChange={e => onEditChange(e.target.value)}
                  autoFocus
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                />
                <div className="flex gap-2 justify-end">
                  <button onClick={onCancelEdit}
                    className="p-1.5 rounded-full border border-border text-muted-foreground hover:bg-secondary transition-colors">
                    <X className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => onSaveEdit(note.id)}
                    className="p-1.5 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              <>
                <p className="text-[13px] text-foreground leading-relaxed whitespace-pre-wrap">{note.content}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-muted-foreground">
                    {new Date(note.created_at).toLocaleDateString("en-NZ", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                  </span>
                  {note.created_by === currentUserId && (
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => onStartEdit(note)}
                        className="p-1 rounded-full hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground">
                        <Edit3 className="w-3 h-3" />
                      </button>
                      <button onClick={() => onDelete(note.id)}
                        className="p-1 rounded-full hover:bg-destructive/10 transition-colors text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        ))}
    </div>
  );
}
