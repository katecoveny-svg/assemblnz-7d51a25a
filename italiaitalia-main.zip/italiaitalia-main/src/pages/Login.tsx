import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";
import { Loader2, Mail, Lock, Eye, EyeOff } from "lucide-react";

type Mode = "signin" | "signup";

export default function Login() {
  const { signIn, signUp } = useAuth();
  const [mode,     setMode]     = useState<Mode>("signin");
  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [show,     setShow]     = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState<string | null>(null);
  const [info,     setInfo]     = useState<string | null>(null);

  const handle = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null); setInfo(null);
    setLoading(true);
    if (mode === "signin") {
      const { error: err } = await signIn(email, password);
      if (err) setError(err.message);
    } else {
      const { error: err } = await signUp(email, password);
      if (err) setError(err.message);
      else setInfo("Check your email to confirm your account, then sign in.");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-5">
      {/* Brand header */}
      <div className="text-center mb-10 fade-up">
        <h1 className="text-[38px] font-light italic text-primary font-serif leading-none">Kate &amp; Adrian</h1>
        <p className="text-sm font-sans tracking-[0.2em] uppercase text-muted-foreground mt-2">Italia 2026</p>
        <p className="text-[11px] text-muted-foreground mt-1 opacity-60">25 May – 10 Jun</p>
      </div>

      {/* Card */}
      <div className="w-full max-w-sm bg-card rounded-2xl border border-border shadow-md p-7 fade-up delay-1">
        {/* Mode toggle */}
        <div className="flex rounded-lg border border-border overflow-hidden mb-6">
          {(["signin", "signup"] as Mode[]).map(m => (
            <button key={m} onClick={() => { setMode(m); setError(null); setInfo(null); }}
              className={cn(
                "flex-1 py-2 text-[12px] font-medium transition-colors",
                mode === m ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
              )}>
              {m === "signin" ? "Sign in" : "Create account"}
            </button>
          ))}
        </div>

        <form onSubmit={handle} className="space-y-4">
          {/* Email */}
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="email" required placeholder="Email address"
              value={email} onChange={e => setEmail(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 transition-all"
            />
          </div>

          {/* Password */}
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type={show ? "text" : "password"} required placeholder="Password" minLength={6}
              value={password} onChange={e => setPassword(e.target.value)}
              className="w-full pl-9 pr-10 py-2.5 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 transition-all"
            />
            <button type="button" onClick={() => setShow(s => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {/* Error / info */}
          {error && (
            <p className="text-[12px] text-burg-light bg-burg-light/8 border border-burg-light/25 rounded-lg px-3 py-2">{error}</p>
          )}
          {info && (
            <p className="text-[12px] text-brown bg-gold/10 border border-gold/30 rounded-lg px-3 py-2">{info}</p>
          )}

          <button type="submit" disabled={loading}
            className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60 flex items-center justify-center gap-2">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {mode === "signin" ? "Sign in" : "Create account"}
          </button>
        </form>

        <p className="text-[11px] text-muted-foreground text-center mt-5 leading-relaxed">
          This planner is private to Kate &amp; Adrian.<br />Sign in with your registered email.
        </p>
      </div>
    </div>
  );
}
