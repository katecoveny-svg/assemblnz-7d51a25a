import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Download, Smartphone, Share, MoreVertical, PlusSquare, CheckCircle2 } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function Install() {
  const navigate = useNavigate();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    const ua = navigator.userAgent;
    setIsIOS(/iphone|ipad|ipod/i.test(ua));
    setIsAndroid(/android/i.test(ua));
    setIsStandalone(
      window.matchMedia("(display-mode: standalone)").matches ||
      ("standalone" in navigator && (navigator as { standalone?: boolean }).standalone === true)
    );

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", () => setInstalled(true));
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") setInstalled(true);
    setDeferredPrompt(null);
  };

  const Step = ({ n, icon, text }: { n: number; icon: React.ReactNode; text: string }) => (
    <div className="flex items-start gap-3">
      <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">{n}</span>
      <div className="flex items-center gap-2 text-sm text-foreground">
        <span className="text-muted-foreground">{icon}</span>
        <span>{text}</span>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background font-serif flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-br from-foreground via-primary to-[hsl(var(--primary-light))] px-6 pt-12 pb-10 text-primary-foreground text-center">
        <div className="w-20 h-20 rounded-[22px] mx-auto mb-4 overflow-hidden shadow-xl border-2 border-white/20">
          <img src="/pwa-192.png" alt="App icon" className="w-full h-full object-cover" />
        </div>
        <h1 className="text-2xl font-light italic tracking-wide">Italia 2026</h1>
        <p className="text-sm opacity-70 mt-1 tracking-wide">Kate &amp; Adrian's trip planner</p>
      </div>

      <div className="flex-1 px-5 py-6 max-w-sm mx-auto w-full space-y-6">

        {/* Already installed */}
        {isStandalone || installed ? (
          <div className="text-center space-y-4 pt-4">
            <CheckCircle2 className="w-14 h-14 text-green mx-auto" />
            <p className="font-semibold text-foreground text-lg">Already installed!</p>
            <p className="text-sm text-muted-foreground">The app is on your home screen and works offline.</p>
            <button
              onClick={() => navigate("/")}
              className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
            >
              Open the trip planner →
            </button>
          </div>

        /* Android — native install prompt */
        ) : deferredPrompt ? (
          <div className="space-y-5">
            <div className="rounded-xl bg-secondary p-4 text-sm text-foreground leading-relaxed">
              Add <strong>Italia 2026</strong> to your home screen for quick access, offline viewing, and a full-screen app experience.
            </div>
            <button
              onClick={handleInstall}
              className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform"
            >
              <Download className="w-4 h-4" /> Add to Home Screen
            </button>
            <button onClick={() => navigate("/")} className="w-full text-center text-xs text-muted-foreground py-2">
              Not now — go to the planner
            </button>
          </div>

        /* iOS instructions */
        ) : isIOS ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Follow these steps in <strong>Safari</strong> to install:</p>
            <div className="bg-card rounded-xl border border-border p-4 space-y-4">
              <Step n={1} icon={<Share className="w-4 h-4" />} text='Tap the Share button at the bottom of Safari' />
              <Step n={2} icon={<PlusSquare className="w-4 h-4" />} text='"Add to Home Screen"' />
              <Step n={3} icon={<Smartphone className="w-4 h-4" />} text='Tap "Add" — the app icon appears on your home screen' />
            </div>
            <div className="rounded-xl bg-[hsl(var(--rose)/0.08)] border border-[hsl(var(--rose)/0.2)] px-4 py-3 text-xs text-muted-foreground">
              Must be opened in <strong>Safari</strong> — Chrome and Firefox on iPhone don't support home screen install.
            </div>
            <button onClick={() => navigate("/")} className="w-full text-center text-xs text-muted-foreground py-2">
              Back to the planner
            </button>
          </div>

        /* Android manual instructions */
        ) : isAndroid ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Install from your browser menu:</p>
            <div className="bg-card rounded-xl border border-border p-4 space-y-4">
              <Step n={1} icon={<MoreVertical className="w-4 h-4" />} text='Tap the ⋮ menu (top-right of Chrome)' />
              <Step n={2} icon={<PlusSquare className="w-4 h-4" />} text='"Add to Home screen" or "Install app"' />
              <Step n={3} icon={<Smartphone className="w-4 h-4" />} text='Tap "Install" to confirm' />
            </div>
            <button onClick={() => navigate("/")} className="w-full text-center text-xs text-muted-foreground py-2">
              Back to the planner
            </button>
          </div>

        /* Desktop fallback */
        ) : (
          <div className="space-y-4">
            <div className="rounded-xl bg-secondary p-4 text-sm text-foreground">
              Open this page on your phone to install the app. On iPhone use Safari; on Android use Chrome.
            </div>
            <div className="font-mono text-xs bg-card border border-border rounded-lg px-4 py-3 text-center break-all text-muted-foreground select-all">
              {window.location.origin}/install
            </div>
            <button
              onClick={() => navigate("/")}
              className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
            >
              Open the trip planner →
            </button>
          </div>
        )}

        {/* Offline badge */}
        <div className="flex items-center gap-2 rounded-xl bg-[hsl(var(--green)/0.08)] border border-[hsl(var(--green)/0.2)] px-4 py-3">
          <CheckCircle2 className="w-4 h-4 text-green shrink-0" />
          <p className="text-xs text-foreground">Works offline — all activities, hotels &amp; phrases load without Wi-Fi.</p>
        </div>
      </div>
    </div>
  );
}
