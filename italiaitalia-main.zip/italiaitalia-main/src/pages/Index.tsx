import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { HOTELS, ActivityType } from "@/data/tripData";
import { TripHeader } from "@/components/trip/TripHeader";
import { TimelineView } from "@/components/trip/TimelineView";
import { HotelsView } from "@/components/trip/HotelsView";
import { UrgentView } from "@/components/trip/UrgentView";
import { BudgetView } from "@/components/trip/BudgetView";
import { FoodView } from "@/components/trip/FoodView";
import { PackingView } from "@/components/trip/PackingView";
import { MapView } from "@/components/trip/MapView";
import { ExpenseView } from "@/components/trip/ExpenseView";
import { CountdownView } from "@/components/trip/CountdownView";
import { NotesView } from "@/components/trip/NotesView";
import { ExportView } from "@/components/trip/ExportView";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { useTripSync } from "@/hooks/useTripSync";
import {
  Map, Calendar, Hotel, AlertTriangle, Wallet, Utensils, ShoppingBag,
  Download, Check, LogOut, Loader2, Receipt, StickyNote, Timer,
} from "lucide-react";

type View = "countdown" | "timeline" | "hotels" | "urgent" | "budget" | "food" | "packing" | "map" | "expenses" | "notes" | "export";

const FLIGHT_PER_PAX = 4850;

// Nav groups for cleaner layout
const PRIMARY_VIEWS: View[] = ["countdown", "timeline", "hotels", "map"];

export default function Index() {
  const navigate = useNavigate();
  const { profile, tripRole, user, signOut } = useAuth();
  const {
    days, votes, alreadyBooked, selectedNzd, customHotels, packing, expenses, notes, synced,
    toggleActivity, handleVote,
    handleSetCustomHotel, handleSelectOption, handleMarkBooked,
    handlePackingToggle, handlePackingAdd, handlePackingRemove,
    handleAddExpense, handleDeleteExpense,
    handleAddNote, handleUpdateNote, handleDeleteNote,
  } = useTripSync();

  const [view, setView] = useState<View>("countdown");
  const [pax, setPax] = useState(2);
  const [customActs, setCustomActs] = useState<Record<string, { nm: string; c: number; tp: ActivityType; bk: boolean }[]>>({});
  const [showInstallNudge, setShowInstallNudge] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);

  useEffect(() => {
    const isStandalone = window.matchMedia("(display-mode: standalone)").matches;
    const dismissed = sessionStorage.getItem("install-nudge-dismissed");
    if (!isStandalone && !dismissed && /iphone|ipad|android/i.test(navigator.userAgent)) {
      setShowInstallNudge(true);
    }
  }, []);

  // Close "More" menu when main view changes
  useEffect(() => { setMoreOpen(false); }, [view]);

  const urgentCount = days.reduce((s, d) => s + d.sg.filter(a => a.nt?.includes("⚠") && !a.bk).length, 0);
  const packingDone = Object.values(packing).reduce((s, items) => s + items.filter(i => i.k && i.a).length, 0);
  const packingTotal = Object.values(packing).reduce((s, items) => s + items.length, 0);

  const addCustomAct = (di: number, nm: string, cost: number) => {
    const key = `d${di}`;
    setCustomActs(prev => ({ ...prev, [key]: [...(prev[key] ?? []), { nm, c: cost, tp: "experience", bk: false }] }));
  };
  const removeCustomAct = (di: number, ci: number) => {
    const key = `d${di}`;
    setCustomActs(prev => { const arr = [...(prev[key] ?? [])]; arr.splice(ci, 1); return { ...prev, [key]: arr }; });
  };
  const toggleCustomAct = (di: number, ci: number) => {
    const key = `d${di}`;
    setCustomActs(prev => ({ ...prev, [key]: (prev[key] ?? []).map((a, i) => i === ci ? { ...a, bk: !a.bk } : a) }));
  };

  // Bottom nav items (primary)
  type NavItem = { id: View; label: string; icon: React.ReactNode; badge?: number | string };
  const BOTTOM_NAV: NavItem[] = [
    { id: "countdown", label: "Home", icon: <Timer className="w-5 h-5" /> },
    { id: "timeline", label: "Days", icon: <Calendar className="w-5 h-5" /> },
    { id: "hotels", label: "Hotels", icon: <Hotel className="w-5 h-5" /> },
    { id: "map", label: "Route", icon: <Map className="w-5 h-5" /> },
  ];

  // "More" drawer items
  const MORE_NAV: NavItem[] = [
    { id: "urgent", label: urgentCount > 0 ? `Urgent (${urgentCount})` : "Urgent", icon: <AlertTriangle className="w-4 h-4" />, badge: urgentCount || undefined },
    { id: "budget", label: "Budget", icon: <Wallet className="w-4 h-4" /> },
    { id: "expenses", label: "Expenses", icon: <Receipt className="w-4 h-4" /> },
    { id: "food", label: "Food Guide", icon: <Utensils className="w-4 h-4" /> },
    { id: "packing", label: packingDone === packingTotal && packingTotal > 0 ? "Packing ✓" : "Packing", icon: packingDone === packingTotal && packingTotal > 0 ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" /> },
    { id: "notes", label: notes.length > 0 ? `Notes (${notes.length})` : "Notes", icon: <StickyNote className="w-4 h-4" /> },
    { id: "export", label: "Export PDFs", icon: <Download className="w-4 h-4" /> },
  ];

  const isMoreActive = MORE_NAV.some(n => n.id === view);

  return (
    <div className="min-h-screen bg-background font-sans pb-20">
      {/* Install nudge */}
      {showInstallNudge && (
        <div className="bg-primary text-primary-foreground px-4 py-2.5 flex items-center gap-3 text-[11px]">
          <Download className="w-4 h-4 shrink-0 opacity-70" />
          <span className="flex-1">Add to your home screen for offline access</span>
          <button onClick={() => navigate("/install")}
            className="bg-white/20 hover:bg-white/30 transition-colors rounded-full px-3 py-1 font-semibold shrink-0">
            Install
          </button>
          <button onClick={() => { setShowInstallNudge(false); sessionStorage.setItem("install-nudge-dismissed", "1"); }}
            className="opacity-60 hover:opacity-100 transition-opacity text-lg leading-none">×</button>
        </div>
      )}

      <TripHeader
        days={days} hotels={HOTELS} customNzd={customHotels}
        selectedNzd={selectedNzd} alreadyBooked={alreadyBooked}
        pax={pax} flightPerPax={FLIGHT_PER_PAX}
      />

      {/* User identity bar */}
      <div className="max-w-3xl mx-auto px-4 pt-2 pb-1 flex items-center justify-end gap-2">
        {!synced && <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
        <div className={cn(
          "w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold text-white shrink-0",
          tripRole === 'k' ? "bg-primary" : "bg-gold"
        )}>
          {profile?.display_name?.[0] ?? "?"}
        </div>
        <span className="text-[11px] text-muted-foreground">{profile?.display_name ?? ""}</span>
        <button onClick={signOut} title="Sign out"
          className="p-1.5 rounded-full hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground">
          <LogOut className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Content */}
      <main className={cn("max-w-3xl mx-auto px-4", view === "map" ? "py-2" : "py-4")}>
        {view === "countdown" && (
          <CountdownView
            days={days} alreadyBooked={alreadyBooked} customHotels={customHotels}
            packing={packing} urgentCount={urgentCount}
            onNavigate={(v) => setView(v as View)}
          />
        )}
        {view === "map" && (
          <MapView days={days} alreadyBooked={alreadyBooked} customHotels={customHotels} onNavigate={(v) => setView(v as View)} />
        )}
        {view === "timeline" && (
          <TimelineView days={days} votes={votes} customActs={customActs}
            onToggle={toggleActivity} onVote={handleVote}
            onAddCustom={addCustomAct} onRemoveCustom={removeCustomAct} onToggleCustom={toggleCustomAct}
          />
        )}
        {view === "hotels" && (
          <HotelsView customHotels={customHotels} selectedNzd={selectedNzd} alreadyBooked={alreadyBooked}
            onSetCustom={handleSetCustomHotel} onSelectOption={handleSelectOption} onMarkBooked={handleMarkBooked}
          />
        )}
        {view === "urgent" && <UrgentView days={days} onToggle={toggleActivity} />}
        {view === "budget" && (
          <BudgetView days={days} pax={pax} setPax={setPax}
            customHotels={customHotels} selectedNzd={selectedNzd} alreadyBooked={alreadyBooked}
            flightPerPax={FLIGHT_PER_PAX} customActs={customActs}
          />
        )}
        {view === "expenses" && (
          <ExpenseView expenses={expenses} onAdd={handleAddExpense} onDelete={handleDeleteExpense} currentUserRole={tripRole ?? "k"} />
        )}
        {view === "food" && <FoodView />}
        {view === "packing" && (
          <PackingView packing={packing} onToggle={handlePackingToggle} onAddItem={handlePackingAdd} onRemoveItem={handlePackingRemove} />
        )}
        {view === "notes" && (
          <NotesView notes={notes} onAdd={handleAddNote} onUpdate={handleUpdateNote} onDelete={handleDeleteNote} currentUserId={user?.id ?? ""} />
        )}
        {view === "export" && <ExportView />}
      </main>

      {/* ── Fixed bottom navigation ── */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 bg-background/98 backdrop-blur border-t border-border safe-area-pb">
        <div className="max-w-3xl mx-auto flex items-end">
          {BOTTOM_NAV.map(({ id, label, icon }) => {
            const active = view === id;
            return (
              <button
                key={id}
                onClick={() => setView(id)}
                className={cn(
                  "flex-1 flex flex-col items-center gap-0.5 py-2.5 transition-all",
                  active ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <div className={cn(
                  "rounded-xl px-3 py-1 transition-all",
                  active ? "bg-primary/10" : ""
                )}>
                  {icon}
                </div>
                <span className={cn("text-[10px] font-medium", active ? "text-primary" : "")}>{label}</span>
              </button>
            );
          })}

          {/* More button */}
          <button
            onClick={() => setMoreOpen(v => !v)}
            className={cn(
              "flex-1 flex flex-col items-center gap-0.5 py-2.5 transition-all relative",
              isMoreActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
            )}
          >
            <div className={cn(
              "rounded-xl px-3 py-1 transition-all",
              isMoreActive ? "bg-primary/10" : ""
            )}>
              <div className="w-5 h-5 flex flex-col justify-center items-center gap-[3px]">
                <span className={cn("w-4 h-[1.5px] rounded-full bg-current transition-all", moreOpen ? "rotate-45 translate-y-[4.5px]" : "")} />
                <span className={cn("w-4 h-[1.5px] rounded-full bg-current transition-all", moreOpen ? "opacity-0" : "")} />
                <span className={cn("w-4 h-[1.5px] rounded-full bg-current transition-all", moreOpen ? "-rotate-45 -translate-y-[4.5px]" : "")} />
              </div>
            </div>
            <span className={cn("text-[10px] font-medium", isMoreActive ? "text-primary" : "")}>More</span>
            {urgentCount > 0 && (
              <span className="absolute top-1.5 right-4 w-4 h-4 rounded-full bg-destructive text-white text-[9px] font-bold flex items-center justify-center">
                {urgentCount}
              </span>
            )}
          </button>
        </div>

        {/* More drawer */}
        {moreOpen && (
          <div className="border-t border-border bg-background/98 backdrop-blur animate-in slide-in-from-bottom-2 duration-200">
            <div className="max-w-3xl mx-auto px-4 py-3 grid grid-cols-3 gap-2">
              {MORE_NAV.map(({ id, label, icon, badge }) => {
                const active = view === id;
                return (
                  <button
                    key={id}
                    onClick={() => setView(id)}
                    className={cn(
                      "flex items-center gap-2 px-3 py-2.5 rounded-xl border text-left transition-all",
                      active
                        ? "bg-primary text-primary-foreground border-primary"
                        : id === "urgent" && urgentCount > 0
                          ? "bg-card border-destructive/40 text-destructive hover:bg-destructive/5"
                          : "bg-card border-border text-foreground hover:bg-secondary"
                    )}
                  >
                    <span className="shrink-0">{icon}</span>
                    <span className="text-[11px] font-medium leading-tight">{label}</span>
                    {typeof badge === "number" && badge > 0 && (
                      <span className="ml-auto w-4 h-4 rounded-full bg-destructive text-white text-[9px] font-bold flex items-center justify-center shrink-0">
                        {badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </nav>
    </div>
  );
}
